import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Enable reading JSON request bodies
  app.use(express.json());

  // Secure admin authentication gateway
  app.post("/api/admin-login", (req, res) => {
    const { username, password } = req.body;

    // Retrieve secure credentials from environment variables, fallback securely
    const envUsername = process.env.ADMIN_USERNAME || "medicare2021";
    const envPassword = process.env.ADMIN_PASSWORD || "Mcsh@7005";

    const isProd = process.env.NODE_ENV === "production";

    let isValid = false;

    if (username === envUsername && password === envPassword) {
      isValid = true;
    } else if (!isProd) {
      // Sandbox / development credentials allowed only in non-production mode
      if (
        (username === "admin" && password === "admin") ||
        (username === "sandeep.24mic7005@vitapstudent.ac.in" && password === "admin") ||
        (username === "sandeep.24mic7005@vitapstudent.ac.in" && password === "password123")
      ) {
        isValid = true;
      }
    }

    if (isValid) {
      res.json({ success: true, token: "authorized_session_token_secure" });
    } else {
      // Show clean, unified secure error message
      res.status(401).json({ success: false, error: "Invalid username or password." });
    }
  });

  // Serve the dynamic EmailJS configuration to the client
  app.get("/api/email-config", (req, res) => {
    const serviceId = process.env.VITE_EMAILJS_SERVICE_ID || process.env.EMAILJS_SERVICE_ID || "";
    const templateId = process.env.VITE_EMAILJS_TEMPLATE_ID || process.env.EMAILJS_TEMPLATE_ID || "";
    const publicKey = process.env.VITE_EMAILJS_PUBLIC_KEY || process.env.EMAILJS_PUBLIC_KEY || "";

    res.json({
      serviceId,
      templateId,
      publicKey
    });
  });

  // Basic API Healthcheck
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Serve frontend assets using Vite dev middleware or standard production statics
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Medicare Server] Full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
