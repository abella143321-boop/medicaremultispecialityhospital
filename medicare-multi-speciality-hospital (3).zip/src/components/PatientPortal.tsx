import React, { useState, useEffect } from "react";
import { 
  User, 
  Phone, 
  Mail, 
  Lock, 
  KeyRound, 
  UserCheck, 
  CalendarDays, 
  Clock, 
  Bell, 
  ChevronRight, 
  LogOut, 
  ShieldAlert,
  Loader2,
  Stethoscope,
  Smile,
  CheckCircle2,
  AlertTriangle
} from "lucide-react";
import { dbAPI, CMSPatientUser, CMSAppointment } from "../utils/db";
import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { auth } from "../utils/firebase";

export default function PatientPortal() {
  const [currentUser, setCurrentUser] = useState<CMSPatientUser | null>(null);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [loginMethod, setLoginMethod] = useState<"email" | "mobile">("email");
  
  // Login State
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mobile, setMobile] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [simulatedOtp, setSimulatedOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loginError, setLoginError] = useState("");

  // Registration State
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regMobile, setRegMobile] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirmPassword, setRegConfirmPassword] = useState("");
  const [regError, setRegError] = useState("");
  const [regSuccess, setRegSuccess] = useState(false);

  // Dashboard Data
  const [appointments, setAppointments] = useState<CMSAppointment[]>([]);

  // Check login state on mount
  useEffect(() => {
    const savedUserSession = localStorage.getItem("medicare_patient_session");
    if (savedUserSession) {
      const user = JSON.parse(savedUserSession);
      // Double check blocking status
      const freshUsers = dbAPI.getUsers();
      const match = freshUsers.find(u => u.uid === user.uid);
      if (match && !match.blocked) {
        setCurrentUser(match);
      } else {
        localStorage.removeItem("medicare_patient_session");
      }
    }
  }, []);

  // Listen to Google authentication sessions for the Patient Portal
  useEffect(() => {
    const unsub = auth.onAuthStateChanged((user) => {
      if (user) {
        const freshUsers = dbAPI.getUsers();
        const match = freshUsers.find(u => u.uid === user.uid || (u.email && u.email.toLowerCase() === user.email?.toLowerCase()));
        if (match) {
          if (match.blocked) {
            setCurrentUser(null);
            localStorage.removeItem("medicare_patient_session");
            auth.signOut();
          } else {
            setCurrentUser(match);
            localStorage.setItem("medicare_patient_session", JSON.stringify(match));
          }
        } else {
          // Register dynamic new authenticated user from Google credentials instantly
          const patUser: CMSPatientUser = {
            uid: user.uid,
            name: user.displayName || "Patient User",
            email: user.email || undefined,
            mobile: user.phoneNumber || "",
            blocked: false,
            registeredAt: new Date().toISOString()
          };
          dbAPI.saveUsers([...freshUsers, patUser]);
          setCurrentUser(patUser);
          localStorage.setItem("medicare_patient_session", JSON.stringify(patUser));
        }
      }
    });

    return () => unsub();
  }, []);

  const handleGoogleLogin = async () => {
    setLoginError("");
    setRegError("");
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      console.error(err);
      setLoginError(err.message || "An error occurred during Google sign-in.");
    }
  };

  // Fetch appointments for current user
  useEffect(() => {
    if (currentUser) {
      const allApps = dbAPI.getAppointments();
      // Filter by registered email or mobile
      const userApps = allApps.filter(
        app => 
          (currentUser.email && app.email.toLowerCase() === currentUser.email.toLowerCase()) || 
          app.mobile === currentUser.mobile
      );
      setAppointments(userApps);
    }
  }, [currentUser]);

  // Handle Email + Password Login
  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    if (!email || !password) {
      setLoginError("Please enter both email and password.");
      return;
    }

    const users = dbAPI.getUsers();
    const match = users.find(u => u.email?.toLowerCase() === email.toLowerCase() && u.password === password);

    if (!match) {
      setLoginError("Invalid email or password.");
      return;
    }

    if (match.blocked) {
      setLoginError("Your account has been deactivated. Please contact clinical administration.");
      return;
    }

    setCurrentUser(match);
    localStorage.setItem("medicare_patient_session", JSON.stringify(match));
  };

  // Trigger simulated Mobile OTP dispatch
  const handleSendOtp = () => {
    setOtpError("");
    setSimulatedOtp("");

    if (!mobile || mobile.length < 10) {
      setOtpError("Please enter a valid 10-digit mobile number.");
      return;
    }

    const users = dbAPI.getUsers();
    const match = users.find(u => u.mobile === mobile);

    if (!match) {
      setOtpError("Mobile number is not registered yet. Please create an account first.");
      return;
    }

    if (match.blocked) {
      setOtpError("Your account has been deactivated. Please contact support.");
      return;
    }

    // Generate simulated 4 digit code
    const mockCode = Math.floor(1000 + Math.random() * 9000).toString();
    setSimulatedOtp(mockCode);
    setOtpSent(true);
  };

  // Perform Simulated OTP validation
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpError("");

    if (otpCode !== simulatedOtp) {
      setOtpError("Incorrect OTP verification code. Please try again.");
      return;
    }

    const users = dbAPI.getUsers();
    const match = users.find(u => u.mobile === mobile)!;

    setCurrentUser(match);
    localStorage.setItem("medicare_patient_session", JSON.stringify(match));
    
    // Clear OTP states
    setOtpSent(false);
    setSimulatedOtp("");
    setOtpCode("");
  };

  // Handle registration
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");

    if (!regName || !regMobile || !regPassword) {
      setRegError("Please fill out all mandatory fields.");
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError("Passwords do not match.");
      return;
    }

    const result = dbAPI.registerPatient(regName, regEmail, regMobile, regPassword);

    if ("error" in result) {
      setRegError(result.error);
      return;
    }

    setRegSuccess(true);
    setTimeout(() => {
      setRegSuccess(false);
      setAuthMode("login");
      setEmail(regEmail);
      setPassword(regPassword);
      setRegName("");
      setRegEmail("");
      setRegMobile("");
      setRegPassword("");
      setRegConfirmPassword("");
    }, 2000);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("medicare_patient_session");
    auth.signOut().catch(console.error);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8" id="patient-portal-container">
      {currentUser ? (
        // ================= PATIENT DASHBOARD SATE =================
        <div className="space-y-8 animate-fadeIn" id="patient-dashboard">
          
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-[#0077B6] to-indigo-700 text-white p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <Smile className="w-6 h-6 text-emerald-300" />
                <span className="text-xs uppercase tracking-widest font-black text-emerald-300">Medicare Patient Portal</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Welcome back, {currentUser.name}!
              </h2>
              <p className="text-sky-100 text-xs sm:text-sm font-medium">
                Access your consultation roster, slot bookings, and hospital updates.
              </p>
            </div>
            
            <button
              onClick={handleLogout}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all self-start sm:self-auto flex items-center gap-1.5 cursor-pointer"
              id="patient-logout-btn"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Patient Profile Card (1/3 COL) */}
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-md h-fit space-y-6">
              <div className="border-b border-slate-100 pb-4">
                <h4 className="font-bold text-slate-800 text-sm tracking-tight uppercase">Profile Details</h4>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center font-bold">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-extrabold text-slate-800 text-sm leading-tight">{currentUser.name}</div>
                    <div className="text-[10px] text-slate-400 font-medium">Registered Patient</div>
                  </div>
                </div>

                <div className="space-y-3 pt-2 text-xs">
                  <div className="flex items-center gap-2.5 text-slate-600">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span className="font-mono">+91 {currentUser.mobile}</span>
                  </div>
                  {currentUser.email && (
                    <div className="flex items-center gap-2.5 text-slate-600">
                      <Mail className="w-4 h-4 text-slate-400" />
                      <span className="break-all">{currentUser.email}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2.5 text-slate-600">
                    <CalendarDays className="w-4 h-4 text-slate-400" />
                    <span>Member since: {new Date(currentUser.registeredAt).toLocaleDateString('en-GB')}</span>
                  </div>
                </div>
              </div>

              <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100 text-emerald-800 text-xs space-y-1">
                <div className="font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  Account Active
                </div>
                <p className="text-[11px] text-emerald-600/90 leading-relaxed">
                  You have full read-access to book appointments and consult clinical specialists. Editing permissions are locked.
                </p>
              </div>
            </div>

            {/* Roster / Appointment History (2/3 COL) */}
            <div className="md:col-span-2 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <h4 className="font-bold text-slate-800 text-sm tracking-tight uppercase flex items-center gap-1.5">
                  <CalendarDays className="w-4 h-4 text-sky-600" />
                  My Appointments ({appointments.length})
                </h4>
                <span className="text-[11px] font-mono text-slate-400 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                  Real-time schedule
                </span>
              </div>

              {appointments.length === 0 ? (
                <div className="text-center py-12 px-4 space-y-4">
                  <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <CalendarDays className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <p className="font-extrabold text-slate-700 text-sm">No Appointments Logged</p>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto">
                      Book a specialist consultation through the "Book Appointment" tab to track your schedules here in real-time.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
                  {appointments.map((app) => {
                    const statusColors = {
                      Pending: "bg-amber-50 text-amber-700 border-amber-100",
                      Confirmed: "bg-emerald-50 text-emerald-700 border-emerald-100",
                      Completed: "bg-sky-50 text-sky-700 border-sky-100",
                      Cancelled: "bg-rose-50 text-rose-700 border-rose-100"
                    };

                    return (
                      <div 
                        key={app.id} 
                        className="p-4 rounded-2xl border border-slate-100 hover:border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-all flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
                        id={`patient-app-${app.id}`}
                      >
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-black text-slate-800 text-sm">{app.doctor}</span>
                            <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${statusColors[app.status] || "bg-slate-100"}`}>
                              {app.status}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-slate-500 font-medium">
                            <div className="flex items-center gap-1 font-mono">
                              <CalendarDays className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              {app.date}
                            </div>
                            <div className="flex items-center gap-1 font-mono">
                              <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              {app.time}
                            </div>
                          </div>

                          <p className="text-[11px] text-slate-400 leading-relaxed italic block">
                            Symptoms: {app.symptoms}
                          </p>
                        </div>

                        {app.notifications?.broadcast && (
                          <div className="bg-sky-50/80 border border-sky-100 rounded-xl p-3 text-sky-800 text-xs sm:max-w-xs space-y-1 self-start sm:self-center">
                            <div className="font-extrabold flex items-center gap-1">
                              <Bell className="w-3.5 h-3.5 text-sky-600 shrink-0 animate-bounce" />
                              Clinical Note
                            </div>
                            <p className="text-[11px] text-sky-700/90 leading-relaxed">
                              {app.notifications.broadcast}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

        </div>
      ) : (
        // ================= AUTHENTICATION FORM STATE =================
        <div className="max-w-md mx-auto bg-white p-8 rounded-3xl border border-slate-100 shadow-xl space-y-6" id="patient-auth-card">
          
          {/* Form Header */}
          <div className="text-center space-y-2">
            <span className="bg-[#0077B6]/5 text-[#0077B6] px-3.5 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider inline-block border border-sky-100">
              Patient Portal Gateway
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-800 tracking-tight">
              {authMode === "login" ? "Welcome to Medicare" : "Create Patient Account"}
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              {authMode === "login" 
                ? "Sign in to monitor slot allocations and consult diagnostic alerts." 
                : "Register with your direct contact numbers to start booking slots."}
            </p>
          </div>

          {authMode === "login" ? (
            // ============ LOGIN TAB ============
            <div className="space-y-5">
              
              {/* Method Switchers */}
              <div className="grid grid-cols-2 gap-1.5 bg-slate-50 p-1 rounded-xl border border-slate-100">
                <button
                  type="button"
                  onClick={() => { setLoginMethod("email"); setLoginError(""); }}
                  className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${loginMethod === "email" ? "bg-white text-[#0077B6] shadow-sm" : "text-slate-500 hover:text-slate-800"}`}
                >
                  Email & Password
                </button>
                <button
                  type="button"
                  onClick={() => { setLoginMethod("mobile"); setLoginError(""); }}
                  className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${loginMethod === "mobile" ? "bg-white text-[#0077B6] shadow-sm" : "text-slate-500 hover:text-slate-800"}`}
                >
                  Mobile Number + OTP
                </button>
              </div>

              {loginMethod === "email" ? (
                // Email + Password input fields
                <form onSubmit={handleEmailLogin} className="space-y-4">
                  {loginError && (
                    <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-100 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      {loginError}
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="email" 
                        required
                        placeholder="e.g. sandeep.24@vitapstudent.ac.in" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="password" 
                        required
                        placeholder="••••••••" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wider uppercase shadow-md hover:shadow-lg transition-all cursor-pointer"
                    id="submit-email-login"
                  >
                    Authenticate Account
                  </button>
                </form>
              ) : (
                // Mobile + Simulated OTP fields
                <div className="space-y-4">
                  {otpError && (
                    <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-100 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      {otpError}
                    </div>
                  )}

                  {!otpSent ? (
                    <div className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 block">Registered Mobile Number</label>
                        <div className="relative">
                          <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                          <input 
                            type="tel" 
                            maxLength={10}
                            placeholder="e.g. 6281573727" 
                            value={mobile}
                            onChange={(e) => setMobile(e.target.value.replace(/\D/g, ""))}
                            className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800 font-mono"
                          />
                        </div>
                        <p className="text-[10px] text-slate-400">Enter your 10-digit primary communication number.</p>
                      </div>

                      <button
                        type="button"
                        onClick={handleSendOtp}
                        className="w-full py-3 rounded-xl bg-[#0077B6] hover:bg-sky-700 text-white font-bold text-xs tracking-wider uppercase shadow-md transition-all cursor-pointer"
                        id="send-otp-btn"
                      >
                        Send Verification OTP
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleVerifyOtp} className="space-y-4">
                      {/* Interactive Simulated SMS Indicator */}
                      <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4 text-emerald-800 text-xs space-y-1">
                        <div className="font-extrabold flex items-center gap-1.5 text-emerald-700 animate-pulse">
                          <Bell className="w-4 h-4 fill-emerald-600 text-white shrink-0" />
                          Simulated SMS Gateway Dispatch
                        </div>
                        <p className="text-[11px] leading-relaxed text-emerald-600/90 font-mono">
                          OTP Sent successfully to +91 {mobile}. Use simulated credential:{" "}
                          <span className="font-bold text-sm bg-emerald-100 px-2.5 py-0.5 rounded-lg text-emerald-800 tracking-widest">{simulatedOtp}</span>
                        </p>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 block">Enter One-Time Password</label>
                        <div className="relative">
                          <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                          <input 
                            type="text" 
                            required
                            maxLength={4}
                            placeholder="e.g. 1234" 
                            value={otpCode}
                            onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                            className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800 font-mono tracking-widest text-center text-lg font-bold"
                          />
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setOtpSent(false)}
                          className="w-1/3 py-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-100 text-slate-600 font-bold text-xs tracking-wider uppercase transition-all cursor-pointer"
                        >
                          Back
                        </button>
                        <button
                          type="submit"
                          className="w-2/3 py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wider uppercase shadow-md transition-all cursor-pointer"
                        >
                          Verify & Secure Login
                        </button>
                      </div>
                    </form>
                  )}

                </div>
              )}

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-slate-200"></div>
                <span className="flex-shrink mx-4 text-slate-400 text-[10px] font-bold uppercase tracking-wider">or sign in with</span>
                <div className="flex-grow border-t border-slate-200"></div>
              </div>

              <button
                type="button"
                onClick={handleGoogleLogin}
                className="w-full py-3 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm bg-white"
                id="patient-google-login-btn"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.08H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.92l2.85-2.22.81-.6z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.08l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>
                Secure Google Authentication
              </button>

              <div className="text-center pt-2">
                <span className="text-xs text-slate-400">New patient? </span>
                <button
                  type="button"
                  onClick={() => { setAuthMode("register"); setLoginError(""); }}
                  className="text-xs font-extrabold text-sky-600 hover:underline cursor-pointer"
                >
                  Create an Account
                </button>
              </div>

            </div>
          ) : (
            // ============ REGISTRATION TAB ============
            <form onSubmit={handleRegister} className="space-y-4">
              {regError && (
                <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-100 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  {regError}
                </div>
              )}

              {regSuccess && (
                <div className="p-3.5 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-xl border border-emerald-100 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Your registration is successful! Redirecting to login...
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">
                  Patient Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text" 
                    required
                    placeholder="e.g. Sandeep Vitap" 
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">Email Address (Optional)</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="email" 
                    placeholder="e.g. sandeep.24mic7005@vitapstudent.ac.in" 
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">
                  Mobile Number <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="tel" 
                    required
                    maxLength={10}
                    placeholder="e.g. 6281573727" 
                    value={regMobile}
                    onChange={(e) => setRegMobile(e.target.value.replace(/\D/g, ""))}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">
                  Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="password" 
                    required
                    placeholder="••••••••" 
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">
                  Confirm Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="password" 
                    required
                    placeholder="••••••••" 
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wider uppercase shadow-md transition-all cursor-pointer"
                id="submit-patient-registration"
              >
                Register & Initialize
              </button>

              <div className="text-center pt-2">
                <span className="text-xs text-slate-400">Already registered? </span>
                <button
                  type="button"
                  onClick={() => { setAuthMode("login"); setRegError(""); }}
                  className="text-xs font-extrabold text-sky-600 hover:underline cursor-pointer"
                >
                  Log In
                </button>
              </div>
            </form>
          )}

        </div>
      )}
    </div>
  );
}
