import { useState, useEffect } from "react";
import { 
  Phone, 
  Menu, 
  X, 
  HeartPulse, 
  ShieldAlert, 
  Clock, 
  ChevronRight,
  MessageCircle
} from "lucide-react";
import { HOSPITAL_INFO } from "../data";
import { dbAPI } from "../utils/db";
import MedicareLogo from "./MedicareLogo";

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onBookClick: () => void;
  onResetPortal?: () => void;
}

export default function Header({ activeTab, setActiveTab, onBookClick, onResetPortal }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [dynInfo, setDynInfo] = useState(() => dbAPI.getHospitalInfo());

  useEffect(() => {
    const refresh = () => setDynInfo(dbAPI.getHospitalInfo());
    window.addEventListener("medicare_db_update", refresh);
    return () => window.removeEventListener("medicare_db_update", refresh);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "Home" },
    { id: "about", label: "About Us" },
    { id: "doctors", label: "Our Doctors" },
    { id: "services", label: "Services" },
    { id: "facilities", label: "Facilities" },
    { id: "gallery", label: "Gallery" },
    { id: "reviews", label: "Reviews" },
    { id: "appointment", label: "Book Appointment" },
    { id: "contact", label: "Contact" },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <header className="w-full relative z-50">
      {/* Top bar with quick contacts */}
      <div className="bg-slate-900 text-slate-300 text-xs py-2 px-4 transition-all duration-300 hidden sm:block">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1.5 text-rose-400 font-medium font-bold animate-pulse">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
              {dynInfo.availability || HOSPITAL_INFO.availability}
            </span>
            <span className="hidden md:inline text-slate-500">|</span>
            <a href={`mailto:${dynInfo.email || HOSPITAL_INFO.email}`} className="hover:text-sky-400 transition-colors flex items-center gap-1 font-semibold">
              Email: {dynInfo.email || HOSPITAL_INFO.email}
            </a>
          </div>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1 text-sky-400 font-bold">
              <Phone className="w-3.5 h-3.5" /> Emergency Hotlines:
            </span>
            {(dynInfo.phones || HOSPITAL_INFO.phones).map((phone) => (
              <a 
                key={phone} 
                href={`tel:${phone}`} 
                className="hover:text-white font-mono tracking-wide text-xs hover:underline transition-all font-semibold"
              >
                +91 {phone}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Main navigation header */}
      <nav 
        className={`w-full transition-all duration-300 ${
          isScrolled 
            ? "sticky top-0 bg-white/95 backdrop-blur-md shadow-md border-b border-slate-100 py-3" 
            : "bg-white border-b border-slate-100 py-4"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-6 flex justify-between items-center">
          {/* Logo element */}
          <button 
            onClick={() => handleNavClick("home")} 
            className="flex items-center gap-2.5 text-left group focus:outline-none"
            id="logo-button"
          >
            <MedicareLogo layout="horizontal" size="sm" hideTagline={true} />
          </button>

          {/* Desktop links */}
          <div className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-2.5 py-1.5 text-xs xl:text-sm font-bold rounded-lg transition-all duration-200 cursor-pointer ${
                  activeTab === item.id 
                    ? item.id === "admin-dashboard"
                      ? "text-rose-700 bg-rose-50 border border-rose-100"
                      : item.id === "patient-portal"
                        ? "text-emerald-700 bg-emerald-50 border border-emerald-100"
                        : "text-sky-600 bg-sky-50" 
                    : item.id === "admin-dashboard"
                      ? "text-slate-500 hover:text-rose-600 hover:bg-rose-50/40"
                      : item.id === "patient-portal"
                        ? "text-slate-500 hover:text-emerald-600 hover:bg-emerald-50/40"
                        : "text-slate-600 hover:text-sky-600 hover:bg-slate-50"
                }`}
                id={`nav-${item.id}`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Right Action buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {onResetPortal && (
              <button
                onClick={onResetPortal}
                className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs uppercase tracking-wide border border-slate-200 transition-all cursor-pointer hover:shadow-sm"
                id="header-switch-portal"
              >
                Switch Portal ⇆
              </button>
            )}
            <a 
              href="https://wa.me/916281573727"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 text-emerald-700 font-semibold text-sm flex items-center gap-2 transition-all font-sans cursor-pointer hover:shadow-sm"
              id="header-whatsapp-cta"
            >
              <MessageCircle className="w-4 h-4 fill-emerald-600 text-white" />
              WhatsApp
            </a>
            <button
              onClick={onBookClick}
              className="px-4 py-2.5 rounded-xl bg-[#0077B6] hover:bg-sky-700 text-white font-bold text-sm tracking-wide shadow-md shadow-sky-200/50 hover:shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              id="header-book-cta"
            >
              Book Slot
            </button>
          </div>

          {/* Mobile menu toggle */}
          <div className="flex lg:hidden items-center gap-2">
            <a 
              href={`tel:${HOSPITAL_INFO.phones[0]}`}
              className="p-2.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-100 block sm:hidden"
            >
              <Phone className="w-5 h-5" />
            </a>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-sky-600 hover:bg-slate-50 border border-slate-100 focus:outline-none"
              id="mobile-menu-toggle"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile slide drawer */}
        {isOpen && (
          <div className="lg:hidden absolute top-auto left-0 w-full bg-white border-b border-slate-100 shadow-xl py-4 px-4 flex flex-col gap-1.5 animate-fadeIn z-40 max-h-[85vh] overflow-y-auto">
            <div className="px-2 py-1 mb-2 bg-rose-50/50 rounded-lg flex items-center gap-2 text-rose-700 text-xs font-semibold sm:hidden">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
              24/7 Emergency Support Available Now
            </div>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold flex items-center justify-between transition-all ${
                  activeTab === item.id 
                    ? "bg-sky-50 text-[#0077B6]" 
                    : "text-slate-700 hover:bg-slate-50 hover:text-[#0077B6]"
                }`}
                id={`mobile-nav-${item.id}`}
              >
                {item.label}
                <ChevronRight className={`w-4 h-4 transition-transform duration-200 ${activeTab === item.id ? "text-sky-600 translate-x-1" : "text-slate-400"}`} />
              </button>
            ))}
            {onResetPortal && (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onResetPortal();
                }}
                className="w-full py-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-center text-xs uppercase tracking-wider border border-slate-200 transition-all cursor-pointer mt-2"
                id="mobile-nav-portal-switcher"
              >
                Switch Portal ⇄
              </button>
            )}
            <div className="grid grid-cols-2 gap-2 mt-2 pt-4 border-t border-slate-100">
              <a 
                href={`tel:${HOSPITAL_INFO.phones[0]}`}
                className="py-3 px-4 rounded-xl bg-rose-50 border border-rose-100 text-rose-700 font-bold text-center text-xs flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" />
                Call Now
              </a>
              <a 
                href="https://wa.me/916281573727"
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-4 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-700 font-bold text-center text-xs flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 fill-emerald-600 text-white" />
                WhatsApp
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
