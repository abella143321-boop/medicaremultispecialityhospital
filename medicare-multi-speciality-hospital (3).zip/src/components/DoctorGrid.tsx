import { 
  Award, 
  Calendar, 
  Stethoscope,
  BriefcaseMedical,
  CheckCircle,
  MessageSquareHeart
} from "lucide-react";
import { Doctor } from "../data";
import { dbAPI, CMSDoctor } from "../utils/db";
import { useState, useEffect } from "react";

interface DoctorGridProps {
  onBookDoctor: (doctorName: string) => void;
  doctorsData?: CMSDoctor[];
}

export default function DoctorGrid({ onBookDoctor, doctorsData }: DoctorGridProps) {
  const [doctorsList, setDoctorsList] = useState<CMSDoctor[]>([]);

  const fetchActiveDoctors = () => {
    if (doctorsData) {
      setDoctorsList(doctorsData);
    } else {
      setDoctorsList(dbAPI.getDoctors().filter(d => d.status === "Active"));
    }
  };

  useEffect(() => {
    fetchActiveDoctors();
    window.addEventListener("medicare_db_update", fetchActiveDoctors);
    return () => window.removeEventListener("medicare_db_update", fetchActiveDoctors);
  }, [doctorsData]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {doctorsList.map((doc) => (
        <div 
          key={doc.id}
          className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
          id={`doctor-card-${doc.id}`}
        >
          <div>
            {/* Doctor Photo Section with specialized badges */}
            <div className="relative overflow-hidden aspect-square sm:aspect-[4/3] md:aspect-square bg-slate-100">
              <img 
                src={doc.photo} 
                alt={doc.name} 
                className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-95" />
              
              {/* Specialized badges on top of image */}
              <div className="absolute top-4 left-4">
                <span className="bg-[#0077B6]/95 text-white px-3 py-1.5 rounded-xl text-xs font-bold shadow-md inline-flex items-center gap-1.5 backdrop-blur-sm">
                  <Stethoscope className="w-3.5 h-3.5" />
                  Specialist
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 text-white">
                <p className="text-[11px] uppercase tracking-wider font-semibold text-sky-400">
                  {doc.specialization}
                </p>
                <h4 className="text-lg font-bold mt-1 tracking-tight drop-shadow-sm/80 leading-snug">
                  {doc.name}
                </h4>
              </div>
            </div>

            {/* Doctor Details info block */}
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 gap-2.5 text-sm">
                
                <div className="flex items-start gap-2 text-slate-700">
                  <Award className="w-4.5 h-4.5 text-[#0077B6] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-slate-400 text-xs font-medium block">Qualifications:</span>
                    <span className="font-semibold text-slate-800 text-xs leading-relaxed">
                      {doc.qualifications}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2 text-slate-700">
                  <BriefcaseMedical className="w-4.5 h-4.5 text-[#0077B6] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-slate-400 text-xs font-medium block">Years of Practice:</span>
                    <span className="font-bold text-slate-800">
                      {doc.experience} Experience
                    </span>
                  </div>
                </div>

              </div>

              {/* Service list or attributes specific to the treatment expertise */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <CheckCircle className="w-4.5 h-4.5" />
                </div>
                <div className="text-xs">
                  <span className="font-bold text-slate-800 block">Patient Recommended</span>
                  <span className="text-slate-500 text-[11px]">Safe treatment adherence</span>
                </div>
              </div>
            </div>
          </div>

          {/* Call to action footer buttons */}
          <div className="p-6 pt-0 border-t border-slate-50 grid grid-cols-1 gap-2.5">
            <button
              onClick={() => onBookDoctor(doc.name)}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all shadow-md shadow-sky-100 group-hover:shadow-lg hover:scale-[1.01]"
              id={`book-doc-btn-${doc.id}`}
            >
              <Calendar className="w-4 h-4" />
              Book Appointment
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
