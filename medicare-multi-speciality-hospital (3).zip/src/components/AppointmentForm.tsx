import React, { useState, useEffect } from "react";
import { 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Mail, 
  MessageSquare,
  Activity,
  HeartPulse,
  HeartHandshake,
  Check,
  ChevronDown,
  PhoneCall,
  MessageCircle,
  CalendarCheck,
  Trash2
} from "lucide-react";
import { HOSPITAL_INFO } from "../data";
import { sendAppointmentEmail, isEmailJsConfigured, ensureConfigured } from "../utils/emailService";
import { dbAPI, CMSDoctor } from "../utils/db";

interface Appointment {
  id: string;
  name: string;
  mobile: string;
  email: string;
  age: string;
  gender: string;
  doctor: string;
  date: string;
  time: string;
  symptoms: string;
  bookingTime: string;
}

interface AppointmentFormProps {
  initialDoctorName?: string;
  onSuccess?: () => void;
}

export default function AppointmentForm({ initialDoctorName, onSuccess }: AppointmentFormProps) {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("Male");
  const [doctor, setDoctor] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [symptoms, setSymptoms] = useState("");
  
  const [submitted, setSubmitted] = useState(false);
  const [myAppointments, setMyAppointments] = useState<Appointment[]>([]);
  
  // EmailJS sending state
  const [emailSending, setEmailSending] = useState(false);
  const [emailStatus, setEmailStatus] = useState<"idle" | "success" | "error" | "unconfigured">("idle");
  const [emailErrorDetail, setEmailErrorDetail] = useState("");
  const [configActive, setConfigActive] = useState(false);

  // Available Time Slots
  const timeSlots = [
    "09:00 AM - 10:00 AM",
    "10:00 AM - 11:00 AM",
    "11:00 AM - 12:00 PM",
    "12:00 PM - 01:00 PM",
    "02:00 PM - 03:00 PM",
    "03:00 PM - 04:00 PM",
    "04:00 PM - 05:00 PM",
    "05:00 PM - 06:00 PM",
    "06:00 PM - 07:00 PM"
  ];

  const [activeDoctors, setActiveDoctors] = useState<CMSDoctor[]>([]);

  // Load doctors and appointments
  const refreshData = () => {
    try {
      const docs = dbAPI.getDoctors().filter(d => d.status === "Active");
      setActiveDoctors(docs);
      
      const stored = dbAPI.getAppointments() as any[];
      setMyAppointments(stored);
      
      if (initialDoctorName) {
        setDoctor(initialDoctorName);
      } else if (docs.length > 0 && !doctor) {
        setDoctor(docs[0].name);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    refreshData();
    window.addEventListener("medicare_db_update", refreshData);
    return () => window.removeEventListener("medicare_db_update", refreshData);
  }, [initialDoctorName]);

  // Dynamically resolve EmailJS credentials
  useEffect(() => {
    ensureConfigured()
      .then((active) => {
        setConfigActive(active);
      })
      .catch(console.error);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !mobile || !doctor || !date || !time) {
      alert("Please fill in all the required fields (Name, Mobile, Doctor, Date, and Time).");
      return;
    }

    // Submit appointment via our CMS dbAPI
    const newBookingRaw = {
      name,
      mobile,
      email: email || "Not provided",
      age: age || "N/A",
      gender,
      doctor,
      date,
      time,
      symptoms: symptoms || "Routine Checkup",
      bookingTime: new Date().toLocaleString()
    };

    const newBooking = dbAPI.addAppointment(newBookingRaw);
    
    // In order to maintain state in the patient's view
    const updated = [newBooking, ...myAppointments];
    setMyAppointments(updated as any[]);

    setSubmitted(true);
    if (onSuccess) onSuccess();

    // Trigger EmailJS sending
    if (configActive || isEmailJsConfigured()) {
      setEmailSending(true);
      setEmailStatus("idle");
      sendAppointmentEmail({
        name: newBooking.name,
        mobile: newBooking.mobile,
        email: newBooking.email,
        age: newBooking.age,
        gender: newBooking.gender,
        doctor: newBooking.doctor,
        date: newBooking.date,
        time: newBooking.time,
        symptoms: newBooking.symptoms,
        bookingTime: newBooking.bookingTime
      })
        .then((result) => {
          setEmailSending(false);
          if (result.success) {
            setEmailStatus("success");
          } else {
            setEmailStatus("error");
            setEmailErrorDetail(result.error || "");
          }
        })
        .catch((err) => {
          setEmailSending(false);
          setEmailStatus("error");
          setEmailErrorDetail(err?.message || String(err));
        });
    } else {
      setEmailStatus("unconfigured");
    }

    // Reset Form
    setName("");
    setMobile("");
    setEmail("");
    setAge("");
    setSymptoms("");
    setDate("");
    setTime("");
  };

  const deleteAppointment = (id: string) => {
    const filtered = myAppointments.filter(app => app.id !== id);
    setMyAppointments(filtered);
    dbAPI.saveAppointments(filtered as any[]);
  };

  // Build dynamic text for WhatsApp Appointment
  const handleWhatsAppBooking = () => {
    const msg = `Hello Medicare Multi Speciality Hospital, I would like to book an appointment with ${doctor || "a Doctor"}.
Patient Details:
- Name: ${name || "(Name)"}
- Mobile: ${mobile || "(Mobile)"}
- Date: ${date || "(Date)"}
- Time Slot: ${time || "(Time)"}
- Symptoms: ${symptoms || "General Consulting"}`;
    
    const waUrl = `https://wa.me/916281573727?text=${encodeURIComponent(msg)}`;
    window.open(waUrl, "_blank");
  };

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Side: Dynamic Form Layout */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-md col-span-1 lg:col-span-7">
          {submitted ? (
            <div className="py-8 text-center space-y-6 animate-pulseOnce">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-100 shadow-sm">
                <Check className="w-8 h-8" strokeWidth={3} />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-slate-800">
                  Appointment Request Received
                </h3>
                <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
                  Thank you. Your appointment request has been received successfully. Our triage officer will dial your mobile number shortly to verify.
                </p>
              </div>

              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100/50 max-w-sm mx-auto text-left space-y-2 text-xs">
                <p className="text-emerald-800 font-bold block subtitle text-center mb-2 text-xs uppercase tracking-wide">
                  Emergency Support Guard
                </p>
                <p className="text-slate-600 leading-relaxed text-center">
                  If this is a trauma case, coronary risk, or major emergency, call our line immediately:
                </p>
                <a 
                  href={`tel:${HOSPITAL_INFO.phones[0]}`}
                  className="font-bold text-rose-600 block text-center text-sm font-mono mt-1 hover:underline"
                >
                  +91 {HOSPITAL_INFO.phones[0]}
                </a>
              </div>

              {/* EmailJS Delivery Status Indicator */}
              <div className="p-4 bg-slate-50/80 rounded-2xl border border-slate-100 max-w-sm mx-auto text-left space-y-2 text-xs">
                <p className="text-slate-755 font-bold block mb-1 text-center text-xs uppercase tracking-wide">
                  📧 EmailJS Notification Status
                </p>
                {emailSending && (
                  <p className="text-blue-600 font-semibold text-center animate-pulse">
                    Connecting to EmailJS server and transmitting payload...
                  </p>
                )}
                {emailStatus === "success" && (
                  <p className="text-emerald-700 font-semibold text-center leading-relaxed">
                    ✔ Notification dispatched successfully to your configured clinic routing inbox.
                  </p>
                )}
                {emailStatus === "error" && (
                  <div className="space-y-1 text-rose-700">
                    <p className="font-bold text-center">✗ Email transmission failed.</p>
                    <p className="text-[10px] text-slate-500 font-mono text-center overflow-x-auto bg-slate-100 p-1.5 rounded">
                      Details: {emailErrorDetail}
                    </p>
                  </div>
                )}
                {emailStatus === "unconfigured" && (
                  <div className="space-y-1 text-slate-600">
                    <p className="text-center font-semibold">ℹ Trigger bypassed (unconfigured).</p>
                    <p className="text-[11px] text-slate-500 text-center leading-relaxed">
                      Configuring <code className="bg-slate-100 px-1 py-0.5 rounded text-rose-600">VITE_EMAILJS_SERVICE_ID</code> and other variables in settings triggers direct notifications on submit!
                    </p>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row justify-center gap-3 pt-4">
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs uppercase tracking-wide transition-all cursor-pointer"
                >
                  Book Another Appointment
                </button>
                <button
                  onClick={handleWhatsAppBooking}
                  className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wide flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                  Confirm on WhatsApp
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="mb-4">
                <div className="flex flex-wrap justify-between items-start gap-2 mb-1.5">
                  <h3 className="text-xl font-extrabold text-slate-800">
                    Secure Your Clinical Consultation Slot
                  </h3>
                  {configActive || isEmailJsConfigured() ? (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      EmailJS Active
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100 flex items-center gap-1" title="To activate real emails, set VITE_EMAILJS environment variables in AI Studio secrets.">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                      Email Alerts: Demo Mode
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  Fill in the required information securely. We do not store health data publicly.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* Patient Name */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Patient Full Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Ramesh Kumar" 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800"
                    />
                  </div>
                </div>

                {/* Patient Mobile */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Mobile Number <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="tel" 
                      required
                      placeholder="e.g. 9876543210" 
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* Patient Email */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Email Address (Optional)
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="email" 
                      placeholder="e.g. ramesh@gmail.com" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800"
                    />
                  </div>
                </div>

                {/* Age & Gender Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 block">
                      Patient Age
                    </label>
                    <input 
                      type="number" 
                      placeholder="e.g. 45" 
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800 font-mono"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 block">
                      Gender
                    </label>
                    <select 
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-3 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Child">Child / Other</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Doctor selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 block">
                  Select Specialist Consultant <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Activity className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <select 
                    required
                    value={doctor}
                    onChange={(e) => setDoctor(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800 font-semibold appearance-none"
                  >
                    {activeDoctors.map((doc) => (
                      <option key={doc.id} value={doc.name}>
                        {doc.name} ({doc.specialization})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                </div>
              </div>

              {/* Slot Scheduling Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Preferred Date <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative font-mono">
                    <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="date" 
                      required
                      min={new Date().toISOString().split("T")[0]}
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 block">
                    Available Time Slot <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <select 
                      required
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800 font-medium"
                    >
                      <option value="">-- Choose Slot --</option>
                      {timeSlots.map((slot) => (
                        <option key={slot} value={slot}>
                          {slot}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Symptoms / Notes */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 block">
                  Describe Symptoms or Notes (Optional)
                </label>
                <div className="relative">
                  <MessageSquare className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <textarea 
                    rows={3}
                    placeholder="e.g. Persistent stomach ache, fever since last 2 days etc." 
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all text-slate-800 resize-none"
                  />
                </div>
              </div>

              {/* Submit CTA block */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-4 px-6 rounded-xl bg-[#0077B6] hover:bg-sky-700 text-white font-extrabold text-sm tracking-widest uppercase shadow-md shadow-sky-200 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer"
                  id="book-appointment-button"
                >
                  BOOK APPOINTMENT
                </button>
              </div>

              {/* External booking helpers */}
              <div className="border-t border-slate-100 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
                <button 
                  type="button" 
                  onClick={handleWhatsAppBooking}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-800 font-bold text-xs uppercase flex items-center justify-center gap-2 hover:bg-emerald-100 transition-all cursor-pointer"
                  id="appointment-whatsapp-alt"
                >
                  <MessageCircle className="w-4 h-4 fill-emerald-600 text-white" />
                  Quick WhatsApp Request
                </button>
                <a 
                  href={`tel:${HOSPITAL_INFO.phones[0]}`}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-rose-200 bg-rose-50 text-rose-800 font-bold text-xs uppercase flex items-center justify-center gap-2 hover:bg-rose-100 transition-all"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  Call Administrative Desk
                </a>
              </div>
            </form>
          )}
        </div>

        {/* Right Side: Hospital Care details & Locally Tracked Appointments */}
        <div className="space-y-6 col-span-1 lg:col-span-5">
          
          {/* Quick Stats Support card */}
          <div className="bg-gradient-to-tr from-sky-900 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 space-y-4 shadow-lg">
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-sky-300">
              <HeartPulse className="w-6 h-6 animate-pulse" />
            </div>
            <div className="space-y-2">
              <h4 className="font-extrabold text-xl tracking-tight text-white leading-tight">
                Responsive Patient Triaging Group
              </h4>
              <p className="text-xs text-sky-200/80 leading-relaxed">
                When you initiate a digital appointment booking slot, our dedicated receptionist cross-verifies clinic charts, coordinates schedules with the selected specialist, and completes confirmation in less than 30 minutes. Let us know if you need prioritised help.
              </p>
            </div>
            <div className="pt-2 text-xs text-indigo-200 font-bold flex items-center gap-2 border-t border-sky-800">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping inline-block" />
              Administrative desks online for coordination
            </div>
          </div>

          {/* Saved Slot Tracker */}
          <div className="bg-slate-50 border border-slate-100 rounded-3xl p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h4 className="text-slate-800 font-bold text-sm tracking-tight flex items-center gap-2">
                <CalendarCheck className="w-4.5 h-4.5 text-sky-600" />
                Your Booked Slots ({myAppointments.length})
              </h4>
              {myAppointments.length > 0 && (
                <button 
                  onClick={() => {
                    if(confirm("Do you want to clear your local appointment history?")) {
                      setMyAppointments([]);
                      localStorage.removeItem("medicare_appointments");
                    }
                  }}
                  className="text-[10px] text-rose-600 hover:underline font-bold"
                >
                  Clear All
                </button>
              )}
            </div>

            {myAppointments.length === 0 ? (
              <div className="text-center py-10 bg-white rounded-2xl border border-slate-100 p-4 space-y-2">
                <p className="text-xs text-slate-400 font-semibold">No recent clinical bookings tracked in this browser session.</p>
                <p className="text-[10px] text-slate-400">Newly registered appointments will appear here instantly with full status options.</p>
              </div>
            ) : (
              <div className="space-y-3.5 max-h-[360px] overflow-y-auto pr-1">
                {myAppointments.map((app) => (
                  <div 
                    key={app.id} 
                    className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-start group relative transition-all hover:border-sky-100"
                  >
                    <div className="space-y-1.5 text-xs">
                      <div className="font-bold text-slate-800 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        {app.name} 
                        <span className="text-[10px] font-normal text-slate-400">({app.age} yrs, {app.gender})</span>
                      </div>
                      <p className="text-slate-500 font-medium">
                        Doctor: <span className="font-bold text-sky-700">{app.doctor}</span>
                      </p>
                      <div className="flex gap-4 font-mono text-[10px] text-slate-400 font-bold pt-1">
                        <span className="text-slate-600">{app.date}</span>
                        <span className="text-slate-600">{app.time}</span>
                      </div>
                      <div className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded inline-block mt-1">
                        Status: Pending Desk Verification
                      </div>
                    </div>
                    <button 
                      onClick={() => deleteAppointment(app.id)}
                      className="p-1.5 rounded-lg bg-slate-50 text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Cancel request"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
