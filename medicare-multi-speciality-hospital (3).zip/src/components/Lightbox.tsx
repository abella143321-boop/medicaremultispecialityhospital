import { useEffect } from "react";
import { X, ChevronLeft, ChevronRight, ZoomIn, Download, ExternalLink } from "lucide-react";

interface LightboxItem {
  id: string;
  title: string;
  category: string;
  url: string;
}

interface LightboxProps {
  items: LightboxItem[];
  currentIndex: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export default function Lightbox({ items, currentIndex, onClose, onPrev, onNext }: LightboxProps) {
  const activeItem = items[currentIndex];

  // Key listening for navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose, onPrev, onNext]);

  if (!activeItem) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-50 flex flex-col justify-between p-4 sm:p-6 animate-fadeIn">
      
      {/* Lightbox Header with actions */}
      <div className="flex justify-between items-center text-white z-10 py-2 border-b border-white/5">
        <div className="text-left space-y-0.5">
          <span className="text-[10px] font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded font-mono uppercase tracking-wider">
            {activeItem.category}
          </span>
          <h4 className="text-xs sm:text-sm font-bold tracking-tight text-white/90">
            {activeItem.title}
          </h4>
        </div>

        <div className="flex items-center gap-2">
          {/* Zoom guide or placeholder interaction */}
          <span className="text-xs text-slate-500 font-mono hidden md:inline-block pr-2">
            Image {currentIndex + 1} of {items.length}
          </span>
          <a
            href={activeItem.url}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-all flex items-center justify-center"
            title="Open original image"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-white/5 hover:bg-rose-500 hover:text-white text-white/85 transition-all flex items-center justify-center cursor-pointer"
            title="Close Lightbox"
            id="lightbox-close-btn"
          >
            <X className="w-5 h-5" strokeWidth={2.5} />
          </button>
        </div>
      </div>

      {/* Lightbox Center Area with navigation controls and the image */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 max-h-[85vh]">
        
        {/* Previous Button link */}
        <button
          onClick={onPrev}
          className="absolute left-2 sm:left-4 p-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white hover:text-sky-400 transition-all cursor-pointer z-20 max-w-[50px] inline-flex items-center justify-center"
          title="Previous Image"
          id="lightbox-prev-btn"
        >
          <ChevronLeft className="w-7 h-7" strokeWidth={2.5} />
        </button>

        {/* Enhanced high res image element with referrerPolicy constraints */}
        <div className="relative group max-w-full max-h-full overflow-hidden rounded-2xl border border-white/10 shadow-2xl flex items-center justify-center">
          <img
            src={activeItem.url}
            alt={activeItem.title}
            className="max-w-full max-h-[75vh] object-contain transform hover:scale-[1.02] transition-transform duration-500 rounded-lg select-none"
            referrerPolicy="no-referrer"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none flex items-end justify-center pb-4">
            <span className="text-[10px] text-white/80 bg-slate-900/80 px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm">
              <ZoomIn className="w-3 h-3 text-sky-400" />
              Hover to enlarge
            </span>
          </div>
        </div>

        {/* Next Button link */}
        <button
          onClick={onNext}
          className="absolute right-2 sm:right-4 p-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white hover:text-sky-400 transition-all cursor-pointer z-20 max-w-[50px] inline-flex items-center justify-center"
          title="Next Image"
          id="lightbox-next-btn"
        >
          <ChevronRight className="w-7 h-7" strokeWidth={2.5} />
        </button>

      </div>

      {/* Lightbox footer metadata */}
      <div className="text-center text-xs text-slate-500 py-3 border-t border-white/5">
        <p className="font-mono">Use Left/Right vector arrows to scroll, ESC to cancel lightbox</p>
      </div>

    </div>
  );
}
