import React from "react";
import { 
  HeartPulse, 
  Users, 
  ShieldCheck, 
  ArrowRight, 
  Clock, 
  Siren, 
  PhoneCall, 
  Activity,
  MapPin,
  Sparkles
} from "lucide-react";
import { motion } from "motion/react";
import MedicareLogo from "./MedicareLogo";

interface RoleSelectionLandingProps {
  onSelectRole: (role: "patient" | "admin") => void;
}

export default function RoleSelectionLanding({ onSelectRole }: RoleSelectionLandingProps) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between relative overflow-hidden" id="role-selection-screen">
      
      {/* Decorative premium medical background overlays */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-[0.04]">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-[#529E1A] blur-3xl" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-[#BE1212] blur-3xl" />
      </div>

      {/* Grid line style background */}
      <div className="absolute inset-0 bg-grid-pattern z-0 opacity-15 pointer-events-none" />

      {/* Header Bar */}
      <header className="relative z-10 w-full bg-white border-b border-slate-100 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          
          {/* Hospital Brand using the official high-fidelity logo */}
          <MedicareLogo layout="horizontal" size="sm" />

          {/* 24/7 Emergency Line Badge */}
          <div className="flex items-center gap-2 bg-rose-50 border border-rose-100 px-3 py-1.5 rounded-full text-[#BE1212] font-bold text-xs shadow-sm">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#BE1212] animate-pulse" />
            <Siren className="w-3.5 h-3.5 text-[#BE1212]" />
            <span>24/7 EMERGENCY ICU: 9966700911</span>
          </div>

        </div>
      </header>

      {/* Main Content Body */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 md:px-6 py-12 max-w-5xl mx-auto w-full">
        
        {/* Welcome Block with official brand centered and premium tagline */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center space-y-4 mb-12 max-w-2xl"
          id="gateway-welcome-header"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-bold uppercase tracking-wider rounded-full border border-emerald-100">
            <Activity className="w-3 h-3 text-[#529E1A] animate-pulse" />
            Vijayawada’s Premier Healthcare Institution
          </div>

          <div className="flex flex-col items-center justify-center py-4 bg-white/40 backdrop-blur-md rounded-3xl border border-white/60 p-6 shadow-inner">
            <MedicareLogo layout="vertical" size="xl" />
          </div>

          <p className="text-sm text-slate-600 leading-relaxed pt-2 font-medium">
            Welcome to Medicare Multi Speciality Hospital. Please select your portal to continue. Authorized administrators can update schedules, doctors, facilities, and CMS, while patients can book consultations or view diagnostic reports.
          </p>
        </motion.div>

        {/* Portal Options Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
          
          {/* Card 1: Patient Portal Option */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="bg-white rounded-3xl border border-slate-100 p-8 shadow-lg hover:shadow-xl hover:border-[#529E1A]/30 transition-all duration-300 flex flex-col justify-between group cursor-pointer relative overflow-hidden"
            onClick={() => onSelectRole("patient")}
            id="portal-card-patient"
          >
            {/* Visual background gradient hover glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#529E1A]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
            
            <div className="space-y-6 relative z-10">
              {/* Icon Container with brand green tone */}
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-[#529E1A] flex items-center justify-center shadow-inner group-hover:scale-110 group-hover:bg-[#529E1A] group-hover:text-white transition-all duration-300">
                <Users className="w-7 h-7" />
              </div>

              {/* Title & Description */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold text-slate-800 group-hover:text-[#529E1A] transition-colors">
                    🏥 PATIENT PORTAL
                  </h3>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-[#529E1A] px-2 py-0.5 rounded-full border border-emerald-100">
                    Public Access
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                  Book direct physical consultations or online appointments, find specialist doctors, view available medical testing facilities, submit reviews, and read our patient manuals.
                </p>
              </div>
            </div>

            {/* CTA Button */}
            <div className="mt-8 pt-4 border-t border-slate-50 relative z-10 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 group-hover:text-[#529E1A]/80 transition-colors">
                Explore Medicare Services
              </span>
              <button 
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-50 text-[#529E1A] font-bold text-xs uppercase tracking-wider group-hover:bg-[#529E1A] group-hover:text-white transition-all duration-300 shadow-sm"
                id="enter-patient-portal-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectRole("patient");
                }}
              >
                Enter Patient Portal
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>

          {/* Card 2: Admin CMS Option */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white rounded-3xl border border-slate-100 p-8 shadow-lg hover:shadow-xl hover:border-[#BE1212]/30 transition-all duration-300 flex flex-col justify-between group cursor-pointer relative overflow-hidden"
            onClick={() => onSelectRole("admin")}
            id="portal-card-admin"
          >
            {/* Visual background gradient hover glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#BE1212]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
            
            <div className="space-y-6 relative z-10">
              {/* Icon Container with brand red tone */}
              <div className="w-14 h-14 rounded-2xl bg-rose-50 text-[#BE1212] flex items-center justify-center shadow-inner group-hover:scale-110 group-hover:bg-[#BE1212] group-hover:text-white transition-all duration-300">
                <ShieldCheck className="w-7 h-7" />
              </div>

              {/* Title & Description */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold text-slate-800 group-hover:text-[#BE1212] transition-colors">
                    🔐 ADMIN CMS
                  </h3>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-[#BE1212] px-2 py-0.5 rounded-full border border-rose-100">
                    Restricted Staff
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                  Authorized hospital staff can securely sign in to update doctor lists, manage active schedules, moderate patient ratings, update gallery images, and adjust clinical offerings.
                </p>
              </div>
            </div>

            {/* CTA Button */}
            <div className="mt-8 pt-4 border-t border-slate-50 relative z-10 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 group-hover:text-[#BE1212]/80 transition-colors">
                Authorized Personnel Only
              </span>
              <button 
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-50 text-[#BE1212] font-bold text-xs uppercase tracking-wider group-hover:bg-[#BE1212] group-hover:text-white transition-all duration-300 shadow-sm"
                id="enter-admin-portal-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectRole("admin");
                }}
              >
                Admin Login
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>

        </div>

      </main>

      {/* Elegant Grounded Footer */}
      <footer className="relative z-10 bg-white border-t border-slate-100 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#529E1A]" />
            <span>Suryaraopet, Vijayawada, Andhra Pradesh - 520002</span>
          </div>
          <div>
            &copy; {new Date().getFullYear()} Medicare Multi Speciality Hospital. All rights reserved.
          </div>
        </div>
      </footer>

    </div>
  );
}
