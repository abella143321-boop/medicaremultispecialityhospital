import React, { useState, useEffect } from "react";
import { 
  Users, 
  Stethoscope, 
  Settings as SettingsIcon, 
  Calendar, 
  Image as ImageIcon, 
  Star, 
  HeartPulse, 
  ShieldAlert, 
  Building2, 
  Plus, 
  Edit, 
  Trash2, 
  Check, 
  X, 
  Search, 
  Download, 
  Filter, 
  Mail, 
  Phone, 
  ExternalLink,
  Lock,
  ChevronRight,
  Sparkles,
  Award,
  BookOpen,
  MessageSquare,
  Volume2,
  LockKeyhole,
  LockKeyholeOpen,
  Send,
  Sliders,
  CheckCircle,
  FileSpreadsheet,
  Loader2
} from "lucide-react";
import { 
  dbAPI, 
  CMSDoctor, 
  CMSService, 
  CMSReview, 
  CMSHospitalInfo, 
  CMSAppointment, 
  CMSPatientUser, 
  CMSSettings 
} from "../utils/db";
import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { auth } from "../utils/firebase";
import MedicareLogo from "./MedicareLogo";

export default function AdminDashboard() {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminUsername, setAdminUsername] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Sidebar navigation tab
  const [activeAdminTab, setActiveAdminTab] = useState<
    "appointments" | "doctors" | "services" | "hospital" | "gallery" | "reviews" | "users" | "notifications" | "settings"
  >("appointments");

  // CMS Collections State
  const [appointments, setAppointments] = useState<CMSAppointment[]>([]);
  const [doctors, setDoctors] = useState<CMSDoctor[]>([]);
  const [services, setServices] = useState<CMSService[]>([]);
  const [hospitalInfo, setHospitalInfo] = useState<CMSHospitalInfo | null>(null);
  const [gallery, setGallery] = useState<any[]>([]);
  const [reviews, setReviews] = useState<CMSReview[]>([]);
  const [users, setUsers] = useState<CMSPatientUser[]>([]);
  const [settings, setSettings] = useState<CMSSettings | null>(null);

  // Search & Filters State
  const [aptSearch, setAptSearch] = useState("");
  const [aptDoctorFilter, setAptDoctorFilter] = useState("");
  const [aptDateFilter, setAptDateFilter] = useState("");

  // Edit Modals & Forms State
  const [activeDoctorForm, setActiveDoctorForm] = useState<Partial<CMSDoctor> | null>(null);
  const [activeServiceForm, setActiveServiceForm] = useState<Partial<CMSService> | null>(null);
  const [activeGalleryForm, setActiveGalleryForm] = useState<{ id?: string, title: string, category: string, url: string } | null>(null);

  // Broadcaster State
  const [broadcastTarget, setBroadcastTarget] = useState<"all" | "pending" | "confirmed">("all");
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // Image upload compression helper (Base64)
  const [imageCompressing, setImageCompressing] = useState(false);

  // Sync state from storage
  const syncCMSCollections = () => {
    setAppointments(dbAPI.getAppointments());
    setDoctors(dbAPI.getDoctors());
    setServices(dbAPI.getServices());
    setHospitalInfo(dbAPI.getHospitalInfo());
    setGallery(dbAPI.getGallery());
    setReviews(dbAPI.getReviews());
    setUsers(dbAPI.getUsers());
    setSettings(dbAPI.getSettings());
  };

  useEffect(() => {
    syncCMSCollections();
    // Check if session exists
    const adminSessionToken = localStorage.getItem("medicare_admin_session");
    const isAuth = adminSessionToken === "authorized";
    
    if (isAuth) {
      setIsAdminLoggedIn(true);
      // Ensure path says /admin-dashboard when logged in
      if (window.location.pathname === "/admin" || window.location.hash === "#admin") {
        window.history.pushState({}, "", "/admin-dashboard");
      }
    } else {
      setIsAdminLoggedIn(false);
      // Redirect unauthorized users to login page (/admin or #admin)
      if (window.location.pathname === "/admin-dashboard") {
        window.history.pushState({}, "", "/admin");
      } else if (window.location.hash === "#admin-dashboard") {
        window.location.hash = "#admin";
      }
    }

    // Connect update listener
    window.addEventListener("medicare_db_update", syncCMSCollections);
    
    // Auth state observer of Google Sign-in to automatically restore sessions
    const unsub = auth.onAuthStateChanged((user) => {
      if (user && user.email === "sandeep.24mic7005@vitapstudent.ac.in") {
        setIsAdminLoggedIn(true);
        localStorage.setItem("medicare_admin_session", "authorized");
        if (window.location.pathname === "/admin" || window.location.hash === "#admin") {
          window.history.pushState({}, "", "/admin-dashboard");
        }
      }
    });

    return () => {
      window.removeEventListener("medicare_db_update", syncCMSCollections);
      unsub();
    };
  }, []);

  // Handle Admin Authorization securely via backend
  const handleAdminAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setIsLoggingIn(true);

    try {
      const res = await fetch("/api/admin-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: adminUsername, password: adminPassword })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setIsAdminLoggedIn(true);
        localStorage.setItem("medicare_admin_session", "authorized");
        // Redirect to /admin-dashboard upon successful login
        if (window.location.pathname === "/admin") {
          window.history.pushState({}, "", "/admin-dashboard");
        } else if (window.location.hash === "#admin") {
          window.location.hash = "#admin-dashboard";
        }
      } else {
        // Requirement 8: If login fails, show: "Invalid username or password."
        setLoginError(data.error || "Invalid username or password.");
      }
    } catch (err) {
      console.error(err);
      setLoginError("Connection failed. Please check network/server availability.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoginError("");
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result.user.email === "sandeep.24mic7005@vitapstudent.ac.in") {
        setIsAdminLoggedIn(true);
        localStorage.setItem("medicare_admin_session", "authorized");
      } else {
        setLoginError(`Access Denied: ${result.user.email} is not authorized for administration.`);
        await auth.signOut();
      }
    } catch (err: any) {
      console.error(err);
      setLoginError(err.message || "An error occurred during Google sign-in.");
    }
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    localStorage.removeItem("medicare_admin_session");
    auth.signOut().catch(console.error);
    // Redirect unauthenticated user to login page (/admin or #admin)
    if (window.location.pathname === "/admin-dashboard") {
      window.history.pushState({}, "", "/admin");
    } else if (window.location.hash === "#admin-dashboard") {
      window.location.hash = "#admin";
    }
  };

  // Image to Compact Base64 with Canvas Compression
  const handlePhotoUploadChange = (e: React.ChangeEvent<HTMLInputElement>, callback: (url: string) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageCompressing(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 400;
        const scaleSize = MAX_WIDTH / img.width;
        canvas.width = MAX_WIDTH;
        canvas.height = img.height * scaleSize;

        const ctx = canvas.getContext("2d");
        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);

        // Compress and encode
        const compressedBase64 = canvas.toDataURL("image/jpeg", 0.7);
        callback(compressedBase64);
        setImageCompressing(false);
      };
    };
    reader.readAsDataURL(file);
  };

  // ================= 1. DOCTOR MANAGEMENT MODULE =================
  const handleSaveDoctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDoctorForm?.name || !activeDoctorForm.specialization) return;

    const list = [...doctors];
    if (activeDoctorForm.id) {
      // Edit
      const idx = list.findIndex(d => d.id === activeDoctorForm.id);
      if (idx !== -1) {
        list[idx] = { ...list[idx], ...activeDoctorForm } as CMSDoctor;
      }
    } else {
      // Add
      const newDoc: CMSDoctor = {
        id: "doc_" + Math.random().toString(36).substr(2, 9),
        name: activeDoctorForm.name,
        qualifications: activeDoctorForm.qualifications || "MBBS",
        specialization: activeDoctorForm.specialization,
        experience: activeDoctorForm.experience || "5+ Years",
        photo: activeDoctorForm.photo || "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=400&h=400",
        timings: activeDoctorForm.timings || "09:00 AM - 05:00 PM",
        description: activeDoctorForm.description || "Experienced medical consultant.",
        status: activeDoctorForm.status || "Active"
      };
      list.push(newDoc);
    }

    dbAPI.saveDoctors(list);
    setActiveDoctorForm(null);
  };

  const handleDeleteDoctor = (id: string) => {
    if (confirm("Are you sure you want to delete this doctor? This cannot be undone.")) {
      const list = doctors.filter(d => d.id !== id);
      dbAPI.saveDoctors(list);
    }
  };

  // ================= 2. SERVICES CMS MODULE =================
  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeServiceForm?.title || !activeServiceForm.description) return;

    const list = [...services];
    if (activeServiceForm.id) {
      const idx = list.findIndex(s => s.id === activeServiceForm.id);
      if (idx !== -1) {
        list[idx] = { ...list[idx], ...activeServiceForm } as CMSService;
      }
    } else {
      const newSer: CMSService = {
        id: "ser_" + Math.random().toString(36).substr(2, 9),
        title: activeServiceForm.title,
        description: activeServiceForm.description,
        iconName: activeServiceForm.iconName || "Stethoscope"
      };
      list.push(newSer);
    }
    dbAPI.saveServices(list);
    setActiveServiceForm(null);
  };

  const handleDeleteService = (id: string) => {
    if (confirm("Are you sure you want to remove this service department?")) {
      dbAPI.saveServices(services.filter(s => s.id !== id));
    }
  };

  // ================= 3. HOSPITAL CLINIC CONFIG MODULE =================
  const handleUpdateHospital = (e: React.FormEvent) => {
    e.preventDefault();
    if (hospitalInfo) {
      dbAPI.saveHospitalInfo(hospitalInfo);
      alert("Hospital metadata updated instantly!");
    }
  };

  // ================= 4. GALLERY ALBUMS MODULE =================
  const handleSaveGallery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGalleryForm?.title || !activeGalleryForm.url) return;

    const list = [...gallery];
    if (activeGalleryForm.id) {
      const idx = list.findIndex(g => g.id === activeGalleryForm.id);
      if (idx !== -1) list[idx] = activeGalleryForm;
    } else {
      list.push({
        id: "gal_" + Math.random().toString(36).substr(2, 9),
        ...activeGalleryForm
      });
    }
    dbAPI.saveGallery(list);
    setActiveGalleryForm(null);
  };

  const handleDeleteGallery = (id: string) => {
    if (confirm("Remove image from albums?")) {
      dbAPI.saveGallery(gallery.filter(g => g.id !== id));
    }
  };

  // ================= 5. REVIEWS CMS MODULE =================
  const handleToggleReviewStatus = (id: string, status: "Approved" | "Rejected") => {
    const list = reviews.map(r => {
      if (r.id === id) {
        return { ...r, status };
      }
      return r;
    });
    dbAPI.saveReviews(list);
  };

  const handleToggleReviewFeatured = (id: string) => {
    const list = reviews.map(r => {
      if (r.id === id) {
        return { ...r, featured: !r.featured };
      }
      return r;
    });
    dbAPI.saveReviews(list);
  };

  const handleDeleteReview = (id: string) => {
    if (confirm("Delete this patient review?")) {
      dbAPI.saveReviews(reviews.filter(r => r.id !== id));
    }
  };

  // ================= 6. APPOINTMENT CRM MODULE =================
  const handleUpdateAppointmentStatus = (id: string, status: CMSAppointment["status"]) => {
    const list = appointments.map(app => {
      if (app.id === id) {
        // Trigger simulation printout of EmailJS payload parameters on status modifications
        console.log(`[EmailJS Trigger/Notify] Status transition details for ${app.id}:`, {
          patientName: app.name,
          emailAddress: app.email,
          newStatus: status,
          notificationAlert: `Dear ${app.name}, your medical slot status with ${app.doctor} was updated to: ${status}.`
        });

        return { 
          ...app, 
          status,
          notifications: { 
            ...app.notifications, 
            emailSent: app.email !== "Not provided" ? true : false,
            whatsappSent: true 
          }
        };
      }
      return app;
    });
    dbAPI.saveAppointments(list);
  };

  // Trigger CRM direct WhatsApp ping
  const handleDirectWhatsAppAlert = (app: CMSAppointment) => {
    const msg = `Dear ${app.name}, your Medicare Hospital appointment with ${app.doctor} has been flagged as *${app.status}*. Time slot: ${app.date} @ ${app.time}. Wish you a speedy wellness recovery.`;
    const wUrl = `https://wa.me/91${app.mobile}?text=${encodeURIComponent(msg)}`;
    window.open(wUrl, "_blank");
  };

  // Export Appointments to CSV/Excel Format
  const handleExportAppointments = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "ID,Patient Name,Mobile,Email,Age,Gender,Doctor,Preferred Date,Time Slot,Symptoms,Booking Status,Record Date\r\n";
    
    appointments.forEach(a => {
      const row = [
        a.id,
        `"${a.name.replace(/"/g, '""')}"`,
        a.mobile,
        a.email,
        a.age,
        a.gender,
        `"${a.doctor.replace(/"/g, '""')}"`,
        a.date,
        a.time,
        `"${a.symptoms.replace(/"/g, '""')}"`,
        a.status,
        a.bookingTime
      ].join(",");
      csvContent += row + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Medicare_Appointments_Roster_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // ================= 7. PATIENT USER MANAGEMENT MODULE =================
  const handleToggleUserBlocked = (uid: string) => {
    const list = users.map(u => {
      if (u.uid === uid) {
        return { ...u, blocked: !u.blocked };
      }
      return u;
    });
    dbAPI.saveUsers(list);
  };

  const handleDeleteUser = (uid: string) => {
    if (confirm("Permanently delete this registered user profile?")) {
      dbAPI.saveUsers(users.filter(u => u.uid !== uid));
    }
  };

  const handleResetUserPassword = (uid: string) => {
    const list = users.map(u => {
      if (u.uid === uid) {
        const newPassword = "DefaultTemp" + Math.floor(1000 + Math.random() * 9000);
        alert(`Password for ${u.name} reset to: ${newPassword}\nPlease communicate this to the patient!`);
        return { ...u, password: newPassword };
      }
      return u;
    });
    dbAPI.saveUsers(list);
  };

  // ================= 8. BROADCAST MESSAGE MODULE =================
  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) return;

    // Save broadcast text into affected appointments matching criteria
    const list = appointments.map(app => {
      const matchCriteria = 
        broadcastTarget === "all" || 
        (broadcastTarget === "pending" && app.status === "Pending") ||
        (broadcastTarget === "confirmed" && app.status === "Confirmed");

      if (matchCriteria) {
        return {
          ...app,
          notifications: {
            ...app.notifications,
            broadcast: broadcastMessage
          }
        };
      }
      return app;
    });

    dbAPI.saveAppointments(list);
    setBroadcastSuccess(true);
    setBroadcastMessage("");
    setTimeout(() => setBroadcastSuccess(false), 3000);
  };

  // ================= 9. PLATFORM GLOBAL SETTINGS MODULE =================
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (settings) {
      dbAPI.saveSettings(settings);
      alert("Platform settings saved instantly!");
    }
  };

  // Filter Appointments List based on Search & Selections
  const filteredAppointments = appointments.filter(a => {
    const matchSearch = 
      a.name.toLowerCase().includes(aptSearch.toLowerCase()) ||
      a.mobile.includes(aptSearch) ||
      a.doctor.toLowerCase().includes(aptSearch.toLowerCase());
    
    const matchDoctor = !aptDoctorFilter || a.doctor === aptDoctorFilter;
    const matchDate = !aptDateFilter || a.date === aptDateFilter;

    return matchSearch && matchDoctor && matchDate;
  });

  return (
    <div className="min-h-[80vh] flex flex-col font-sans" id="admin-module-root">
      
      {!isAdminLoggedIn ? (
        // ================= 1. SECURE ADMIN SIGN IN GATEWAY =================
        <div className="max-w-md mx-auto my-12 bg-white p-8 rounded-3xl border border-slate-100 shadow-xl space-y-6 flex flex-col items-center" id="admin-auth-card">
          <div className="flex flex-col items-center justify-center pb-4 border-b border-slate-100 w-full">
            <MedicareLogo layout="vertical" size="md" />
          </div>

          <div className="text-center space-y-2 w-full">
            <span className="bg-rose-50 text-[#BE1212] px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider inline-block border border-rose-100">
              Clinical Security Vault
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-800 tracking-tight">
              Hospital Admin Login
            </h3>
            <p className="text-xs text-slate-400">
              Only authorized hospital personnel are allowed to access back-office CMS tools.
            </p>
          </div>

          <form onSubmit={handleAdminAuthSubmit} className="space-y-4">
            {loginError && (
              <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-100 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                {loginError}
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 block">System Username / Email</label>
              <input 
                type="text" 
                required
                placeholder="Enter username or email" 
                value={adminUsername}
                onChange={(e) => setAdminUsername(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800 font-medium"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600 block">Security Password</label>
              <input 
                type="password" 
                required
                placeholder="••••••••" 
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3 rounded-xl bg-slate-900 hover:bg-sky-700 text-white font-bold text-xs tracking-wider uppercase shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-55"
              id="admin-login-submit"
            >
              {isLoggingIn ? (
                <>
                  <Loader2 className="w-4.5 h-4.5 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Sign In To CMS"
              )}
            </button>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-4 text-slate-400 text-[10px] font-bold uppercase tracking-wider">or secure with</span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="w-full py-3 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
              id="admin-google-login-btn"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.08H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.92l2.85-2.22.81-.6z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.08l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              Sign In with Google
            </button>
          </form>
        </div>
      ) : (
        // ================= 2. MASTER HOSPITAL ADMINISTRATION PANEL =================
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 my-4" id="admin-dashboard-container">
          
          {/* Quick CMS Control Dock (Sidebar) */}
          <div className="lg:col-span-1 bg-white p-5 rounded-3xl border border-slate-100 shadow-md h-fit space-y-4">
            <div className="flex flex-col items-start gap-1 pb-3 mb-2 border-b border-slate-100">
              <MedicareLogo layout="horizontal" size="xs" hideTagline={true} />
              <p className="text-[10px] text-slate-400 font-semibold leading-tight mt-1">CMS Control Terminal v2.1</p>
            </div>

            <div className="flex flex-col gap-1">
              {[
                { id: "appointments", label: "Appointments", icon: <Calendar className="w-4 h-4" /> },
                { id: "doctors", label: "Doctors CMS", icon: <Stethoscope className="w-4 h-4" /> },
                { id: "services", label: "Departments", icon: <Volume2 className="w-4 h-4" /> },
                { id: "hospital", label: "Hospital Profile", icon: <Building2 className="w-4 h-4" /> },
                { id: "gallery", label: "Gallery Albums", icon: <ImageIcon className="w-4 h-4" /> },
                { id: "reviews", label: "Patient Reviews", icon: <Star className="w-4 h-4" /> },
                { id: "users", label: "Registered CRM", icon: <Users className="w-4 h-4" /> },
                { id: "notifications", label: "Broadcast Hub", icon: <Send className="w-4 h-4" /> },
                { id: "settings", label: "Global Settings", icon: <SettingsIcon className="w-4 h-4" /> }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveAdminTab(item.id as any);
                    setActiveDoctorForm(null);
                    setActiveServiceForm(null);
                    setActiveGalleryForm(null);
                  }}
                  className={`w-full text-left px-3.5 py-3 rounded-xl text-xs font-bold leading-tight flex items-center justify-between transition-all cursor-pointer ${
                    activeAdminTab === item.id 
                      ? "bg-slate-900 text-white shadow-sm" 
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  }`}
                  id={`admin-tab-btn-${item.id}`}
                >
                  <span className="flex items-center gap-2">{item.icon} {item.label}</span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                </button>
              ))}
            </div>

            <button
              onClick={handleAdminLogout}
              className="w-full mt-4 py-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-100 text-rose-700 font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              Sign Out Securely
            </button>
          </div>

          {/* Core Modular Workstations (Body Module) */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* 6.1 APPOINTMENTS BOARD WORKSTATION */}
            {activeAdminTab === "appointments" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-appointments-workstation">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <h3 className="text-lg font-black text-slate-800 tracking-tight">Clinical Slot Appointments</h3>
                    <p className="text-xs text-slate-400">Search, filter, allocate clinical staff, and update diagnostic checkup queues.</p>
                  </div>
                  <button
                    onClick={handleExportAppointments}
                    className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs rounded-xl flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    Export to Excel
                  </button>
                </div>

                {/* Filter Roster */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search patient or doctor..." 
                      value={aptSearch}
                      onChange={(e) => setAptSearch(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-9 pr-3 text-xs focus:outline-none focus:border-sky-500 font-medium text-slate-800"
                    />
                  </div>

                  <select
                    value={aptDoctorFilter}
                    onChange={(e) => setAptDoctorFilter(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-xs focus:outline-none focus:border-sky-500 font-medium text-slate-600"
                  >
                    <option value="">All Clinical Doctors</option>
                    {doctors.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                  </select>

                  <input 
                    type="date" 
                    value={aptDateFilter}
                    onChange={(e) => setAptDateFilter(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-xs focus:outline-none focus:border-sky-500 font-medium text-slate-600 font-mono"
                  />
                </div>

                {/* Database Table layout */}
                <div className="overflow-x-auto border border-slate-100 rounded-2xl bg-white shadow-sm">
                  <table className="w-full text-left text-xs text-slate-600 border-collapse">
                    <thead className="bg-slate-50 text-slate-400 uppercase font-black tracking-wider text-[10px] border-b border-slate-100">
                      <tr>
                        <th className="py-3 px-4 font-bold">Patient / Contact</th>
                        <th className="py-3 px-4 font-bold">Roster Rationale</th>
                        <th className="py-3 px-4 font-bold">Details</th>
                        <th className="py-3 px-4 font-bold">Booking Status</th>
                        <th className="py-3 px-4 font-bold text-center">Interventions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50 font-medium">
                      {filteredAppointments.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-12 text-center text-slate-400 font-semibold uppercase tracking-wider text-xs bg-slate-50/20">
                            No active appointment filings found.
                          </td>
                        </tr>
                      ) : (
                        filteredAppointments.map((app) => {
                          const statusStyles = {
                            Pending: "bg-amber-50 text-amber-800 border-amber-100",
                            Confirmed: "bg-emerald-50 text-emerald-800 border-emerald-100",
                            Completed: "bg-sky-50 text-sky-800 border-sky-100",
                            Cancelled: "bg-rose-50 text-rose-800 border-rose-100"
                          };

                          return (
                            <tr key={app.id} className="hover:bg-slate-50/50" id={`admin-apt-row-${app.id}`}>
                              <td className="py-3 px-4">
                                <div className="font-extrabold text-slate-800">{app.name}</div>
                                <div className="text-[10px] text-slate-400 font-mono mt-0.5">+91 {app.mobile}</div>
                                <div className="text-[10px] text-slate-400 font-mono mt-0.5">{app.email}</div>
                              </td>
                              <td className="py-3 px-4">
                                <div className="font-bold text-indigo-900">{app.doctor}</div>
                                <div className="text-[10px] text-slate-500 font-mono mt-0.5">{app.date} | {app.time}</div>
                              </td>
                              <td className="py-3 px-4">
                                <div className="text-slate-500 max-w-[180px] break-words line-clamp-2 italic">"{app.symptoms}"</div>
                                <div className="text-[9px] text-slate-300 font-mono mt-1">Booked: {app.bookingTime}</div>
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded-full border ${statusStyles[app.status] || "bg-slate-100"}`}>
                                  {app.status}
                                </span>
                              </td>
                              <td className="py-3 px-4">
                                <div className="flex items-center justify-center gap-1.5">
                                  <select
                                    value={app.status}
                                    onChange={(e) => handleUpdateAppointmentStatus(app.id, e.target.value as any)}
                                    className="bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-bold py-1 px-1.5 rounded-lg focus:outline-none"
                                  >
                                    <option value="Pending">Pending</option>
                                    <option value="Confirmed">Confirmed</option>
                                    <option value="Completed">Completed</option>
                                    <option value="Cancelled">Cancelled</option>
                                  </select>

                                  <button
                                    onClick={() => handleDirectWhatsAppAlert(app)}
                                    title="Send WhatsApp Ping"
                                    className="p-1 px-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-100 rounded-lg cursor-pointer"
                                  >
                                    WhatsApp
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 6.2 DOCTOR MANAGEMENT WORKSTATION */}
            {activeAdminTab === "doctors" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-doctors-workstation">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <h3 className="text-lg font-black text-slate-800 tracking-tight">Clinical Doctor Management</h3>
                    <p className="text-xs text-slate-400">Onboard new medical consultants, adjust timings, shift active status instantly.</p>
                  </div>
                  {!activeDoctorForm && (
                    <button
                      onClick={() => setActiveDoctorForm({})}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-sky-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      Add Specialist
                    </button>
                  )}
                </div>

                {activeDoctorForm ? (
                  // ADD / EDIT FORM
                  <form onSubmit={handleSaveDoctor} className="bg-slate-50 p-6 rounded-3xl border border-slate-200 space-y-4 max-w-2xl">
                    <h4 className="font-extrabold text-xs text-[#0077B6] uppercase tracking-widest">
                      {activeDoctorForm.id ? "Edit Specialist Consultation Details" : "Onboard New Clinical Consultant"}
                    </h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Full Name</label>
                        <input
                          type="text"
                          required
                          value={activeDoctorForm.name || ""}
                          onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, name: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Specialization Area</label>
                        <input
                          type="text"
                          required
                          value={activeDoctorForm.specialization || ""}
                          onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, specialization: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Qualifications</label>
                        <input
                          type="text"
                          value={activeDoctorForm.qualifications || ""}
                          onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, qualifications: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Experience Years</label>
                        <input
                          type="text"
                          value={activeDoctorForm.experience || ""}
                          onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, experience: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600">Consultation Timings</label>
                      <input
                        type="text"
                        value={activeDoctorForm.timings || ""}
                        onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, timings: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800 font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600">Short Profile Description</label>
                      <textarea
                        value={activeDoctorForm.description || ""}
                        onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, description: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800 h-20"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Consultation Status</label>
                        <select
                          value={activeDoctorForm.status || "Active"}
                          onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, status: e.target.value as any })}
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-sm text-slate-700"
                        >
                          <option value="Active">Active Consulting</option>
                          <option value="Inactive">On Leave / Inactive</option>
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Doctor Profile Image</label>
                        <div className="flex flex-col gap-2">
                          <input
                            type="text"
                            placeholder="File URL link..."
                            value={activeDoctorForm.photo || ""}
                            onChange={(e) => setActiveDoctorForm({ ...activeDoctorForm, photo: e.target.value })}
                            className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-[11px] text-slate-800"
                          />
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-400 font-extrabold uppercase shrink-0">or compress local file:</span>
                            <input 
                              type="file" 
                              accept="image/*"
                              onChange={(e) => handlePhotoUploadChange(e, (url) => setActiveDoctorForm({ ...activeDoctorForm, photo: url }))}
                              className="text-[10px] text-slate-500"
                            />
                            {imageCompressing && <Loader2 className="w-4 h-4 text-sky-600 animate-spin shrink-0" />}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setActiveDoctorForm(null)}
                        className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer"
                      >
                        Discard
                      </button>
                      <button
                        type="submit"
                        disabled={imageCompressing}
                        className="px-5 py-2 bg-[#0077B6] hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer"
                      >
                        Save & Deploy
                      </button>
                    </div>

                  </form>
                ) : (
                  // GRID VIEW
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {doctors.map(doc => (
                      <div key={doc.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between" id={`admin-doc-${doc.id}`}>
                        <div className="space-y-3">
                          <div className="w-full h-32 rounded-lg overflow-hidden bg-slate-100">
                            <img src={doc.photo} alt={doc.name} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <div className="flex items-center justify-between gap-1">
                              <span className="font-extrabold text-slate-800 text-xs sm:text-sm">{doc.name}</span>
                              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${doc.status === "Active" ? "bg-emerald-50 text-emerald-800 border border-emerald-100" : "bg-rose-50 text-rose-800 border border-rose-100"}`}>
                                {doc.status}
                              </span>
                            </div>
                            <div className="text-[10px] text-indigo-700 font-semibold uppercase tracking-wider mt-0.5">{doc.specialization}</div>
                            <div className="text-[10px] text-slate-400 font-semibold mt-1 font-mono shrink">{doc.timings}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 mt-4 pt-3 border-t border-slate-200">
                          <button
                            onClick={() => setActiveDoctorForm(doc)}
                            className="p-1.5 text-sky-700 hover:bg-sky-50 rounded"
                            title="Edit Doctor"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteDoctor(doc.id)}
                            className="p-1.5 text-rose-700 hover:bg-rose-50 rounded"
                            title="Delete Doctor"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 6.3 SERVICES DEPARTMENTS CMS */}
            {activeAdminTab === "services" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-services-workstation">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <h3 className="text-lg font-black text-slate-800 tracking-tight">Clinical Services & Departments</h3>
                    <p className="text-xs text-slate-400">Configure public service cards, edit clinical profiles, and replace department icons.</p>
                  </div>
                  {!activeServiceForm && (
                    <button
                      onClick={() => setActiveServiceForm({})}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-sky-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      Add Service Department
                    </button>
                  )}
                </div>

                {activeServiceForm ? (
                  <form onSubmit={handleSaveService} className="bg-slate-50 p-6 rounded-3xl border border-slate-200 space-y-4 max-w-xl">
                    <h4 className="font-extrabold text-xs text-[#0077B6] uppercase tracking-widest">
                      {activeServiceForm.id ? "Edit Clinical Department Details" : "Launch New Clinical Department"}
                    </h4>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600">Department Name</label>
                      <input
                        type="text"
                        required
                        value={activeServiceForm.title || ""}
                        onChange={(e) => setActiveServiceForm({ ...activeServiceForm, title: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600 font-mono">Lucide Icon String Name</label>
                      <select
                        value={activeServiceForm.iconName || "Stethoscope"}
                        onChange={(e) => setActiveServiceForm({ ...activeServiceForm, iconName: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-3 text-xs text-slate-700"
                      >
                        {["Stethoscope", "ShieldAlert", "Flame", "Activity", "Bone", "Volume2", "HeartHandshake", "HeartPulse", "Sliders", "Siren", "ClipboardCheck", "Microscope", "Pill", "Users", "DoorOpen", "Truck", "Sparkles", "Heart"].map(ico => (
                          <option key={ico} value={ico}>{ico}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600">Full Public Description Content</label>
                      <textarea
                        required
                        value={activeServiceForm.description || ""}
                        onChange={(e) => setActiveServiceForm({ ...activeServiceForm, description: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800 h-24"
                      />
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setActiveServiceForm(null)}
                        className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 font-bold text-xs uppercase tracking-wider rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-[#0077B6] hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl"
                      >
                        Publish Changes
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {services.map(ser => (
                      <div key={ser.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between" id={`admin-ser-${ser.id}`}>
                        <div className="space-y-2">
                          <div className="font-extrabold text-[#0077B6] text-xs leading-tight flex items-center gap-1.5">
                            <span className="font-mono text-[10px] bg-sky-50 px-1.5 py-0.5 border border-sky-100 rounded text-sky-700 shrink-0">{ser.iconName}</span>
                            {ser.title}
                          </div>
                          <p className="text-[11px] text-slate-500 line-clamp-3 leading-relaxed">"{ser.description}"</p>
                        </div>

                        <div className="flex gap-1.5 mt-3 pt-2.5 border-t border-slate-200">
                          <button
                            onClick={() => setActiveServiceForm(ser)}
                            className="p-1.5 text-sky-700 hover:bg-sky-50 rounded"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteService(ser.id)}
                            className="p-1.5 text-rose-700 hover:bg-rose-50 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 6.4 HOSPITAL INFORMATION WORKSTATION */}
            {activeAdminTab === "hospital" && hospitalInfo && (
              <form onSubmit={handleUpdateHospital} className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-hospital-workstation">
                <div className="border-b border-slate-100 pb-4">
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Hospital Profile & Copywriting</h3>
                  <p className="text-xs text-slate-400">Instantly modify public SEO headers, mission briefs, MD statements, and phone directories.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Hospital Name (Display Header)</label>
                    <input
                      type="text"
                      required
                      value={hospitalInfo.name || ""}
                      onChange={(e) => setHospitalInfo({ ...hospitalInfo, name: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-xs font-semibold text-slate-800"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Availability Support Status</label>
                    <input
                      type="text"
                      required
                      value={hospitalInfo.availability || ""}
                      onChange={(e) => setHospitalInfo({ ...hospitalInfo, availability: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-xs text-slate-800 font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5 col-span-2">
                    <label className="text-xs font-bold text-slate-600 block">About Us (Hospital History / Rationale)</label>
                    <textarea
                      required
                      value={hospitalInfo.aboutUs || ""}
                      onChange={(e) => setHospitalInfo({ ...hospitalInfo, aboutUs: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-xs text-slate-800 h-24 leading-relaxed"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Hospital Vision Mission Core Invariant</label>
                    <textarea
                      required
                      value={hospitalInfo.vision || ""}
                      onChange={(e) => setHospitalInfo({ ...hospitalInfo, vision: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-xs text-slate-800 h-20"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Hospital Core Mission Statement</label>
                    <textarea
                      required
                      value={hospitalInfo.mission || ""}
                      onChange={(e) => setHospitalInfo({ ...hospitalInfo, mission: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-xs text-slate-800 h-20"
                    />
                  </div>
                </div>

                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-4">
                  <h4 className="font-extrabold text-xs text-[#0077B6] uppercase tracking-wider">Managing Director Profiles</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500">Director Name</label>
                      <input
                        type="text"
                        value={hospitalInfo.managingDirectorName || ""}
                        onChange={(e) => setHospitalInfo({ ...hospitalInfo, managingDirectorName: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500">Official Title</label>
                      <input
                        type="text"
                        value={hospitalInfo.managingDirectorTitle || ""}
                        onChange={(e) => setHospitalInfo({ ...hospitalInfo, managingDirectorTitle: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500">Director Photo Link</label>
                      <input
                        type="text"
                        value={hospitalInfo.managingDirectorPhoto || ""}
                        onChange={(e) => setHospitalInfo({ ...hospitalInfo, managingDirectorPhoto: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5 mt-2">
                    <label className="text-xs font-bold text-slate-500 block">Personal Message From MD Desk</label>
                    <textarea
                      value={hospitalInfo.managingDirectorMessage || ""}
                      onChange={(e) => setHospitalInfo({ ...hospitalInfo, managingDirectorMessage: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800 h-24"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-slate-900 hover:bg-sky-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow cursor-pointer"
                >
                  Save Hospital Profile
                </button>
              </form>
            )}

            {/* 6.5 GALLERY ALBUMS CMS WORKSTATION */}
            {activeAdminTab === "gallery" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-gallery-workstation">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <h3 className="text-lg font-black text-slate-800 tracking-tight">Hospital Gallery & Albums</h3>
                    <p className="text-xs text-slate-400">Add interior, diagnostic lab, or treatment suite photos to showcase infrastructure limits.</p>
                  </div>
                  {!activeGalleryForm && (
                    <button
                      onClick={() => setActiveGalleryForm({ title: "", category: "General", url: "" })}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-sky-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      Add Photo
                    </button>
                  )}
                </div>

                {activeGalleryForm ? (
                  <form onSubmit={handleSaveGallery} className="bg-slate-50 p-6 rounded-3xl border border-slate-200 space-y-4 max-w-xl">
                    <h4 className="font-extrabold text-xs text-[#0077B6] uppercase tracking-widest">
                      Upload Hospital Facility Media
                    </h4>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600">Photo Title</label>
                      <input
                        type="text"
                        required
                        value={activeGalleryForm.title || ""}
                        onChange={(e) => setActiveGalleryForm({ ...activeGalleryForm, title: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Category / Album</label>
                        <select
                          value={activeGalleryForm.category || "General"}
                          onChange={(e) => setActiveGalleryForm({ ...activeGalleryForm, category: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-700"
                        >
                          <option value="Hospital Exterior">Hospital Exterior</option>
                          <option value="Reception">Reception & Lobby</option>
                          <option value="Consultation Rooms">Consultation Rooms</option>
                          <option value="Laboratory">Laboratory Diagnostics</option>
                          <option value="Treatment Rooms">Treatment Rooms</option>
                          <option value="Patient Care Areas">Patient Care Areas</option>
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600">Local Compress File Upload</label>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handlePhotoUploadChange(e, (url) => setActiveGalleryForm({ ...activeGalleryForm, url }))}
                          className="text-xs text-slate-500 mt-1"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-600">Photo URL Link (Or generated base64 above)</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. https://images.unsplash.com..."
                        value={activeGalleryForm.url || ""}
                        onChange={(e) => setActiveGalleryForm({ ...activeGalleryForm, url: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-[10px] font-mono text-slate-800"
                      />
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setActiveGalleryForm(null)}
                        className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 font-bold text-xs uppercase"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={imageCompressing}
                        className="px-5 py-2 bg-[#0077B6] text-white font-bold text-xs uppercase rounded-xl"
                      >
                        Publish Photo
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 animate-fadeIn">
                    {gallery.map(img => (
                      <div key={img.id} className="relative group rounded-xl overflow-hidden aspect-square border border-slate-100 bg-slate-50" id={`admin-gal-${img.id}`}>
                        <img src={img.url} alt={img.title} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-2.5">
                          <p className="text-[10px] text-sky-300 font-extrabold truncate uppercase">{img.category}</p>
                          <p className="text-[11px] text-white font-bold leading-tight truncate">{img.title}</p>
                          <button
                            onClick={() => handleDeleteGallery(img.id)}
                            className="absolute top-2 right-2 p-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 6.6 PATIENT REVIEWS CMS MODERATOR */}
            {activeAdminTab === "reviews" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-reviews-workstation">
                <div>
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Patient Reviews Moderation</h3>
                  <p className="text-xs text-slate-400">Audit submitted clinic feedback, approve star responses, and choose highlights to showcase on the home screen.</p>
                </div>

                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
                  {reviews.map(rev => (
                    <div key={rev.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-all flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4" id={`admin-rev-${rev.id}`}>
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-extrabold text-slate-800 text-sm leading-none">{rev.name}</span>
                          <span className="text-xs text-amber-500 font-bold leading-none">★ {rev.rating}/5</span>
                          <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${
                            rev.status === "Approved" ? "bg-emerald-50 text-emerald-800 border-emerald-100" :
                            rev.status === "Pending" ? "bg-amber-50 text-amber-800 border-amber-100" :
                            "bg-rose-50 text-rose-800 border-rose-100"
                          }`}>
                            {rev.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed italic max-w-xl">"{rev.text}"</p>
                        <p className="text-[10px] text-slate-400 font-mono">Date Submitted: {rev.date}</p>
                      </div>

                      <div className="flex flex-row sm:flex-col items-end gap-1.5 shrink-0 self-start sm:self-center">
                        <div className="flex items-center gap-1">
                          {rev.status !== "Approved" && (
                            <button
                              onClick={() => handleToggleReviewStatus(rev.id, "Approved")}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[10px] font-bold rounded-lg cursor-pointer"
                            >
                              Approve
                            </button>
                          )}
                          {rev.status !== "Rejected" && (
                            <button
                              onClick={() => handleToggleReviewStatus(rev.id, "Rejected")}
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-[10px] font-bold rounded-lg cursor-pointer"
                            >
                              Reject
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleToggleReviewFeatured(rev.id)}
                            className={`px-2 py-1 text-[10px] font-black rounded-lg border cursor-pointer ${rev.featured ? "bg-sky-50 text-sky-800 border-sky-200" : "bg-slate-100 text-slate-600 border-slate-200"}`}
                          >
                            {rev.featured ? "★ Featured" : "☆ Feature"}
                          </button>
                          <button
                            onClick={() => handleDeleteReview(rev.id)}
                            className="p-1 text-rose-600 hover:bg-rose-50 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 6.7 REGISTERED USERS MANAGEMENT CRM */}
            {activeAdminTab === "users" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-users-workstation">
                <div>
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Registered Patients CRM</h3>
                  <p className="text-xs text-slate-400">View member profiles, block/deactivate patient accounts, and resolve login resets.</p>
                </div>

                <div className="overflow-x-auto border border-slate-100 rounded-2xl bg-white shadow-sm">
                  <table className="w-full text-left text-xs text-slate-600 border-collapse">
                    <thead className="bg-slate-50 text-slate-400 uppercase font-black text-[10px] border-b border-slate-100">
                      <tr>
                        <th className="py-3 px-4 font-bold">Patient Details</th>
                        <th className="py-3 px-4 font-bold">Contact ID</th>
                        <th className="py-3 px-4 font-bold">Joined On</th>
                        <th className="py-3 px-4 font-bold">System Status</th>
                        <th className="py-3 px-4 text-center font-bold">CRM Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50 font-medium">
                      {users.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-slate-400 font-extrabold uppercase text-[10px]">No users registered on client end.</td>
                        </tr>
                      ) : (
                        users.map(u => (
                          <tr key={u.uid} className="hover:bg-slate-50/50" id={`admin-user-row-${u.uid}`}>
                            <td className="py-3 px-4 border-slate-100">
                              <div className="font-extrabold text-slate-800">{u.name}</div>
                              <div className="text-[10px] text-slate-400">UID: {u.uid}</div>
                            </td>
                            <td className="py-3 px-4">
                              <div className="font-mono text-slate-700">+91 {u.mobile}</div>
                              <div className="text-[10px] text-slate-400">{u.email || "No Email"}</div>
                            </td>
                            <td className="py-3 px-4 font-mono text-[10px] text-slate-500">
                              {new Date(u.registeredAt).toLocaleDateString('en-GB')}
                            </td>
                            <td className="py-3 px-4">
                              <span className={`px-2 py-0.5 text-[9px] font-black uppercase rounded ${u.blocked ? "bg-rose-50 text-rose-800 border border-rose-100 animate-pulse" : "bg-emerald-50 text-emerald-800 border border-emerald-100"}`}>
                                {u.blocked ? "Deactivated" : "Operational"}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  onClick={() => handleToggleUserBlocked(u.uid)}
                                  className={`px-2 py-1 text-[10px] font-bold rounded-lg border cursor-pointer ${u.blocked ? "bg-emerald-50 text-emerald-800 border-emerald-100" : "bg-rose-50 text-rose-800 border-rose-100"}`}
                                >
                                  {u.blocked ? "Activate" : "Block User"}
                                </button>
                                <button
                                  onClick={() => handleResetUserPassword(u.uid)}
                                  className="px-2 py-1 bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-bold rounded-lg cursor-pointer"
                                  title="Generate new temporary password"
                                >
                                  Reset Key
                                </button>
                                <button
                                  onClick={() => handleDeleteUser(u.uid)}
                                  className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 6.8 CLINICAL BROADCASTER HUB */}
            {activeAdminTab === "notifications" && (
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-notifications-workstation">
                <div className="border-b border-slate-100 pb-4">
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Clinical Broadcaster & Dispatcher</h3>
                  <p className="text-xs text-slate-400">Issue global clinical notes, notify patients about camp updates, or broadcast checkup delays directly into client dashboards.</p>
                </div>

                <form onSubmit={handleSendBroadcast} className="space-y-4 max-w-xl bg-slate-50 p-6 rounded-3xl border border-slate-150">
                  {broadcastSuccess && (
                    <div className="p-3 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-xl border border-emerald-100 flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      Broadcast successfully dispatched into targeted dashboard rosters!
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600">Patient Targeting Criteria</label>
                    <div className="flex gap-4 pt-1 text-xs">
                      {[
                        { id: "all", label: "All Booked Patients" },
                        { id: "pending", label: "State: Pending ONLY" },
                        { id: "confirmed", label: "State: Confirmed ONLY" }
                      ].map(t => (
                        <label key={t.id} className="flex items-center gap-1.5 font-semibold text-slate-700 cursor-pointer">
                          <input 
                            type="radio" 
                            name="target" 
                            checked={broadcastTarget === t.id}
                            onChange={() => setBroadcastTarget(t.id as any)}
                          />
                          {t.label}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Broadcast Alert Text Message</label>
                    <textarea
                      required
                      placeholder="e.g. Due to an emergency tertiary operation, consultations under Dr. Murali will begin with a 30-minute delay today. Thank you for your clinical cooperation."
                      value={broadcastMessage}
                      onChange={(e) => setBroadcastMessage(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-slate-800 h-24 max-h-32"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-slate-900 hover:bg-sky-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow cursor-pointer flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5 text-sky-400" />
                    Dispatch Broadcast Alert
                  </button>
                </form>
              </div>
            )}

            {/* 6.9 SETTINGS CONTROL WORKSTATION */}
            {activeAdminTab === "settings" && settings && (
              <form onSubmit={handleSaveSettings} className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-md space-y-6 animate-fadeIn" id="admin-settings-workstation">
                <div className="border-b border-slate-100 pb-4">
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Global Configurations & Channels</h3>
                  <p className="text-xs text-slate-400">Configure external Google Maps embeddings, QR redirections, notification routing targets, and layout images.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">Google Maps Link</label>
                    <input
                      type="text"
                      required
                      value={settings.mapsLink || ""}
                      onChange={(e) => setSettings({ ...settings, mapsLink: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-indigo-950 font-mono"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 block">QR Redirect Link (Directions target)</label>
                    <input
                      type="text"
                      required
                      value={settings.qrCodeLink || ""}
                      onChange={(e) => setSettings({ ...settings, qrCodeLink: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs text-indigo-950 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600">WhatsApp Channel Number</label>
                    <input
                      type="text"
                      required
                      value={settings.whatsappNumber || ""}
                      onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800 font-mono"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600">Administrative Target Email</label>
                    <input
                      type="text"
                      required
                      value={settings.emailNotificationAddress || ""}
                      onChange={(e) => setSettings({ ...settings, emailNotificationAddress: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-xs text-slate-800"
                    />
                  </div>
                  <div className="space-y-1.5 font-mono">
                    <label className="text-xs font-bold text-slate-600">Website Hero Banner Image</label>
                    <input
                      type="text"
                      required
                      value={settings.bannerImage || ""}
                      onChange={(e) => setSettings({ ...settings, bannerImage: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-[10px] text-slate-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div className="col-span-4 border-b border-slate-200 pb-1 mb-1">
                    <h5 className="text-[11px] font-black text-indigo-800 uppercase tracking-widest">Clinic Coordinates (Socials)</h5>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500">Facebook URL</label>
                    <input
                      type="text"
                      value={settings.socialFacebook || ""}
                      onChange={(e) => setSettings({ ...settings, socialFacebook: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-[10px] font-mono text-slate-800"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500">Twitter X URL</label>
                    <input
                      type="text"
                      value={settings.socialTwitter || ""}
                      onChange={(e) => setSettings({ ...settings, socialTwitter: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-[10px] font-mono text-slate-800"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500">Instagram URL</label>
                    <input
                      type="text"
                      value={settings.socialInstagram || ""}
                      onChange={(e) => setSettings({ ...settings, socialInstagram: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-[10px] font-mono text-slate-800"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500">YouTube URL</label>
                    <input
                      type="text"
                      value={settings.socialYoutube || ""}
                      onChange={(e) => setSettings({ ...settings, socialYoutube: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-[10px] font-mono text-slate-800"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-600 block">Copyright & Footer Info Text</label>
                  <textarea
                    required
                    value={settings.footerInfo || ""}
                    onChange={(e) => setSettings({ ...settings, footerInfo: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-xs text-slate-800 h-16 leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-slate-900 hover:bg-sky-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer"
                >
                  Save Platform Settings
                </button>

                {/* 10. OFFICIAL MEDICARE LOGO REDESIGN SPECIFICATION SUITE */}
                <div className="border-t border-slate-100 pt-6 mt-8 space-y-6">
                  <div>
                    <span className="bg-emerald-50 text-[#529E1A] px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest inline-block border border-emerald-100 mb-2">
                      Brand Identity Standard Suite
                    </span>
                    <h4 className="text-base font-black text-slate-800 tracking-tight">Official Logo Redesign Deliverables</h4>
                    <p className="text-xs text-slate-400">High-fidelity vector specifications extracted and rendered directly from the official branding blueprint across all master form factors.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Deliverable 1: MAIN HORIZONTAL LOGO */}
                    <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">1. Main Horizontal Logo</span>
                          <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold uppercase">Primary</span>
                        </div>
                        <p className="text-xs text-slate-500 mb-4 leading-relaxed">Default header/navbar composition mapping Medicare's primary emblem alongside clean bold brand typefaces.</p>
                      </div>
                      <div className="bg-white p-4 rounded-xl border border-slate-200/60 flex items-center justify-center">
                        <MedicareLogo layout="horizontal" size="sm" />
                      </div>
                    </div>

                    {/* Deliverable 2: SQUARE ICON LOGO */}
                    <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">2. Square Icon Logo</span>
                          <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold uppercase">App & Signage</span>
                        </div>
                        <p className="text-xs text-slate-500 mb-4 leading-relaxed">Symmetrical circular layout nested squarely, ideal for mobile launcher icons, visiting cards, and external signs.</p>
                      </div>
                      <div className="bg-white p-4 rounded-xl border border-slate-200/60 flex items-center justify-center">
                        <MedicareLogo layout="icon" size="md" />
                      </div>
                    </div>

                    {/* Deliverable 3: FAVICON VERSION */}
                    <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">3. Favicon Version</span>
                          <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold uppercase">Browser</span>
                        </div>
                        <p className="text-xs text-slate-500 mb-4 leading-relaxed">Ultra high-contrast mini layout optimized for 16x16 / 32x32 browser tab integrations.</p>
                      </div>
                      <div className="bg-white p-4 rounded-xl border border-slate-200/60 flex items-center justify-center gap-4">
                        <div className="p-2 bg-slate-100 rounded border border-slate-200">
                          <MedicareLogo layout="icon" size="xs" />
                        </div>
                        <span className="text-xs text-slate-600 font-mono">/favicon.ico (Active in current tab!)</span>
                      </div>
                    </div>

                    {/* Deliverable 4: WHITE BACKGROUND VERSION */}
                    <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">4. White Background Version</span>
                          <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold uppercase">Standard</span>
                        </div>
                        <p className="text-xs text-slate-500 mb-4 leading-relaxed">Rendered over pristine light grey or clean white background, leveraging deep emerald text values.</p>
                      </div>
                      <div className="bg-white p-6 rounded-xl border border-slate-200/60 flex items-center justify-center">
                        <MedicareLogo layout="vertical" size="md" />
                      </div>
                    </div>

                    {/* Deliverable 5: DARK BACKGROUND VERSION */}
                    <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">5. Dark Background Version</span>
                          <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold uppercase">Contrast</span>
                        </div>
                        <p className="text-xs text-slate-500 mb-4 leading-relaxed">Optimized with glowing emerald and bright red highlights over navy/charcoal backgrounds for footer and late-night interfaces.</p>
                      </div>
                      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 flex items-center justify-center">
                        <MedicareLogo layout="vertical" size="md" dark={true} />
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
