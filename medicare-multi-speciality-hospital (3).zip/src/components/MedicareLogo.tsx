import React from "react";

interface MedicareLogoProps {
  layout?: "horizontal" | "vertical" | "icon" | "square-showcase";
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  hideTagline?: boolean;
  dark?: boolean;
}

export default function MedicareLogo({
  layout = "horizontal",
  size = "md",
  className = "",
  hideTagline = false,
  dark = false,
}: MedicareLogoProps) {
  // Sizing definitions for high-quality responsive layouts
  const badgeSizes = {
    xs: "w-7 h-7 md:w-8 md:h-8",
    sm: "w-10 h-10 md:w-11 md:h-11",
    md: "w-14 h-14 md:w-16 md:h-16",
    lg: "w-20 h-20 md:w-24 md:h-24",
    xl: "w-28 h-28 md:w-36 md:h-36",
  };

  const nameFonts = {
    xs: "text-base tracking-tight font-black",
    sm: "text-xl md:text-2xl tracking-tight font-black",
    md: "text-2xl md:text-3xl tracking-tight font-black",
    lg: "text-3xl md:text-4xl tracking-tight font-black",
    xl: "text-5xl md:text-6xl tracking-tight font-black",
  };

  const subtitleFonts = {
    xs: "text-[7px] tracking-wider",
    sm: "text-[9px] md:text-[10px] tracking-widest",
    md: "text-xs tracking-[0.16em]",
    lg: "text-sm tracking-[0.18em]",
    xl: "text-xl tracking-[0.2em]",
  };

  const taglineFonts = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-lg",
    lg: "text-xl",
    xl: "text-3xl",
  };

  const isVertical = layout === "vertical";
  const isIconOnly = layout === "icon";

  return (
    <div
      className={`inline-flex ${
        isVertical ? "flex-col items-center text-center" : "items-center text-left"
      } gap-3 md:gap-4 ${className}`}
      id={`medicare-official-logo-${layout}`}
    >
      {/* 
        HIGH-FIDELITY VECTOR REPLICA OF THE MEDICARE MULTI SPECIALITY HOSPITAL EMBLEM
        - Circular background with Linear Gradient (Primary Green '#529E1A' to Deep Medical Blue '#1A4273')
        - Symmetrical White Medical Cross
        - Custom circular head representing human care connected to the top arm
        - High precision stethoscope drawing curving within the cross body resembling a question-mark loop
        - Brilliant light green cradling hand safeguarding the cross at the bottom
      */}
      <div
        className={`rounded-full flex items-center justify-center shrink-0 shadow-lg border border-white/20 transition-transform duration-300 hover:scale-105 bg-white ${badgeSizes[size]}`}
        id="medicare-logo-circle"
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full select-none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Core Brand Gradient - Top Left to Bottom Right */}
            <linearGradient id="medicareLogoGradient" x1="15%" y1="0%" x2="85%" y2="100%">
              <stop offset="0%" stopColor="#529E1A" />
              <stop offset="30%" stopColor="#418712" />
              <stop offset="75%" stopColor="#1E325C" />
              <stop offset="100%" stopColor="#122547" />
            </linearGradient>
            
            {/* Supportive Hand Gradient for natural lifelike appearance */}
            <linearGradient id="supportHandGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#529E1A" />
              <stop offset="100%" stopColor="#6CBE28" />
            </linearGradient>

            {/* Premium Inner Ring Shadow */}
            <radialGradient id="innerGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0" />
              <stop offset="90%" stopColor="#000000" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.2" />
            </radialGradient>
          </defs>

          {/* 1. Official Emblem Outer Circle with logo gradient */}
          <circle cx="50" cy="50" r="48" fill="url(#medicareLogoGradient)" />
          
          {/* Subtle inner seal ring */}
          <circle cx="50" cy="50" r="44" fill="none" stroke="white" strokeWidth="1" strokeDasharray="4 2" strokeOpacity="0.25" />

          {/* 2. Official Symmetrical White Medical Cross and Connected Care Head */}
          {/* Horizontal Arm: x = 26 to 74 (width 48), y = 38 to 58 (height 20) */}
          {/* Vertical Arm: x = 38 to 62 (width 24), y= 28 to 68 (height 40) */}
          {/* Combined seamlessly inside one path */}
          <path
            d="M 38,28 H 62 V 38 H 78 V 58 H 62 V 68 H 38 V 58 H 22 V 38 H 38 Z"
            fill="white"
          />
          
          {/* Connected White Care Head atop the cross (overlapping perfectly at y=28, center cx=50, cy=28, radius=13) */}
          <circle cx="50" cy="28" r="14" fill="white" />

          {/* 3. Gradient Stencil Stethoscope Artwork Cutout - exact question mark curly path */}
          {/* Using same logo gradient to let the emblem's depth show through */}
          <g>
            {/* The Stethoscope line */}
            <path
              d="M 51,61 C 51,54 54.5,53 55.5,49 C 56.5,44.5 50.5,43.5 50,38 C 49.5,32 55.5,31.5 56.5,27.5 C 57.5,23.5 50,21 46.5,25.5 C 43,29.5 45.5,33.5 46.5,33.5"
              fill="none"
              stroke="url(#medicareLogoGradient)"
              strokeWidth="2.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            
            {/* Stethoscope Ear-tip dot */}
            <circle cx="45.5" cy="33.5" r="1.5" fill="url(#medicareLogoGradient)" />

            {/* Stethoscope Chestpiece Ring and Center Dot at y = 61 */}
            <circle cx="51" cy="61" r="4.2" fill="none" stroke="url(#medicareLogoGradient)" strokeWidth="1.2" />
            <circle cx="51" cy="61" r="2.2" fill="url(#medicareLogoGradient)" />
          </g>

          {/* 4. Official Supportive Green Cradling Hand Wrapping bottom of cross */}
          {/* Starts at bottom-left inside circle, swoops gracefully under cross, ends nestled right */}
          <path
            d="M 24,62 C 34,76 66,76 76,62 C 60,69 40,69 24,62 Z"
            fill="url(#supportHandGradient)"
          />
          <path
            d="M 24,62 C 32,71 45,76 58,74 C 70,72 77,65 82,59 C 71,70 56,71 43,68 C 33,65 27,61 24,62 Z"
            fill="url(#supportHandGradient)"
            opacity="0.9"
          />

          {/* 5. Inner glow / shadow for premium depth */}
          <circle cx="50" cy="50" r="48" fill="url(#innerGlow)" pointerEvents="none" />
        </svg>
      </div>

      {/* Brand Text Elements - strictly matching the visual guidelines */}
      {!isIconOnly && (
        <div className={`flex flex-col ${isVertical ? "items-center" : "items-start"}`}>
          
          {/* Hospital Brand Title: Strong bold typography colored in official primary green '#529E1A' */}
          <h1
            className={`font-black tracking-tight font-sans text-[#529E1A] select-none uppercase leading-none transition-colors duration-300 ${nameFonts[size]}`}
            style={{ letterSpacing: "-0.015em" }}
            id="brand-name-medicare"
          >
            MEDICARE
          </h1>
          
          {/* Subtitle Name: Official Red '#BE1212' or softer light red for dark mode */}
          <div
            className={`font-extrabold uppercase ${dark ? "text-rose-400" : "text-[#BE1212]"} select-none leading-none pt-1 transition-colors duration-300 ${subtitleFonts[size]}`}
            style={{ letterSpacing: "0.08em" }}
            id="brand-subtype-medicare"
          >
            Multi Speciality Hospital
          </div>

          {/* Tagline script: Beautiful script calligraphy styled in official deep blue '#1E1F57' (or light sky blue in dark contrast) */}
          {!hideTagline && (
            <div
              className={`font-script ${dark ? "text-emerald-400" : "text-[#1E1F57]"} select-none italic pt-0.5 leading-none ${
                isVertical ? "w-full text-center mt-1" : "self-end"
              } ${taglineFonts[size]}`}
              id="brand-tagline-medicare"
            >
              Dedicated Health Services...
            </div>
          )}
        </div>
      )}
    </div>
  );
}
