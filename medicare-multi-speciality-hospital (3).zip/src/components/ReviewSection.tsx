import React, { useState, useEffect } from "react";
import { 
  Star, 
  MessageSquareHeart, 
  CheckCircle2, 
  User, 
  PenTool, 
  X, 
  Check, 
  HeartHandshake
} from "lucide-react";
import { PatientReview } from "../data";
import { dbAPI, CMSReview } from "../utils/db";

export default function ReviewSection() {
  const [reviews, setReviews] = useState<PatientReview[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [newName, setNewName] = useState("");
  const [newRating, setNewRating] = useState(5);
  const [newText, setNewText] = useState("");
  const [successMsg, setSuccessMsg] = useState(false);

  // Load reviews from CMS database (only showing approved ones)
  const refreshReviews = () => {
    try {
      const allReviews = dbAPI.getReviews();
      const approvedReviews = allReviews.filter((r) => r.status === "Approved");
      setReviews(approvedReviews);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    refreshReviews();
    window.addEventListener("medicare_db_update", refreshReviews);
    return () => window.removeEventListener("medicare_db_update", refreshReviews);
  }, []);

  const handleOpenGoogle = () => {
    // Open a mock search to write standard review or trigger the write review modal
    setShowModal(true);
  };

  const handleAddReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newText) {
      alert("Please provide both your name and feedback message.");
      return;
    }

    const newRev: CMSReview = {
      id: "rev-cus-" + Date.now(),
      name: newName,
      rating: newRating,
      text: newText,
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      photo: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150&h=150`,
      status: "Pending", // Starts as pending until Admin approves it
      featured: false
    };

    const currentList = dbAPI.getReviews();
    dbAPI.saveReviews([newRev, ...currentList]);

    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
      setShowModal(false);
      setNewName("");
      setNewText("");
      setNewRating(5);
    }, 2000);
  };

  // Helper inside stars renderer
  const renderStars = (rating: number, interactive = false, onSetRating?: (r: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            disabled={!interactive}
            onClick={() => onSetRating && onSetRating(star)}
            className={`${interactive ? "cursor-pointer transform hover:scale-110 active:scale-95 transition-all" : ""}`}
            id={`star-${interactive ? 'interactive-' : ''}${star}`}
          >
            <Star 
              className={`w-5 h-5 ${
                star <= rating 
                  ? "fill-amber-400 text-amber-400" 
                  : "text-slate-200 fill-slate-100"
              }`} 
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-10">
      
      {/* Dynamic Summary Panel */}
      <div className="bg-slate-50 rounded-3xl p-6 sm:p-10 border border-slate-100 flex flex-col md:flex-row items-center justify-between gap-8">
        
        <div className="space-y-3.5 text-center md:text-left">
          <span className="bg-sky-50 text-sky-700 px-3.5 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border border-sky-100 inline-block">
            Verified Experiences
          </span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight">
            Loved By Over 1,000+ Happy Patients
          </h3>
          <p className="text-sm text-slate-500 max-w-xl leading-relaxed">
            Patient safety, gentle hospitality, and effective treatments drive standard operations at Medicare Multi Speciality Hospital, Vijayawada. Read authentic clinical testimonials shared by our patient families.
          </p>
        </div>

        {/* Aggregated score block */}
        <div className="flex flex-col items-center shrink-0 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm min-w-[220px]">
          <div className="text-5xl font-extrabold text-slate-800 tracking-tighter">4.9</div>
          <div className="mt-1">{renderStars(5)}</div>
          <div className="text-xs text-slate-400 font-medium mt-1">Based on patient feedback</div>
          
          <button
            onClick={handleOpenGoogle}
            className="w-full mt-4 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-[#0077B6] text-white text-xs font-bold tracking-wider uppercase flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
            id="write-google-review-btn"
          >
            <PenTool className="w-3.5 h-3.5" />
            Write a Review
          </button>
        </div>

      </div>

      {/* Grid of testimonials */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {reviews.map((rev) => (
          <div 
            key={rev.id}
            className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 hover:border-sky-100 shadow-md hover:shadow-lg transition-all duration-300 flex flex-col justify-between group relative"
            id={`review-card-${rev.id}`}
          >
            {/* Quote decoration */}
            <div className="absolute top-6 right-6 font-serif text-slate-100 group-hover:text-sky-50 text-6xl select-none leading-none pointer-events-none transition-colors">
              “
            </div>

            <div className="space-y-4">
              {/* Rating stars */}
              <div>{renderStars(rev.rating)}</div>
              
              {/* Review Text */}
              <p className="text-slate-600 text-sm leading-relaxed italic">
                "{rev.text}"
              </p>
            </div>

            {/* Patients details */}
            <div className="flex items-center gap-3.5 pt-6 mt-6 border-t border-slate-50">
              <div className="w-11 h-11 rounded-full overflow-hidden bg-sky-50 border border-slate-100 text-sky-600 flex items-center justify-center font-bold text-sm select-none shrink-0">
                {rev.photo && !rev.id.startsWith("rev-cus-") ? (
                  <img src={rev.photo} alt={rev.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  rev.name.charAt(0)
                )}
              </div>
              <div className="text-xs">
                <h4 className="font-bold text-slate-800 flex items-center gap-1">
                  {rev.name}
                  {rev.id.startsWith("rev-cus-") && (
                    <span className="text-[9px] bg-sky-50 border border-sky-100 text-sky-600 px-1 py-0.2 rounded font-mono uppercase tracking-wide">
                      Patient
                    </span>
                  )}
                </h4>
                <div className="flex gap-2 text-slate-400 font-medium text-[10px] mt-0.5">
                  <span>{rev.date}</span>
                  <span>•</span>
                  <span className="text-emerald-600 flex items-center gap-0.5">
                    <CheckCircle2 className="w-3 h-3" />
                    Verified Treatment
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Write a review Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl relative overflow-hidden animate-slideUp">
            
            <button 
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {successMsg ? (
              <div className="py-12 px-6 text-center space-y-4">
                <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-100">
                  <Check className="w-7 h-7" strokeWidth={3} />
                </div>
                <h3 className="text-xl font-bold text-slate-800">Review Submitted Successfully!</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Thank you for sharing your hospital experience. Your valuable feedback is now visible on the portal page.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAddReviewSubmit} className="p-6 sm:p-8 space-y-5">
                <div className="flex gap-2.5 items-center pb-2 border-b border-slate-100">
                  <div className="w-9 h-9 bg-sky-50 text-[#0077B6] rounded-xl flex items-center justify-center">
                    <MessageSquareHeart className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-800">Write Your Treatment Review</h3>
                    <p className="text-[10px] text-slate-400">Your experiences help other patient families in Vijayawada make safe decisions.</p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">Patient Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text"
                      required
                      placeholder="e.g. Anand Garapati"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 pl-10 pr-4 text-xs focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800 inline-block"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">Rating</label>
                  <div className="flex gap-1.5 items-center">
                    {renderStars(newRating, true, setNewRating)}
                    <span className="text-xs font-bold text-slate-600 ml-1">({newRating} out of 5)</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">Feedback Message</label>
                  <textarea
                    required
                    placeholder="Describe your surgical experience, consultation comfort, doctor professionalism, or staff nursing service..."
                    rows={4}
                    value={newText}
                    onChange={(e) => setNewText(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs focus:outline-none focus:border-sky-500 focus:bg-white text-slate-800 resize-none inline-block leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-slate-900 hover:bg-[#0077B6] text-white font-extrabold text-xs uppercase tracking-widest transition-all cursor-pointer shadow"
                >
                  SUBMIT VERIFIED REVIEW
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
