import { 
  HeartPulse, 
  MapPin, 
  Phone, 
  Mail, 
  ExternalLink,
  Facebook,
  Instagram,
  Linkedin,
  Clock,
  QrCode
} from "lucide-react";
import { HOSPITAL_INFO, DOCTORS, SERVICES } from "../data";
import MedicareLogo from "./MedicareLogo";

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export default function Footer({ setActiveTab }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (id: string) => {
    setActiveTab(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const footerNavLinks = [
    { id: "home", label: "Home" },
    { id: "about", label: "About Hospital" },
    { id: "doctors", label: "Expert Doctors" },
    { id: "services", label: "Clinical Services" },
    { id: "facilities", label: "Our Facilities" },
    { id: "gallery", label: "Media Gallery" },
    { id: "reviews", label: "Patient Reviews" },
    { id: "contact", label: "Get in Touch" },
  ];

  // Google Maps address formatted for dynamic creation
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(HOSPITAL_INFO.mapsLink)}`;

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-8 border-t border-slate-900" id="main-footer">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          
          {/* Column 1: Hospital profile, Address & QR */}
          <div className="space-y-6">
            <button 
              onClick={() => handleLinkClick("home")} 
              className="flex items-center gap-2.5 text-left focus:outline-none cursor-pointer"
            >
              <MedicareLogo layout="horizontal" size="sm" dark={true} />
            </button>
            
            <p className="text-slate-400 text-sm leading-relaxed">
              Serving the citizens of Vijayawada and surrounding regions with impeccable medical integrity, 24/7 care, and advanced healthcare setups.
            </p>

            <div className="flex gap-4 items-center pt-2">
              <a href="#" className="w-9 h-9 rounded-lg bg-slate-900 hover:bg-sky-600 hover:text-white transition-all flex items-center justify-center text-slate-400">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-slate-900 hover:bg-sky-600 hover:text-white transition-all flex items-center justify-center text-slate-400">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-slate-900 hover:bg-sky-600 hover:text-white transition-all flex items-center justify-center text-slate-400">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Navigation & Services */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase border-l-2 border-sky-500 pl-3">
              Quick Links
            </h4>
            <div className="grid grid-cols-2 gap-x-2 gap-y-2 text-sm">
              {footerNavLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className="text-left text-slate-400 hover:text-sky-400 py-1 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span className="text-sky-500 text-xs">▪</span>
                  {link.label}
                </button>
              ))}
            </div>

            <div className="pt-2">
              <h4 className="text-white font-bold text-xs tracking-wider uppercase pl-3 mb-2">
                Top Specialists
              </h4>
              <div className="flex flex-wrap gap-1.5 pl-3">
                {DOCTORS.slice(0, 3).map((doc) => (
                  <button 
                    key={doc.id}
                    onClick={() => handleLinkClick("doctors")}
                    className="text-[10px] bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 px-2 py-1 rounded"
                  >
                    {doc.name.split(" ").slice(0, 2).join(" ")}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Column 3: Contact & Google Route Link */}
          <div className="space-y-5">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase border-l-2 border-sky-500 pl-3">
              Hospital Contact
            </h4>
            <ul className="space-y-3.5 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
                <span className="text-slate-400 leading-relaxed text-xs">
                  {HOSPITAL_INFO.address}
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-sky-500 shrink-0" />
                <div className="flex flex-col">
                  <a href={`tel:${HOSPITAL_INFO.phones[0]}`} className="hover:text-white font-semibold">
                    +91 {HOSPITAL_INFO.phones[0]}
                  </a>
                  <a href={`tel:${HOSPITAL_INFO.phones[1]}`} className="text-xs text-slate-500 hover:text-white">
                    +91 {HOSPITAL_INFO.phones[1]}
                  </a>
                </div>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-sky-500 shrink-0" />
                <a href={`mailto:${HOSPITAL_INFO.email}`} className="text-xs hover:text-white break-words max-w-[200px]">
                  {HOSPITAL_INFO.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5 text-xs text-slate-500">
                <Clock className="w-4 h-4 text-emerald-500 shrink-0 animate-pulse" />
                <span className="text-emerald-400 font-semibold">{HOSPITAL_INFO.availability}</span>
              </li>
            </ul>

            <div className="pt-2">
              <a 
                href={HOSPITAL_INFO.mapsLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold underline"
              >
                Open in Google Maps
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Column 4: QR Code Feature to satisfy strict requirements */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase border-l-2 border-sky-500 pl-3">
              Directions QR
            </h4>
            
            <div className="bg-white p-3 rounded-2xl inline-block shadow-lg border border-slate-800 hover:shadow-sky-900/30 transition-all group">
              <img 
                src={qrCodeUrl} 
                alt="Scan QR Code for Hospital Location in Google Maps" 
                className="w-28 h-28 object-contain rounded"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <QrCode className="w-3.5 h-3.5 text-sky-500" />
                Scan QR Code / Click
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Scan code with a mobile camera to load coordinates instantly in Google Maps app.
              </p>
              <a 
                href={HOSPITAL_INFO.directionsLink} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center gap-1 mt-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 uppercase tracking-wider"
              >
                Get Directions Now &rarr;
              </a>
            </div>
          </div>

        </div>

        {/* Divider and copyright */}
        <div className="border-t border-slate-900 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <div className="text-center md:text-left">
            <div>
              &copy; {currentYear} Medicare Multi Speciality Hospital, Suryaraopet, Vijayawada. All Rights Reserved.
            </div>
            <div className="mt-1 text-[10px]">
              Managing Director: <span className="text-slate-400 font-medium">{HOSPITAL_INFO.managingDirector.name}</span>.
            </div>
          </div>
          <div className="flex gap-4">
            <button onClick={() => handleLinkClick("about")} className="hover:text-slate-300">Privacy Policy</button>
            <span>•</span>
            <button onClick={() => handleLinkClick("contact")} className="hover:text-slate-300">Contact Desk</button>
            <span>•</span>
            <a href="https://wa.me/916281573727" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 text-emerald-600 transition-colors">Emergency WhatsApp</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
