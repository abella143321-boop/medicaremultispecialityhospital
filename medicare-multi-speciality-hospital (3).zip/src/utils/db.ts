import { Doctor, Service, PatientReview, HOSPITAL_INFO, DOCTORS, SERVICES, SAMPLE_REVIEWS, GALLERY_ITEMS } from "../data";
import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  deleteDoc, 
  onSnapshot,
  query,
  where
} from "firebase/firestore";
import { db, handleFirestoreError, OperationType, auth } from "./firebase";

// Extending models to support CMS structures
export interface CMSDoctor extends Doctor {
  timings: string;
  description: string;
  status: "Active" | "Inactive";
}

export interface CMSService extends Service {
  // Can add specific CMS properties if needed
}

export interface CMSReview extends PatientReview {
  status: "Pending" | "Approved" | "Rejected";
  featured: boolean;
}

export interface CMSHospitalInfo {
  name: string;
  aboutUs: string;
  vision: string;
  mission: string;
  managingDirectorName: string;
  managingDirectorTitle: string;
  managingDirectorPhoto: string;
  managingDirectorMessage: string;
  address: string;
  phones: string[];
  email: string;
  availability: string;
}

export interface CMSAppointment {
  id: string;
  name: string;
  mobile: string;
  email: string;
  age: string;
  gender: string;
  doctor: string;
  date: string;
  time: string;
  symptoms: string;
  bookingTime: string;
  status: "Pending" | "Confirmed" | "Completed" | "Cancelled";
  notifications: {
    emailSent: boolean;
    whatsappSent: boolean;
    broadcast?: string;
  };
}

export interface CMSPatientUser {
  uid: string;
  name: string;
  email?: string;
  mobile: string;
  password?: string;
  blocked: boolean;
  registeredAt: string;
}

export interface CMSSettings {
  mapsLink: string;
  qrCodeLink: string;
  whatsappNumber: string;
  emailNotificationAddress: string;
  socialFacebook: string;
  socialTwitter: string;
  socialInstagram: string;
  socialYoutube: string;
  bannerImage: string;
  footerInfo: string;
}

// Default Doctors CMS seed timings and descriptions
const defaultCmsDoctors: CMSDoctor[] = DOCTORS.map((docVal, idx) => ({
  ...docVal,
  timings: idx % 2 === 0 ? "09:00 AM - 01:00 PM, 04:00 PM - 08:00 PM" : "10:00 AM - 02:00 PM, 05:00 PM - 09:00 PM",
  description: `${docVal.name} is a highly accomplished specialist with ${docVal.experience} of medical expertise. Focused on giving precise diagnosis and personalized treatment options to the Vijayawada public.`,
  status: "Active"
}));

// Default Reviews seed
const defaultCmsReviews: CMSReview[] = SAMPLE_REVIEWS.map((rev) => ({
  ...rev,
  status: "Approved",
  featured: true
}));

// Default Settings
const defaultSettings: CMSSettings = {
  mapsLink: HOSPITAL_INFO.mapsLink,
  qrCodeLink: `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(HOSPITAL_INFO.mapsLink)}`,
  whatsappNumber: "+916281573727",
  emailNotificationAddress: HOSPITAL_INFO.email,
  socialFacebook: "https://facebook.com",
  socialTwitter: "https://twitter.com",
  socialInstagram: "https://instagram.com",
  socialYoutube: "https://youtube.com",
  bannerImage: "https://images.unsplash.com/photo-1586773860418-d3b3da9601ee?auto=format&fit=crop&q=80&w=1200",
  footerInfo: "© Medicare Multi Speciality Hospital. Crafted with compassionate healthcare standards for Vijayawada and surrounding regions."
};

// Default Hospital Info
const defaultHospital: CMSHospitalInfo = {
  name: HOSPITAL_INFO.name,
  aboutUs: HOSPITAL_INFO.managingDirector.message,
  vision: "To render standard-setting clinical outcomes and achieve national acclaim as the premier healthcare destination of Andhra Pradesh, grounded in empathetic nursing and robust surgical integrity.",
  mission: "We are committed to delivering advanced laparoscopic, laser, orthopedic, and pediatric surgical solutions alongside reliable round-the-clock emergency support at honest and transparent costs.",
  managingDirectorName: HOSPITAL_INFO.managingDirector.name,
  managingDirectorTitle: HOSPITAL_INFO.managingDirector.title,
  managingDirectorPhoto: HOSPITAL_INFO.managingDirector.photo,
  managingDirectorMessage: HOSPITAL_INFO.managingDirector.message,
  address: HOSPITAL_INFO.address,
  phones: HOSPITAL_INFO.phones,
  email: HOSPITAL_INFO.email,
  availability: HOSPITAL_INFO.availability
};

// State Store Keys for localStorage
const KEYS = {
  DOCTORS: "medicare_cms_doctors",
  SERVICES: "medicare_cms_services",
  REVIEWS: "medicare_cms_reviews",
  GALLERY: "medicare_cms_gallery",
  HOSPITAL: "medicare_cms_hospital",
  APPOINTMENTS: "medicare_cms_appointments",
  USERS: "medicare_cms_users",
  SETTINGS: "medicare_cms_settings"
};

/**
 * Checks and pre-seeds datasets to local fallback storage on first run.
 */
export function initializeStorage() {
  if (typeof window === "undefined") return;

  if (!localStorage.getItem(KEYS.DOCTORS)) {
    localStorage.setItem(KEYS.DOCTORS, JSON.stringify(defaultCmsDoctors));
  }
  if (!localStorage.getItem(KEYS.SERVICES)) {
    localStorage.setItem(KEYS.SERVICES, JSON.stringify(SERVICES));
  }
  if (!localStorage.getItem(KEYS.REVIEWS)) {
    localStorage.setItem(KEYS.REVIEWS, JSON.stringify(defaultCmsReviews));
  }
  if (!localStorage.getItem(KEYS.GALLERY)) {
    localStorage.setItem(KEYS.GALLERY, JSON.stringify(GALLERY_ITEMS));
  }
  if (!localStorage.getItem(KEYS.HOSPITAL)) {
    localStorage.setItem(KEYS.HOSPITAL, JSON.stringify(defaultHospital));
  }
  if (!localStorage.getItem(KEYS.SETTINGS)) {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(defaultSettings));
  }
  if (!localStorage.getItem(KEYS.APPOINTMENTS)) {
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.USERS)) {
    const defaultPatient: CMSPatientUser = {
      uid: "pat123",
      name: "Sandeep Vitap",
      email: "sandeep.24mic7005@vitapstudent.ac.in",
      mobile: "6281573727",
      password: "password123",
      blocked: false,
      registeredAt: new Date().toISOString()
    };
    localStorage.setItem(KEYS.USERS, JSON.stringify([defaultPatient]));
  }
}

// Initial Local Storage Backed Setup
initializeStorage();

/**
 * Helper to save changes back to Firestore (reconciling deleted items)
 */
async function saveListToFirestore(collectionName: string, items: any[], idField: string = "id") {
  try {
    const collRef = collection(db, collectionName);
    const snap = await getDocs(collRef);
    const existingIds = snap.docs.map(d => d.id);
    const newIds = items.map(item => item[idField]);

    // Delete item if deleted from cms
    for (const id of existingIds) {
      if (!newIds.includes(id)) {
        await deleteDoc(doc(db, collectionName, id));
      }
    }

    // Upsert items
    for (const item of items) {
      const idVal = item[idField];
      if (idVal) {
        await setDoc(doc(db, collectionName, idVal), item);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, collectionName);
  }
}

// Store active dynamic subscriptions so they can be securely managed/disposed
let unsubAppointments: (() => void) | null = null;
let unsubUsers: (() => void) | null = null;

/**
 * Safe Admin-only Seeding Procedure
 */
async function seedDatabaseIfNeeded() {
  try {
    const user = auth.currentUser;
    if (!user || user.email !== "sandeep.24mic7005@vitapstudent.ac.in") return;

    // Check and seed missing Doctors
    const docSnap = await getDocs(collection(db, "doctors"));
    const existingDocIds = new Set(docSnap.docs.map(d => d.id));
    for (const item of defaultCmsDoctors) {
      if (!existingDocIds.has(item.id)) {
        await setDoc(doc(db, "doctors", item.id), item);
      }
    }

    // Check and seed missing Services
    const servSnap = await getDocs(collection(db, "services"));
    const existingServIds = new Set(servSnap.docs.map(s => s.id));
    for (const item of SERVICES) {
      if (!existingServIds.has(item.id)) {
        await setDoc(doc(db, "services", item.id), item);
      }
    }

    // Check and seed missing Reviews
    const revSnap = await getDocs(collection(db, "reviews"));
    const existingRevIds = new Set(revSnap.docs.map(r => r.id));
    for (const item of defaultCmsReviews) {
      if (!existingRevIds.has(item.id)) {
        await setDoc(doc(db, "reviews", item.id), item);
      }
    }

    // Check and seed missing Gallery Items
    const galSnap = await getDocs(collection(db, "gallery"));
    const existingGalIds = new Set(galSnap.docs.map(g => g.id));
    for (const item of GALLERY_ITEMS) {
      if (!existingGalIds.has(item.id)) {
        await setDoc(doc(db, "gallery", item.id), item);
      }
    }

    // Check and seed Hospital Main Info
    const hospSnap = await getDocs(collection(db, "hospital"));
    if (hospSnap.empty) {
      await setDoc(doc(db, "hospital", "main"), defaultHospital);
    }

    // Check and seed Settings Main Info
    const settSnap = await getDocs(collection(db, "settings"));
    if (settSnap.empty) {
      await setDoc(doc(db, "settings", "main"), defaultSettings);
    }
  } catch (error) {
    console.warn("Administrative database seeding deferred/failed", error);
  }
}

/**
 * Live Realtime Sync Listener matching specifications
 */
export function startRealtimeSync() {
  if (typeof window === "undefined") return;

  // ==================== PUBLIC COLLECTIONS (READABLE BY ANYONE) ====================

  // 1. Sync Doctors
  onSnapshot(collection(db, "doctors"), (snap) => {
    const data = snap.empty ? [] : snap.docs.map(d => d.data() as CMSDoctor);
    const merged = [...data];
    let hasChanges = false;
    for (const defDoc of defaultCmsDoctors) {
      if (!merged.some(d => d.id === defDoc.id)) {
        merged.push(defDoc);
        hasChanges = true;
        setDoc(doc(db, "doctors", defDoc.id), defDoc).catch(console.warn);
      }
    }
    localStorage.setItem(KEYS.DOCTORS, JSON.stringify(merged));
    window.dispatchEvent(new Event("medicare_db_update"));
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, "doctors");
  });

  // 2. Sync Services
  onSnapshot(collection(db, "services"), (snap) => {
    const data = snap.empty ? [] : snap.docs.map(d => d.data() as CMSService);
    const merged = [...data];
    let hasChanges = false;
    for (const defSer of SERVICES) {
      if (!merged.some(s => s.id === defSer.id)) {
        merged.push(defSer);
        hasChanges = true;
        setDoc(doc(db, "services", defSer.id), defSer).catch(console.warn);
      }
    }
    localStorage.setItem(KEYS.SERVICES, JSON.stringify(merged));
    window.dispatchEvent(new Event("medicare_db_update"));
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, "services");
  });

  // 3. Sync Reviews
  onSnapshot(collection(db, "reviews"), (snap) => {
    const data = snap.empty ? [] : snap.docs.map(d => d.data() as CMSReview);
    const merged = [...data];
    let hasChanges = false;
    for (const defRev of defaultCmsReviews) {
      if (!merged.some(r => r.id === defRev.id)) {
        merged.push(defRev);
        hasChanges = true;
        setDoc(doc(db, "reviews", defRev.id), defRev).catch(console.warn);
      }
    }
    localStorage.setItem(KEYS.REVIEWS, JSON.stringify(merged));
    window.dispatchEvent(new Event("medicare_db_update"));
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, "reviews");
  });

  // 4. Sync Gallery
  onSnapshot(collection(db, "gallery"), (snap) => {
    const data = snap.empty ? [] : snap.docs.map(d => d.data());
    const merged = [...data];
    let hasChanges = false;
    for (const defGal of GALLERY_ITEMS) {
      if (!merged.some(g => g.id === defGal.id)) {
        merged.push(defGal);
        hasChanges = true;
        setDoc(doc(db, "gallery", defGal.id), defGal).catch(console.warn);
      }
    }
    localStorage.setItem(KEYS.GALLERY, JSON.stringify(merged));
    window.dispatchEvent(new Event("medicare_db_update"));
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, "gallery");
  });

  // 5. Sync Hospital Info
  onSnapshot(doc(db, "hospital", "main"), (snap) => {
    if (snap.exists()) {
      const data = snap.data() as CMSHospitalInfo;
      localStorage.setItem(KEYS.HOSPITAL, JSON.stringify(data));
      window.dispatchEvent(new Event("medicare_db_update"));
    } else {
      setDoc(doc(db, "hospital", "main"), defaultHospital).catch(console.warn);
      localStorage.setItem(KEYS.HOSPITAL, JSON.stringify(defaultHospital));
      window.dispatchEvent(new Event("medicare_db_update"));
    }
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, "hospital/main");
  });

  // 6. Sync Settings
  onSnapshot(doc(db, "settings", "main"), (snap) => {
    if (snap.exists()) {
      const data = snap.data() as CMSSettings;
      localStorage.setItem(KEYS.SETTINGS, JSON.stringify(data));
      window.dispatchEvent(new Event("medicare_db_update"));
    } else {
      setDoc(doc(db, "settings", "main"), defaultSettings).catch(console.warn);
      localStorage.setItem(KEYS.SETTINGS, JSON.stringify(defaultSettings));
      window.dispatchEvent(new Event("medicare_db_update"));
    }
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, "settings/main");
  });


  // ==================== AUTH-RESTRICTED COLLECTIONS ====================

  auth.onAuthStateChanged((user) => {
    // Check if the authenticated user is the designated admin
    const isAdminUser = user && user.email === "sandeep.24mic7005@vitapstudent.ac.in";

    if (isAdminUser) {
      // Trigger database seeding dynamically under administrative permissions
      seedDatabaseIfNeeded();

      // 7. Sync Appointments (Full Collection read - Admin Only)
      if (!unsubAppointments) {
        unsubAppointments = onSnapshot(collection(db, "appointments"), (snap) => {
          const data = snap.docs.map(d => d.data() as CMSAppointment);
          localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(data));
          window.dispatchEvent(new Event("medicare_db_update"));
        }, (err) => {
          handleFirestoreError(err, OperationType.GET, "appointments");
        });
      }

      // 8. Sync Users (Full Collection read - Admin Only)
      if (!unsubUsers) {
        unsubUsers = onSnapshot(collection(db, "users"), (snap) => {
          if (snap.empty) {
            const defaultPatient: CMSPatientUser = {
              uid: "pat123",
              name: "Sandeep Vitap",
              email: "sandeep.24mic7005@vitapstudent.ac.in",
              mobile: "6281573727",
              blocked: false,
              registeredAt: new Date().toISOString()
            };
            setDoc(doc(db, "users", defaultPatient.uid), defaultPatient).catch(console.error);
          } else {
            const data = snap.docs.map(d => d.data() as CMSPatientUser);
            localStorage.setItem(KEYS.USERS, JSON.stringify(data));
            window.dispatchEvent(new Event("medicare_db_update"));
          }
        }, (err) => {
          handleFirestoreError(err, OperationType.GET, "users");
        });
      }
    } else if (user) {
      // Standard Signed-in Parent/Patient: Can read own user profile and own appointments under security rules

      // Sub to single user profile in `/users/{userId}`
      if (unsubUsers) {
        unsubUsers();
      }
      unsubUsers = onSnapshot(doc(db, "users", user.uid), (docSnap) => {
        if (docSnap.exists()) {
          const userData = docSnap.data() as CMSPatientUser;
          const freshUsers = dbAPI.getUsers();
          const index = freshUsers.findIndex(u => u.uid === userData.uid);
          if (index > -1) {
            freshUsers[index] = userData;
          } else {
            freshUsers.push(userData);
          }
          localStorage.setItem(KEYS.USERS, JSON.stringify(freshUsers));
          
          const savedSession = localStorage.getItem("medicare_patient_session");
          if (savedSession) {
            const currentSess = JSON.parse(savedSession);
            if (currentSess.uid === userData.uid) {
              localStorage.setItem("medicare_patient_session", JSON.stringify(userData));
            }
          }
          window.dispatchEvent(new Event("medicare_db_update"));
        }
      }, (err) => {
        console.warn("User profile doc not found or inaccessible:", err.message);
      });

      // Sub to query of own appointments filtered by their verified email
      if (unsubAppointments) {
        unsubAppointments();
      }
      if (user.email) {
        const q = query(collection(db, "appointments"), where("email", "==", user.email));
        unsubAppointments = onSnapshot(q, (snap) => {
          const patientApps = snap.docs.map(d => d.data() as CMSAppointment);
          const allApps = dbAPI.getAppointments();
          const otherApps = allApps.filter(app => !app.email || app.email.toLowerCase() !== user.email?.toLowerCase());
          const merged = [...patientApps, ...otherApps];
          localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(merged));
          window.dispatchEvent(new Event("medicare_db_update"));
        }, (err) => {
          handleFirestoreError(err, OperationType.GET, "appointments");
        });
      } else {
        unsubAppointments = null;
      }
    } else {
      // Fully signed-out/anonymous guest: Unsubscribe from auth-restricted listeners and rely on local storage
      if (unsubAppointments) {
        unsubAppointments();
        unsubAppointments = null;
      }
      if (unsubUsers) {
        unsubUsers();
        unsubUsers = null;
      }
    }
  });
}

// Spark up Realtime Listeners
startRealtimeSync();

/**
 * Database API functions (Cloud Persistent)
 */
export const dbAPI = {
  // DOCTORS CRUD
  getDoctors: (): CMSDoctor[] => {
    return JSON.parse(localStorage.getItem(KEYS.DOCTORS) || "[]");
  },
  saveDoctors: (docs: CMSDoctor[]) => {
    localStorage.setItem(KEYS.DOCTORS, JSON.stringify(docs));
    window.dispatchEvent(new Event("medicare_db_update"));
    saveListToFirestore("doctors", docs);
  },
  
  // SERVICES CRUD
  getServices: (): CMSService[] => {
    return JSON.parse(localStorage.getItem(KEYS.SERVICES) || "[]");
  },
  saveServices: (services: CMSService[]) => {
    localStorage.setItem(KEYS.SERVICES, JSON.stringify(services));
    window.dispatchEvent(new Event("medicare_db_update"));
    saveListToFirestore("services", services);
  },

  // REVIEWS CRUD
  getReviews: (): CMSReview[] => {
    return JSON.parse(localStorage.getItem(KEYS.REVIEWS) || "[]");
  },
  saveReviews: (reviews: CMSReview[]) => {
    localStorage.setItem(KEYS.REVIEWS, JSON.stringify(reviews));
    window.dispatchEvent(new Event("medicare_db_update"));
    saveListToFirestore("reviews", reviews);
  },

  // GALLERY CRUD
  getGallery: (): typeof GALLERY_ITEMS => {
    return JSON.parse(localStorage.getItem(KEYS.GALLERY) || "[]");
  },
  saveGallery: (gallery: typeof GALLERY_ITEMS) => {
    localStorage.setItem(KEYS.GALLERY, JSON.stringify(gallery));
    window.dispatchEvent(new Event("medicare_db_update"));
    saveListToFirestore("gallery", gallery);
  },

  // HOSPITAL INFO CRUD
  getHospitalInfo: (): CMSHospitalInfo => {
    return JSON.parse(localStorage.getItem(KEYS.HOSPITAL) || JSON.stringify(defaultHospital));
  },
  saveHospitalInfo: (info: CMSHospitalInfo) => {
    localStorage.setItem(KEYS.HOSPITAL, JSON.stringify(info));
    window.dispatchEvent(new Event("medicare_db_update"));
    setDoc(doc(db, "hospital", "main"), info).catch((err) => {
      handleFirestoreError(err, OperationType.WRITE, "hospital/main");
    });
  },

  // SETTINGS CRUD
  getSettings: (): CMSSettings => {
    return JSON.parse(localStorage.getItem(KEYS.SETTINGS) || JSON.stringify(defaultSettings));
  },
  saveSettings: (settings: CMSSettings) => {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
    window.dispatchEvent(new Event("medicare_db_update"));
    setDoc(doc(db, "settings", "main"), settings).catch((err) => {
      handleFirestoreError(err, OperationType.WRITE, "settings/main");
    });
  },

  // APPOINTMENTS CRUD
  getAppointments: (): CMSAppointment[] => {
    return JSON.parse(localStorage.getItem(KEYS.APPOINTMENTS) || "[]");
  },
  saveAppointments: (apps: CMSAppointment[]) => {
    const prevAppsStr = localStorage.getItem(KEYS.APPOINTMENTS);
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(apps));
    window.dispatchEvent(new Event("medicare_db_update"));

    const user = auth.currentUser;
    const isAdminUser = user && user.email === "sandeep.24mic7005@vitapstudent.ac.in";
    if (isAdminUser) {
      saveListToFirestore("appointments", apps);
    } else if (user && user.email) {
      // Client-side diff-based sync for standard logged-in patients
      const prevApps = prevAppsStr ? (JSON.parse(prevAppsStr) as CMSAppointment[]) : [];
      
      // 1. Identify deleted appointments belonging to current user
      const prevUserApps = prevApps.filter(app => app.email && app.email.toLowerCase() === user.email?.toLowerCase());
      const newUserAppIds = new Set(apps.map(app => app.id));
      
      for (const app of prevUserApps) {
        if (!newUserAppIds.has(app.id)) {
          // Deleted from UI, delete from Firestore
          deleteDoc(doc(db, "appointments", app.id)).catch((err) => {
            console.warn("Could not delete appointment:", err.message);
          });
        }
      }

      // 2. Identify created/updated appointments
      const currUserApps = apps.filter(app => app.email && app.email.toLowerCase() === user.email?.toLowerCase());
      for (const app of currUserApps) {
        setDoc(doc(db, "appointments", app.id), app).catch((err) => {
          console.warn("Could not upsert appointment:", err.message);
        });
      }
    }
  },
  addAppointment: (app: Omit<CMSAppointment, "id" | "status" | "notifications">): CMSAppointment => {
    const list = dbAPI.getAppointments();
    const newApp: CMSAppointment = {
      ...app,
      id: "apt_" + Math.random().toString(36).substr(2, 9),
      status: "Pending",
      notifications: { emailSent: false, whatsappSent: false }
    };
    list.unshift(newApp); 
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(list));
    window.dispatchEvent(new Event("medicare_db_update"));

    setDoc(doc(db, "appointments", newApp.id), newApp).catch((err) => {
      handleFirestoreError(err, OperationType.WRITE, `appointments/${newApp.id}`);
    });
    return newApp;
  },

  // USER MANAGEMENT
  getUsers: (): CMSPatientUser[] => {
    return JSON.parse(localStorage.getItem(KEYS.USERS) || "[]");
  },
  saveUsers: (users: CMSPatientUser[]) => {
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    window.dispatchEvent(new Event("medicare_db_update"));
    
    const user = auth.currentUser;
    const isAdminUser = user && user.email === "sandeep.24mic7005@vitapstudent.ac.in";
    if (isAdminUser) {
      saveListToFirestore("users", users, "uid");
    } else if (user) {
      // Standard logged-in patient: only upsert their own record to Firestore
      const myRecord = users.find(u => u.uid === user.uid);
      if (myRecord) {
        setDoc(doc(db, "users", user.uid), myRecord).catch((err) => {
          console.warn("Could not save user profile:", err.message);
        });
      }
    }
  },
  registerPatient: (name: string, email: string, mobile: string, password?: string): CMSPatientUser | { error: string } => {
    const users = dbAPI.getUsers();
    
    // Check if duplicate mobile or email exists
    const duplicate = users.find(u => u.mobile === mobile || (email && u.email === email));
    if (duplicate) {
      return { error: "A user with this mobile number or email address already exists." };
    }

    const newUser: CMSPatientUser = {
      uid: "user_" + Math.random().toString(36).substr(2, 9),
      name,
      email,
      mobile,
      password,
      blocked: false,
      registeredAt: new Date().toISOString()
    };
    users.push(newUser);
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    window.dispatchEvent(new Event("medicare_db_update"));

    setDoc(doc(db, "users", newUser.uid), newUser).catch((err) => {
      handleFirestoreError(err, OperationType.WRITE, `users/${newUser.uid}`);
    });
    return newUser;
  }
};
