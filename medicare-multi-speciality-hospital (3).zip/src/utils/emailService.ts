import emailjs from "@emailjs/browser";

// Cached configuration fetched from the full-stack server
let cachedConfig: { serviceId: string; templateId: string; publicKey: string } | null = null;
let isFetchingConfig = false;

/**
 * Dynamically resolves the EmailJS parameters.
 * First try backend server endpoint since compile-time static files do not update with new runtime environment secrets on Cloud Run.
 * If backend fails, falls back to Vite-level build-time variables.
 */
export async function ensureConfigured(): Promise<boolean> {
  if (cachedConfig) {
    return true;
  }
  
  if (isFetchingConfig) {
    // Wait slightly or let it continue; since we do on-demand await, simple check is good
    return !!cachedConfig;
  }

  isFetchingConfig = true;
  try {
    const response = await fetch("/api/email-config");
    if (response.ok) {
      const data = await response.json();
      if (data.serviceId && data.templateId && data.publicKey) {
        cachedConfig = {
          serviceId: data.serviceId,
          templateId: data.templateId,
          publicKey: data.publicKey
        };
        console.log("[EmailJS Service] Dynamically loaded credentials from container runtime!");
        isFetchingConfig = false;
        return true;
      }
    }
  } catch (error) {
    console.warn("[EmailJS Service] Failed to retrieve server-side configuration, using fallbacks:", error);
  }

  // Fallback to build-time vars
  const buildServiceId = (import.meta as any).env.VITE_EMAILJS_SERVICE_ID || "";
  const buildTemplateId = (import.meta as any).env.VITE_EMAILJS_TEMPLATE_ID || "";
  const buildPublicKey = (import.meta as any).env.VITE_EMAILJS_PUBLIC_KEY || "";

  if (buildServiceId && buildTemplateId && buildPublicKey) {
    cachedConfig = {
      serviceId: buildServiceId,
      templateId: buildTemplateId,
      publicKey: buildPublicKey
    };
    isFetchingConfig = false;
    return true;
  }

  isFetchingConfig = false;
  return false;
}

/**
 * Checks if EmailJS keys are configured, either dynamically or statically.
 */
export const isEmailJsConfigured = (): boolean => {
  if (cachedConfig) return true;
  const buildServiceId = (import.meta as any).env.VITE_EMAILJS_SERVICE_ID || "";
  const buildTemplateId = (import.meta as any).env.VITE_EMAILJS_TEMPLATE_ID || "";
  const buildPublicKey = (import.meta as any).env.VITE_EMAILJS_PUBLIC_KEY || "";
  return !!(buildServiceId && buildTemplateId && buildPublicKey);
};

export interface AppointmentEmailParams {
  name: string;
  mobile: string;
  email: string;
  age: string;
  gender: string;
  doctor: string;
  date: string;
  time: string;
  symptoms: string;
  bookingTime: string;
}

export interface SupportInquiryEmailParams {
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
}

/**
 * Sends an email notification of a new Patient Appointment Slot Booking.
 */
export async function sendAppointmentEmail(params: AppointmentEmailParams): Promise<{ success: boolean; error?: string }> {
  // Ensure we are initialized with dynamic server keys
  const initialized = await ensureConfigured();
  if (!initialized || !cachedConfig) {
    const warningMsg = "Service ID, Template ID, or Public Key is not defined. Email dispatch was bypassed.";
    console.warn(warningMsg);
    return { success: false, error: "EmailJS parameters are unconfigured in your environment settings." };
  }

  // Rich mapping to ensure compatibility with both default and custom templates
  const templateParams = {
    // 1. Precise structured fields
    form_type: "Appointment Booking",
    patient_name: params.name,
    patient_mobile: params.mobile,
    patient_email: params.email,
    patient_age: params.age,
    patient_gender: params.gender,
    doctor_name: params.doctor,
    appointment_date: params.date,
    appointment_time: params.time,
    symptoms: params.symptoms,
    booking_time: params.bookingTime,
    
    // 2. Generic default/fallback identifiers (extremely important for generic templates)
    name: params.name,
    from_name: params.name,
    email: params.email,
    from_email: params.email,
    phone: params.mobile,
    mobile: params.mobile,
    subject: `Clinical Consultation Scheduled with ${params.doctor}`,
    
    // 3. Complete long message fallback in case the developer mapped only {{message}}
    message: `A new Clinical Appointment was booked by ${params.name} with ${params.doctor} for ${params.date} at ${params.time}.\n\nPatient Details:\n- Age/Gender: ${params.age} yrs (${params.gender})\n- Mobile: ${params.mobile}\n- Email Contact: ${params.email}\n- Manifested Symptoms: ${params.symptoms}\n- Booking Occurred: ${params.bookingTime}`
  };

  try {
    console.log("[EmailJS Service] Sending Appointment Email with templateParams:", templateParams);
    const result = await emailjs.send(cachedConfig.serviceId, cachedConfig.templateId, templateParams, cachedConfig.publicKey);
    console.log("EmailJS Appointment Notification Sent Successfully:", result.status, result.text);
    return { success: true };
  } catch (error: any) {
    console.error("EmailJS Appointment Notification Failed:", error);
    return { success: false, error: error?.text || error?.message || "Unknown EmailJS Error" };
  }
}

/**
 * Sends an email notification of a new Support / Admin Inquiry request.
 */
export async function sendSupportInquiryEmail(params: SupportInquiryEmailParams): Promise<{ success: boolean; error?: string }> {
  // Ensure we are initialized with dynamic server keys
  const initialized = await ensureConfigured();
  if (!initialized || !cachedConfig) {
    const warningMsg = "Service ID, Template ID, or Public Key is not defined. Email dispatch was bypassed.";
    console.warn(warningMsg);
    return { success: false, error: "EmailJS parameters are unconfigured in your environment settings." };
  }

  // Rich mapping to ensure compatibility with both default and custom templates
  const templateParams = {
    // 1. Precise structured fields
    form_type: "Support Ticket Inquiry",
    coordinator_name: params.name,
    phone_number: params.phone,
    email_address: params.email || "Not provided",
    subject: params.subject || "No Subject",
    details: params.message,

    // 2. Generic default/fallback identifiers (extremely important for generic templates)
    name: params.name,
    from_name: params.name,
    email: params.email || "Not provided",
    from_email: params.email || "Not provided",
    phone: params.phone,
    
    // 3. Complete long message fallback in case the developer mapped only {{message}}
    message: `A new Support Inquiry Ticket was submitted by ${params.name}.\n\nInquirer Contact Info:\n- Phone: ${params.phone}\n- Email: ${params.email || "Not provided"}\n- Help Topic Subject: ${params.subject || "No Subject"}\n\nDetails Submitted:\n${params.message}`
  };

  try {
    console.log("[EmailJS Service] Sending Support Inquiry Email with templateParams:", templateParams);
    const result = await emailjs.send(cachedConfig.serviceId, cachedConfig.templateId, templateParams, cachedConfig.publicKey);
    console.log("EmailJS Support Notification Sent Successfully:", result.status, result.text);
    return { success: true };
  } catch (error: any) {
    console.error("EmailJS Support Notification Failed:", error);
    return { success: false, error: error?.text || error?.message || "Unknown EmailJS Error" };
  }
}
