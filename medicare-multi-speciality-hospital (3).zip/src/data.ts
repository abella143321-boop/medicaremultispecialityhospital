export interface Doctor {
  id: string;
  name: string;
  qualifications: string;
  specialization: string;
  experience: string;
  photo: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: string; // Used to pick correct Lucide icon
}

export interface PatientReview {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
  photo: string;
}

export interface Facility {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  url: string;
}

export const HOSPITAL_INFO = {
  name: "MEDICARE MULTI SPECIALITY HOSPITAL",
  tagline: "Dedicated Healthcare Services",
  managingDirector: {
    name: "Dr. B. Lakshmi Srilekha",
    title: "Managing Director",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400&h=400", // Female professional executive
    message: "At Medicare Multi Speciality Hospital, our cornerstone is a resolute commitment to patient well-being. We believe healthcare goes beyond prescribing remedies; it is about cultivating empathy, utilizing state-of-the-art procedures, and rendering standard-setting clinical outcomes. Since our establishment in 2021, we have dedicated ourselves to serving the people of Vijayawada and surrounding regions with impeccable medical integrity, 24/7 care, and experienced clinical hands."
  },
  address: "D.No. 29-7-34, Vishnuvardhanarao Street, Suryaraopet, Vijayawada – 520002",
  addressShort: "Suryaraopet, Vijayawada - 520002",
  phones: [
    "6281573727",
    "9701783693",
    "9966700911"
  ],
  email: "medicaremultispeciality2021@gmail.com",
  availability: "24/7 Emergency Service",
  mapsLink: "https://maps.google.com/?q=Medicare+Multi+Speciality+Hospital+Suryaraopet+Vijayawada+520002",
  directionsLink: "https://www.google.com/maps/dir/?api=1&destination=Medicare+Multi+Speciality+Hospital+Suryaraopet+Vijayawada+520002"
};

// Doctors List
export const DOCTORS: Doctor[] = [
  {
    id: "doc1",
    name: "Dr. C.T. Murali Krishna Reddy",
    qualifications: "MBBS, DNB, MRCS, FMAS, FIAGES",
    specialization: "Laparoscopic and Laser Surgeon",
    experience: "18+ Years",
    photo: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    id: "doc2",
    name: "Dr. Lavakumar Ande",
    qualifications: "MBBS, MD, FIPM",
    specialization: "Critical Care & Pain Management Physician",
    experience: "12+ Years",
    photo: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    id: "doc3",
    name: "Dr. Venkatesh",
    qualifications: "MCH UROLOGY",
    specialization: "MCH Urology Specialist",
    experience: "15+ Years",
    photo: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    id: "doc4",
    name: "Dr. Satya Phanindra",
    qualifications: "MS ORTHO",
    specialization: "Orthopedic Surgeon",
    experience: "10+ Years",
    photo: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    id: "doc5",
    name: "Dr. Lakshmi Lasya",
    qualifications: "MBBS, MS ENT, DNB ENT",
    specialization: "ENT Specialist",
    experience: "8+ Years",
    photo: "https://images.unsplash.com/photo-1594824813573-246434de83fb?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    id: "doc6",
    name: "Dr. Nandini",
    qualifications: "MBBS, MS OBG",
    specialization: "Obstetrics & Gynecology Specialist",
    experience: "11+ Years",
    photo: "https://images.unsplash.com/photo-1614608682850-e0d6ed316d47?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    id: "doc7",
    name: "Dr. B. Lakshmi Srilekha",
    qualifications: "MBBS, MD",
    specialization: "Managing Director & Chief Administrator",
    experience: "16+ Years",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400&h=400"
  }
];

// Services List
export const SERVICES: Service[] = [
  {
    id: "ser1",
    title: "General Medicine",
    description: "Comprehensive management of acute illnesses, chronic lifestyle disorders, hypertension, diabetes, and infectious fevers by seasoned clinicians.",
    iconName: "Stethoscope"
  },
  {
    id: "ser2",
    title: "General Surgery",
    description: "Conventional open and minor surgeries for hernias, appendicitis, hydroceles, lumps, and soft-tissue masses with top post-op clinical nursing.",
    iconName: "ShieldAlert"
  },
  {
    id: "ser3",
    title: "Laparoscopic Surgery",
    description: "Advanced minimally invasive keyhole operations and precision laser surgeries leading to negligible pain, small scars, and lightning-fast healing.",
    iconName: "Flame"
  },
  {
    id: "ser4",
    title: "Urology",
    description: "Comprehensive care for kidney stones, prostate concerns, urinary system disorders, and advanced laser urological interventions.",
    iconName: "Activity"
  },
  {
    id: "ser5",
    title: "Orthopedics",
    description: "Management of comprehensive joint pain, fractures, dislocations, osteoarthritis, joint replacements, and sport injury rehabilitation programs.",
    iconName: "Bone"
  },
  {
    id: "ser6",
    title: "ENT",
    description: "Highly specialized medical and surgical treatments for specialized ear, nose, throat, auditory, sinus, and voice disorders.",
    iconName: "Volume2"
  },
  {
    id: "ser7",
    title: "Gynecology",
    description: "Comprehensive obstetrics, safe prenatal programs, delivery guidance, gynecological surgery, PCOD therapy, and comprehensive women health services.",
    iconName: "HeartHandshake"
  },
  {
    id: "ser8",
    title: "Critical Care",
    description: "Round-the-clock intensive care unit (ICU) support with advanced mechanical ventilators, real-time monitors, and high-ratio dedicated staff-to-patient monitoring.",
    iconName: "HeartPulse"
  },
  {
    id: "ser9",
    title: "Pain Management",
    description: "Therapeutic interventions, nerve blocks, and specialized outpatient care to systematically address and alleviate chronic back, joint, and terminal pain.",
    iconName: "Sliders"
  },
  {
    id: "ser10",
    title: "Emergency Care",
    description: "Trauma, stroke, coronary care emergencies integrated with 24/7 in-house triage teams prepared for rapid action during critical moments.",
    iconName: "Siren"
  },
  {
    id: "ser11",
    title: "Health Checkups",
    description: "Comprehensive age-appropriate preventative master wellness packages tailored for active individuals, executives, and senior citizens.",
    iconName: "ClipboardCheck"
  },
  {
    id: "ser12",
    title: "Diagnostic Services",
    description: "Fast-loading laboratory, accurate high-res ultrasound, digitized X-ray imaging, and ECG screening under one roof for fluid clinical diagnostic precision.",
    iconName: "Microscope"
  }
];

// Facilities List
export const FACILITIES: Facility[] = [
  {
    id: "fac1",
    title: "24/7 Emergency",
    description: "Immediate emergency response team with dedicated triage beds and life support systems.",
    iconName: "Siren"
  },
  {
    id: "fac2",
    title: "Pharmacy",
    description: "Fully stocked critical care drugs and routine medical inventory, open round-the-clock.",
    iconName: "Pill"
  },
  {
    id: "fac3",
    title: "Laboratory",
    description: "In-house clinical biochemistry, pathology and hematology lab for high-speed diagnostic reports.",
    iconName: "Microscope"
  },
  {
    id: "fac4",
    title: "ICU Support",
    description: "Fully equipped High-Dependency Units and Intensive Care Units with telemetry and ventilators.",
    iconName: "Activity"
  },
  {
    id: "fac5",
    title: "Specialist Consultation",
    description: "Daily and on-call specialist doctor availability for various medicine and surgery domains.",
    iconName: "Users"
  },
  {
    id: "fac6",
    title: "Diagnostic Services",
    description: "Instant ultrasound sonography, digitized digital X-Ray imaging, and multiscale cardiac ECG tests.",
    iconName: "Sparkles"
  },
  {
    id: "fac7",
    title: "Patient Care",
    description: "Compassionate in-patient support with dynamic meal plans, housekeeping, and standard sanitization.",
    iconName: "Heart"
  },
  {
    id: "fac8",
    title: "Comfortable Waiting Area",
    description: "Comfortable air-conditioned spaces with modern digital displays, clean drinking water, and sanitization stations.",
    iconName: "DoorOpen"
  },
  {
    id: "fac9",
    title: "Digital Appointments",
    description: "Hassle-free slot booking via phone, website, or WhatsApp for reduced waiting queues.",
    iconName: "Calendar"
  },
  {
    id: "fac10",
    title: "Ambulance Support",
    description: "Equipped transit vehicle ready for emergency transfers and pick-ups across Vijayawada.",
    iconName: "Truck"
  }
];

// 10 Patients Reviews
export const SAMPLE_REVIEWS: PatientReview[] = [
  {
    id: "tr1",
    name: "Rajeswari Garapati",
    rating: 5,
    text: "Dr. Lakshmi Srilekha and Dr. Murali Krishna Murthy gave us exceptional care. The laparoscopic surgery went smoothly. Medicare is truly the most trustworthy multi-speciality setup in Suryaraopet.",
    date: "12 May 2026",
    photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr2",
    name: "Suresh Babu K.",
    rating: 5,
    text: "Highly recommended for ENT treatment! Dr. Lakshita Lasya explained the sinus condition with great patience. Very hygienic consultation rooms and polite staff.",
    date: "28 April 2026",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr3",
    name: "Venkata Ramanujam",
    rating: 5,
    text: "Saved my father in an emergency! The 24/7 critical care ICU doctors and nurses reacted instantly during chest pain. We are extremely grateful to Medicare Hospital, Vijayawada.",
    date: "14 April 2026",
    photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr4",
    name: "Dr. Swathi Priya",
    rating: 5,
    text: "Consulted Dr. Nandini for maternity/gynecology care. The guidance, ultrasound tests, and warm environment made the entire process highly reassuring. Outstanding hospital management.",
    date: "02 April 2026",
    photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr5",
    name: "Mohammad Ali",
    rating: 5,
    text: "Dr. Lavakumar has exceptional skills in pain management. My chronic spinal nerve pain has reduced drastically with his specialized injections and therapeutic care. Clean and modern rooms.",
    date: "20 March 2026",
    photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr6",
    name: "Anjali Devi",
    rating: 5,
    text: "Best urology care under Dr. Venkatesh. He diagnosed my kidney stone issue immediately and treated it endoscopically. Quick recovery without any complications.",
    date: "05 March 2026",
    photo: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr7",
    name: "Prasad Rao Ch.",
    rating: 5,
    text: "I met with an accident and broke my wrist. Dr. Sathya Phanindra performed orthopedic surgery flawlessly. I have regained 100% hand mobility now. Reliable, affordable medical fees.",
    date: "18 Feb 2026",
    photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr8",
    name: "K. Lakshmi",
    rating: 5,
    text: "Hassle-free experience. I booked an appointment through the website, received instant phone confirmation, and saw the doctor within 10 minutes of arrival. Very tidy waiting area.",
    date: "03 Feb 2026",
    photo: "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr9",
    name: "Srinivas G.",
    rating: 5,
    text: "Unmatched cleanliness and customer service in Vijayawada. Everyone from the reception desk to clinical technicians is respectful. Lab results are sent directly on WhatsApp too.",
    date: "25 Jan 2026",
    photo: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    id: "tr10",
    name: "Purnachandra Rao",
    rating: 4,
    text: "Superb critical care and general medicine services. General surgery team is extremely experienced under Dr. Murali Krishna. Highly recommend this Medicare Hospital in Vijayawada.",
    date: "15 Jan 2026",
    photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150&h=150"
  }
];

// Why choose us points
export const WHY_CHOOSE_US = [
  {
    title: "Experienced Doctors",
    description: "Highly qualified clinicians bring decades of combined tertiary healthcare expertise from top institutions in India and abroad.",
    bullet: "Senior specialists on-site"
  },
  {
    title: "Modern Equipment",
    description: "Latest laser technology, advanced laparoscopic stack, micro-debriders, and high-tech real-time ICU vitals monitoring panels.",
    bullet: "State-of-the-art operation theaters"
  },
  {
    title: "Emergency Care",
    description: "24/7 critical trauma management, emergency triage, ICU support, and on-call specialist doctors ready for instant response.",
    bullet: "Always ready, round-the-clock"
  },
  {
    title: "Affordable Treatment",
    description: "World-class care priced honestly. Transparencies in diagnostic and procedural bills make tertiary healthcare accessible to all.",
    bullet: "Value-centric treatment plans"
  },
  {
    title: "Personalized Care",
    description: "We don't treat symptoms; we care for humans. Tailor-made nursing directives and individualized surgical followups.",
    bullet: "Patient-centered recovery setups"
  },
  {
    title: "Quality Healthcare",
    description: "Rigorous pharmaceutical compliance, certified infection controls, sterile instrumentation, and continuous audit protocols.",
    bullet: "Impeccable clinical standards"
  }
];

// Statistics
export const STATS = [
  { label: "24/7 Emergency Support", value: "24/7", sub: "Round-the-clock care" },
  { label: "6 Specialist Doctors", value: "6", sub: "Acreedited experts" },
  { label: "1000+ Happy Patients", value: "1000+", sub: "Successful recoveries" },
  { label: "Multi-Speciality Care", value: "100%", sub: "Departments under one roof" }
];

// Gallery Images
export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gal1",
    title: "Hospital Exterior Facade",
    category: "Hospital Exterior",
    url: "/src/assets/images/hospital_hero_1780220812724.png"
  },
  {
    id: "gal2",
    title: "Premium Reception & Patient Lobby",
    category: "Reception",
    url: "/src/assets/images/hospital_lobby_1780220828924.png"
  },
  {
    id: "gal3",
    title: "Specialist Consultation Rooms",
    category: "Consultation Rooms",
    url: "/src/assets/images/hospital_clinic_room_1780220844368.png"
  },
  {
    id: "gal4",
    title: "High-Speed Biochemical Diagnostics Laboratory",
    category: "Laboratory",
    url: "https://images.unsplash.com/photo-1579154769741-628d3ef37b6c?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "gal5",
    title: "Advanced Emergency Treatment Suite",
    category: "Treatment Rooms",
    url: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "gal6",
    title: "In-Patient Recovery Ward & Care Areas",
    category: "Patient Care Areas",
    url: "https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=800"
  }
];

