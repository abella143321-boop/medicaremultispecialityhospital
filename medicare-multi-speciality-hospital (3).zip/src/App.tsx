import React, { useState, useEffect } from "react";
import { 
  Phone, 
  Mail, 
  Clock, 
  MapPin, 
  Calendar, 
  Award, 
  Stethoscope, 
  Activity, 
  Flame, 
  ShieldAlert, 
  Bone, 
  Volume2, 
  HeartHandshake, 
  HeartPulse, 
  Sliders, 
  Siren, 
  ClipboardCheck, 
  Microscope, 
  Pill, 
  Users, 
  DoorOpen, 
  Truck, 
  Sparkles, 
  Heart, 
  ChevronRight, 
  ArrowRight, 
  CheckSquare, 
  ThumbsUp, 
  CheckCircle2, 
  MessageSquare, 
  Map, 
  ExternalLink, 
  QrCode, 
  MessageCircle, 
  Check, 
  ShieldCheck, 
  BriefcaseMedical, 
  Star,
  Compass,
  Smile,
  PhoneCall,
  CalendarDays
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Imports of custom sub-components
import Header from "./components/Header";
import Footer from "./components/Footer";
import DoctorGrid from "./components/DoctorGrid";
import AppointmentForm from "./components/AppointmentForm";
import ReviewSection from "./components/ReviewSection";
import Lightbox from "./components/Lightbox";
import PatientPortal from "./components/PatientPortal";
import AdminDashboard from "./components/AdminDashboard";
import RoleSelectionLanding from "./components/RoleSelectionLanding";
import { dbAPI, CMSHospitalInfo, CMSDoctor, CMSService, CMSSettings } from "./utils/db";

// EmailJS integrations support
import { sendSupportInquiryEmail, isEmailJsConfigured, ensureConfigured } from "./utils/emailService";

// Import of data values
import { 
  HOSPITAL_INFO, 
  DOCTORS, 
  SERVICES, 
  FACILITIES, 
  GALLERY_ITEMS, 
  WHY_CHOOSE_US, 
  STATS 
} from "./data";

export default function App() {
  const [selectedRole, setSelectedRole] = useState<"patient" | "admin" | null>(() => {
    const path = window.location.pathname;
    const hash = window.location.hash;
    if (
      path === "/admin" || 
      path === "/admin-dashboard" || 
      path.startsWith("/admin") ||
      hash === "#admin" || 
      hash === "#admin-dashboard"
    ) {
      return "admin";
    }
    if (
      path === "/patient" || 
      path === "/patient-dashboard" || 
      hash === "#patient" || 
      hash === "#patient-portal"
    ) {
      return "patient";
    }
    const stored = sessionStorage.getItem("medicare_selected_portal");
    if (stored === "patient" || stored === "admin") {
      return stored;
    }
    return null;
  });

  const [activeTab, setActiveTab] = useState(() => {
    const path = window.location.pathname;
    const hash = window.location.hash;
    if (path.includes("admin") || hash.includes("admin")) {
      return "admin-dashboard";
    }
    if (path.includes("patient") || hash.includes("patient")) {
      return "patient-portal";
    }
    return "home";
  });
  const [selectedDoctorName, setSelectedDoctorName] = useState("");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Dynamic CRM & CMS state
  const [dynHospitalInfo, setDynHospitalInfo] = useState<CMSHospitalInfo>(dbAPI.getHospitalInfo());
  const [dynDoctors, setDynDoctors] = useState<CMSDoctor[]>(dbAPI.getDoctors());
  const [dynServices, setDynServices] = useState<CMSService[]>(dbAPI.getServices());
  const [dynGallery, setDynGallery] = useState<any[]>(dbAPI.getGallery());
  const [dynSettings, setDynSettings] = useState<CMSSettings>(dbAPI.getSettings());

  const refreshAppData = () => {
    setDynHospitalInfo(dbAPI.getHospitalInfo());
    setDynDoctors(dbAPI.getDoctors());
    setDynServices(dbAPI.getServices());
    setDynGallery(dbAPI.getGallery());
    setDynSettings(dbAPI.getSettings());
  };

  useEffect(() => {
    refreshAppData();
    window.addEventListener("medicare_db_update", refreshAppData);
    return () => window.removeEventListener("medicare_db_update", refreshAppData);
  }, []);

  // Sync selectedRole with activeTab swaps
  useEffect(() => {
    if (activeTab === "admin-dashboard") {
      setSelectedRole("admin");
      sessionStorage.setItem("medicare_selected_portal", "admin");
    } else if (
      activeTab === "patient-portal" || 
      activeTab === "home" || 
      activeTab === "about" || 
      activeTab === "doctors" || 
      activeTab === "services" || 
      activeTab === "facilities" || 
      activeTab === "gallery" || 
      activeTab === "reviews" || 
      activeTab === "appointment" || 
      activeTab === "contact"
    ) {
      setSelectedRole("patient");
      sessionStorage.setItem("medicare_selected_portal", "patient");
    }
  }, [activeTab]);

  // Synchronize path and hash routing with activeTab
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname;
      const hash = window.location.hash;
      if (
        path === "/admin" || 
        path === "/admin-dashboard" || 
        path.startsWith("/admin") ||
        hash === "#admin" || 
        hash === "#admin-dashboard"
      ) {
        const adminSessionToken = localStorage.getItem("medicare_admin_session");
        const isAuth = adminSessionToken === "authorized";
        
        if (!isAuth && (path === "/admin-dashboard" || hash === "#admin-dashboard")) {
          // Redirect unauthenticated admin-dashboard visitors to secure /admin login page
          if (hash === "#admin-dashboard") {
            window.location.hash = "#admin";
          } else {
            window.history.pushState({}, "", "/admin");
          }
        }
        setSelectedRole("admin");
        setActiveTab("admin-dashboard");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else if (
        path === "/patient" || 
        path === "/patient-dashboard" || 
        hash === "#patient" || 
        hash === "#patient-portal"
      ) {
        setSelectedRole("patient");
        setActiveTab("patient-portal");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else if (path === "/" || path === "" || hash === "" || hash === "#home") {
        const stored = sessionStorage.getItem("medicare_selected_portal");
        if (stored === "patient") {
          setSelectedRole("patient");
          setActiveTab("home");
        } else if (stored === "admin") {
          setSelectedRole("admin");
          setActiveTab("admin-dashboard");
        } else {
          setSelectedRole(null);
        }
      }
    };
    
    handleLocationChange();
    window.addEventListener("hashchange", handleLocationChange);
    window.addEventListener("popstate", handleLocationChange);
    return () => {
      window.removeEventListener("hashchange", handleLocationChange);
      window.removeEventListener("popstate", handleLocationChange);
    };
  }, []);

  const handleSelectRole = (role: "patient" | "admin") => {
    setSelectedRole(role);
    sessionStorage.setItem("medicare_selected_portal", role);
    if (role === "patient") {
      setActiveTab("home");
      if (window.location.pathname !== "/") {
        window.history.pushState({}, "", "/");
      }
    } else {
      setActiveTab("admin-dashboard");
      if (window.location.pathname !== "/admin") {
        window.history.pushState({}, "", "/admin");
      } else {
        window.location.hash = "#admin";
      }
    }
  };

  const handleResetPortal = () => {
    setSelectedRole(null);
    sessionStorage.removeItem("medicare_selected_portal");
    setActiveTab("home");
    if (window.location.pathname !== "/") {
      window.history.pushState({}, "", "/");
    } else {
      window.location.hash = "";
    }
  };
  
  // Contact Feedback state
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactSubject, setContactSubject] = useState("");
  const [contactMsg, setContactMsg] = useState("");
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // EmailJS Support Ticket status state
  const [contactEmailSending, setContactEmailSending] = useState(false);
  const [contactEmailStatus, setContactEmailStatus] = useState<"idle" | "success" | "error" | "unconfigured">("idle");
  const [contactEmailErrorDetail, setContactEmailErrorDetail] = useState("");
  const [contactConfigActive, setContactConfigActive] = useState(false);

  // Floating button and Scroll tracking
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    // Dynamically retrieve EmailJS configuration
    ensureConfigured()
      .then((active) => {
        setContactConfigActive(active);
      })
      .catch(console.error);

    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleBookDoctorAndRedirect = (docName: string) => {
    setSelectedDoctorName(docName);
    setActiveTab("appointment");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBookButtonClickNoDoc = () => {
    setSelectedDoctorName("");
    setActiveTab("appointment");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactPhone || !contactMsg) {
      alert("Please fill out Name, Phone, and Message fields.");
      return;
    }
    
    setContactSubmitted(true);

    if (contactConfigActive || isEmailJsConfigured()) {
      setContactEmailSending(true);
      setContactEmailStatus("idle");
      sendSupportInquiryEmail({
        name: contactName,
        phone: contactPhone,
        email: contactEmail,
        subject: contactSubject,
        message: contactMsg
      })
        .then((result) => {
          setContactEmailSending(false);
          if (result.success) {
            setContactEmailStatus("success");
          } else {
            setContactEmailStatus("error");
            setContactEmailErrorDetail(result.error || "");
          }
        })
        .catch((err) => {
          setContactEmailSending(false);
          setContactEmailStatus("error");
          setContactEmailErrorDetail(err?.message || String(err));
        });
    } else {
      setContactEmailStatus("unconfigured");
    }
  };

  const handleResetContactForm = () => {
    setContactSubmitted(false);
    setContactName("");
    setContactPhone("");
    setContactEmail("");
    setContactSubject("");
    setContactMsg("");
    setContactEmailStatus("idle");
  };

  // Helper function to dynamically map strings into Lucide Icons
  const getIconComponent = (iconName: string, className: string = "w-6 h-6") => {
    switch (iconName) {
      case "Stethoscope": return <Stethoscope className={className} />;
      case "ShieldAlert": return <ShieldAlert className={className} />;
      case "Flame": return <Flame className={className} />;
      case "Activity": return <Activity className={className} />;
      case "Bone": return <Bone className={className} />;
      case "Volume2": return <Volume2 className={className} />;
      case "HeartHandshake": return <HeartHandshake className={className} />;
      case "HeartPulse": return <HeartPulse className={className} />;
      case "Sliders": return <Sliders className={className} />;
      case "Siren": return <Siren className={className} />;
      case "ClipboardCheck": return <ClipboardCheck className={className} />;
      case "Microscope": return <Microscope className={className} />;
      case "Pill": return <Pill className={className} />;
      case "Users": return <Users className={className} />;
      case "DoorOpen": return <DoorOpen className={className} />;
      case "Truck": return <Truck className={className} />;
      case "Sparkles": return <Sparkles className={className} />;
      case "Heart": return <Heart className={className} />;
      case "Calendar": return <Calendar className={className} />;
      default: return <Stethoscope className={className} />;
    }
  };

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(HOSPITAL_INFO.mapsLink)}`;

  if (selectedRole === null) {
    return <RoleSelectionLanding onSelectRole={handleSelectRole} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 flex flex-col justify-between selection:bg-sky-500 selection:text-white" id="root-content">
      
      {/* 1. Header Navigation Element */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onBookClick={handleBookButtonClickNoDoc} 
        onResetPortal={handleResetPortal}
      />

      {/* Main page content wrapper with client side transition animations */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          
          {/* ==================== HOME TAB ==================== */}
          {activeTab === "home" && (
            <motion.div
              key="home-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="space-y-16 sm:space-y-24 pb-16"
            >
              {/* Premium Hero Section */}
              <section className="relative bg-slate-900 border-b border-slate-800 overflow-hidden min-h-[580px] flex items-center">
                {/* Hero dynamic banner image layered background */}
                <div className="absolute inset-0 z-0">
                  <img 
                    src="/src/assets/images/hospital_hero_1780220812724.png" 
                    alt="Medicare Multi Speciality Hospital Outer View" 
                    className="w-full h-full object-cover object-center opacity-40 select-none scale-[1.01]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
                </div>

                <div className="max-w-7xl mx-auto px-4 md:px-6 relative z-10 w-full py-16 sm:py-24">
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                    
                    {/* Hero Left Content Column */}
                    <div className="space-y-6 lg:col-span-7">
                      
                      {/* Emergency Badge */}
                      <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#0077B6] text-white text-xs font-bold leading-none tracking-wider uppercase animate-pulse shadow-md">
                        <Siren className="w-3.5 h-3.5" />
                        {dynHospitalInfo.availability}
                      </span>

                      <div className="space-y-2">
                        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
                          {dynHospitalInfo.name}
                        </h1>
                        <p className="text-[#0077B6] font-extrabold tracking-widest text-sm sm:text-base md:text-lg uppercase">
                          {dynHospitalInfo.tagline}
                        </p>
                      </div>

                      <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl">
                        Welcome to {dynHospitalInfo.name}, Suryaraopet, Vijayawada. We provide comprehensive healthcare services with experienced specialists and advanced medical facilities to foster early recoveries and lifelong well-being.
                      </p>

                      <div className="flex flex-wrap gap-4 pt-2">
                        <button
                          onClick={handleBookButtonClickNoDoc}
                          className="px-7 py-4 rounded-2xl bg-gradient-to-r from-[#0077B6] to-sky-500 hover:from-sky-500 hover:to-[#0077B6] text-white text-sm font-bold tracking-wider uppercase shadow-lg shadow-sky-400/20 active:scale-[0.98] transition-all cursor-pointer flex items-center gap-2"
                        >
                          <CalendarDays className="w-4 h-4 text-sky-150" />
                          Book Appointment
                        </button>
                        <a
                          href={`tel:${dynHospitalInfo.phones?.[0] || HOSPITAL_INFO.phones[0]}`}
                          className="px-7 py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-sm font-bold tracking-wider uppercase active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                        >
                          <Phone className="w-4 h-4 text-emerald-500" />
                          Call Administrative Desk
                        </a>
                      </div>

                      {/* Quick Hospital meta */}
                      <div className="pt-6 grid grid-cols-3 gap-4 border-t border-slate-800 text-xs text-slate-400 font-medium">
                        <div>
                          <span className="text-white font-bold block">Suryaraopet</span>
                          Vijayawada, India
                        </div>
                        <div>
                          <span className="text-white font-bold block">Admissions</span>
                          24 hours open
                        </div>
                        <div>
                          <span className="text-white font-bold block">Staff Ratio</span>
                          High clinical attention
                        </div>
                      </div>

                    </div>

                    {/* Hero Right Content Column (QR panel for layout density) */}
                    <div className="hidden lg:flex lg:col-span-5 justify-center">
                      <div className="bg-slate-950/70 border border-slate-800 p-8 rounded-3xl backdrop-blur-md max-w-xs text-center space-y-4">
                        <div className="bg-white p-3 rounded-2xl inline-block shadow-lg border border-slate-800/10 hover:shadow-sky-500/20 transition-all">
                          <img 
                            src={qrImageUrl} 
                            alt="Scan QR code for Hospital location" 
                            className="w-40 h-40 object-contain rounded"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-white uppercase tracking-wider">
                            Hospital Location QR
                          </p>
                          <p className="text-[11px] text-slate-400 leading-snug">
                            Scan to open Medicare Multi Speciality location directly in Google Maps application.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </section>

              {/* Dynamic Welcome section */}
              <section className="max-w-7xl mx-auto px-4 md:px-6">
                <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-100 shadow-md grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
                  <div className="lg:col-span-5 rounded-2xl overflow-hidden aspect-[4/3] bg-slate-100 max-h-[300px]">
                    <img 
                      src="/src/assets/images/hospital_lobby_1780220828924.png" 
                      alt="Medicare Hospital Reception Area"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="lg:col-span-7 space-y-5">
                    <span className="text-xs bg-sky-50 border border-sky-100 text-sky-700 px-3 py-1 rounded-xl font-bold uppercase tracking-wider">
                      Welcome to Medicare
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-850 tracking-tight leading-snug">
                      We offer premium multi-speciality clinical expertise and emergency backups
                    </h2>
                    <p className="text-slate-650 text-sm leading-relaxed">
                      "Welcome to Medicare Multi Speciality Hospital. We provide comprehensive healthcare services with experienced specialists and advanced medical facilities." We emphasize immediate diagnosis, reliable clinical counseling, and personalized surgical treatments for patient families across Vijayawada.
                    </p>
                    <div className="pt-2">
                      <button 
                        onClick={() => setActiveTab("about")}
                        className="text-sky-600 hover:text-sky-700 font-bold text-sm flex items-center gap-1.5 group cursor-pointer"
                      >
                        Read hospital biography
                        <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </section>

              {/* Statistics Panel */}
              <section className="bg-[#0077B6]/5 py-12 border-y border-sky-100">
                <div className="max-w-7xl mx-auto px-4 md:px-6">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
                    {STATS.map((stat, i) => (
                      <div key={i} className="text-center space-y-2">
                        <div className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#0077B6] tracking-tight">
                          {stat.value}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">
                            {stat.label}
                          </p>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            {stat.sub}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* Why Choose Us */}
              <section className="max-w-7xl mx-auto px-4 md:px-6 space-y-10">
                <div className="text-center space-y-3">
                  <span className="text-xs bg-emerald-50 border border-emerald-100 text-emerald-800 px-3 py-1 rounded-full font-bold uppercase tracking-wider">
                    Our Pillars
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-850 tracking-tight">
                    Why Choose Medicare Hospital?
                  </h3>
                  <p className="text-xs text-slate-500 max-w-xl mx-auto">
                    We maintain stringent standards in our outpatient consults, critical ward nursing structure, and operating rooms to ensure consistent safe patient outcomes.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {WHY_CHOOSE_US.map((item, index) => {
                    // Pick relevant check icon or matching lucide symbols
                    const colors = [
                      "from-sky-50 to-indigo-50 border-sky-100 font-sky-800 hover:border-sky-300",
                      "from-amber-50 to-amber-100/50 border-amber-100 font-amber-800 hover:border-amber-300",
                      "from-rose-50 to-rose-100/50 border-rose-100 font-rose-800 hover:border-rose-300",
                      "from-emerald-50 to-emerald-100/50 border-emerald-100 font-emerald-800 hover:border-emerald-300",
                      "from-purple-50 to-purple-100/50 border-purple-100 font-purple-800 hover:border-purple-300",
                      "from-teal-50 to-teal-100/50 border-teal-100 font-teal-800 hover:border-teal-300"
                    ];
                    return (
                      <div 
                        key={index} 
                        className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-100 shadow-sm hover:shadow-md transition-all duration-300 space-y-4"
                      >
                        <div className="w-10 h-10 rounded-xl bg-[#0077B6]/5 text-[#0077B6] flex items-center justify-center font-bold">
                          <Check className="w-5 h-5" strokeWidth={3} />
                        </div>
                        <div className="space-y-1.5">
                          <h4 className="font-extrabold text-slate-800 text-base">
                            {item.title}
                          </h4>
                          <p className="text-xs text-slate-500 leading-relaxed">
                            {item.description}
                          </p>
                        </div>
                        <span className="text-[10px] text-sky-600 font-bold bg-sky-50/50 px-2 py-0.5 rounded border border-sky-100/30 inline-block">
                          {item.bullet}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </section>

            </motion.div>
          )}

          {/* ==================== ABOUT US TAB ==================== */}
          {activeTab === "about" && (
            <motion.div
              key="about-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-16"
            >
              {/* Title Section */}
              <div className="text-center space-y-3">
                <span className="text-xs bg-sky-50 border border-sky-100 text-sky-700 px-3 py-1 rounded-xl font-bold uppercase tracking-wider">
                  Our Legacy
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  About Medicare Multi Speciality Hospital
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  A high quality regional medical destination in Suruyaraopet, Vijayawada offering experienced clinical consultation and critical surgery back-ups.
                </p>
              </div>

              {/* Hospital Overview, Mission & Vision */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                <div className="space-y-6">
                  <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-md space-y-4">
                    <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
                      <ShieldCheck className="w-5 h-5 text-sky-600" />
                      Hospital Biography
                    </h2>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Established in the year 2021 in Suryaraopet, Vijayawada, Medicare Multi Speciality Hospital has clinical boundaries designed to provide exemplary patient-centered healthcare. Our infrastructure is equipped to address tertiary diagnostic procedures, complicated stomach surgeries, precise bone fracture care, ENT, and gynaecological treatments. 
                    </p>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Our nurses, clinical coordinators, and emergency paramedics coordinate daily to deliver flawless recoveries. We ensure that health therapies are made affordable, billing transparent, and consulting slots fully digital.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Mission */}
                    <div className="bg-emerald-50/40 rounded-2xl p-6 border border-emerald-100 space-y-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <Compass className="w-4.5 h-4.5" />
                      </div>
                      <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Our Mission</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        To prioritize health outcomes in Suryaraopet and Vijayawada by providing clinical excellence, advanced diagnostics, compassionate emergency triaging, and affordable treatment.
                      </p>
                    </div>

                    {/* Vision */}
                    <div className="bg-sky-50/40 rounded-2xl p-6 border border-sky-100 space-y-3">
                      <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
                        <Sparkles className="w-4.5 h-4.5" />
                      </div>
                      <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">Our Vision</h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        To become the region's most trusted hospital group synonymous with medical ethics, senior surgical precision, flawless clinical coordination, and high-performance ICU emergency support.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right Column: Managing Director Message */}
                <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-md col-span-1 lg:col-span-5">
                  <div className="flex flex-col sm:flex-row gap-6 items-center sm:items-start animate-fadeIn">
                    {/* MD Photo border */}
                    <div className="w-28 h-28 rounded-2xl overflow-hidden bg-slate-100 border-2 border-sky-200 shrink-0 shadow-sm relative">
                      <img 
                        src={dynHospitalInfo.managingDirectorPhoto || HOSPITAL_INFO.managingDirector.photo} 
                        alt={dynHospitalInfo.managingDirectorName || HOSPITAL_INFO.managingDirector.name} 
                        className="w-full h-full object-cover object-top"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    
                    <div className="space-y-1.5 text-center sm:text-left">
                      <p className="text-[#0077B6] font-bold text-xs uppercase tracking-wide">
                        {dynHospitalInfo.managingDirectorTitle || HOSPITAL_INFO.managingDirector.title}
                      </p>
                      <h3 className="text-xl font-extrabold text-slate-800 tracking-tight leading-snug">
                        {dynHospitalInfo.managingDirectorName || HOSPITAL_INFO.managingDirector.name}
                      </h3>
                      <p className="text-slate-400 text-xs">
                        {dynHospitalInfo.name}, Vijayawada
                      </p>
                    </div>
                  </div>

                  {/* Message and signature */}
                  <div className="mt-6 pt-6 border-t border-slate-100 space-y-4">
                    <p className="text-xs text-slate-500 italic leading-relaxed">
                      "{dynHospitalInfo.managingDirectorMessage || HOSPITAL_INFO.managingDirector.message}"
                    </p>
                    <div className="flex justify-between items-center bg-slate-50 p-4 rounded-xl text-xs">
                      <div>
                        <span className="font-bold text-slate-700 block">Patient Commitment Promise</span>
                        <span className="text-[10px] text-slate-400">Medicare Administrative Officer</span>
                      </div>
                      <div className="text-right">
                        <span className="text-sky-600 font-bold block mb-0.5">Medicare</span>
                        <span className="text-[#0077B6] font-mono tracking-wide text-[10px] font-bold">2021 - 2026</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Patient Care Principles Banner */}
              <div className="bg-gradient-to-tr from-sky-900 via-sky-950 to-[#0077B6] text-white rounded-3xl p-8 sm:p-12 shadow-lg space-y-4 text-center">
                <div className="w-10 h-10 rounded-xl bg-white/10 text-sky-400 flex items-center justify-center mx-auto mb-2">
                  <Star className="w-5 h-5 fill-sky-300" />
                </div>
                <h3 className="text-2xl font-bold tracking-tight">Our Unwavering Clinical Excellence Standards</h3>
                <p className="text-xs text-sky-200/80 max-w-xl mx-auto leading-relaxed">
                  We integrate safe operating theater sterility protocols, real-time bio diagnostics, and certified ward assistance mechanisms to deliver pristine patient care standards.
                </p>
                <div className="flex flex-wrap justify-center gap-6 text-xs text-white/90 pt-4">
                  <span className="flex items-center gap-1.5 font-semibold bg-white/5 py-1 px-3 rounded-xl border border-white/5">
                    <Check className="w-4 h-4 text-emerald-400" /> Transparent Pricing
                  </span>
                  <span className="flex items-center gap-1.5 font-semibold bg-white/5 py-1 px-3 rounded-xl border border-white/5">
                    <Check className="w-4 h-4 text-emerald-400" /> Zero Infection Target
                  </span>
                  <span className="flex items-center gap-1.5 font-semibold bg-white/5 py-1 px-3 rounded-xl border border-white/5">
                    <Check className="w-4 h-4 text-emerald-400" /> Accredited Chemists
                  </span>
                </div>
              </div>
            </motion.div>
          )}

          {/* ==================== DOCTORS TAB ==================== */}
          {activeTab === "doctors" && (
            <motion.div
              key="doctors-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-12"
            >
              {/* Profile card title */}
              <div className="text-center space-y-3">
                <span className="text-xs bg-sky-50 border border-sky-100 text-[#0077B6] px-3 py-1 rounded-xl font-bold uppercase tracking-wider">
                  Accredited Staff
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  Our Specialist Doctors & Surgeons
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  Medicare Hospital in Vijayawada is powered by senior physicians, laparoscopic surgeons, and pediatric experts with verified track records of clinical success.
                </p>
              </div>

              {/* Dynamic Grid Layout containing Cards */}
              <DoctorGrid onBookDoctor={handleBookDoctorAndRedirect} />

              {/* Out-patient quick notice */}
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="text-left space-y-1 text-xs">
                  <h4 className="font-extrabold text-slate-800 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-indigo-600" />
                    Specialist OPD Schedule Advisory
                  </h4>
                  <p className="text-slate-500">
                    OPD slots of specific laparoscopic surgeons may fluctuate due to scheduled operation theater bookings. Real-time slot pre-booking is advised to minimize waiting.
                  </p>
                </div>
                <button
                  onClick={handleBookButtonClickNoDoc}
                  className="px-5 py-3 rounded-xl bg-slate-900 hover:bg-[#0077B6] text-white text-xs font-bold tracking-wider uppercase transition-all shrink-0 cursor-pointer"
                >
                  Schedule an OPD Appointment
                </button>
              </div>
            </motion.div>
          )}

          {/* ==================== SERVICES TAB ==================== */}
          {activeTab === "services" && (
            <motion.div
              key="services-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-12"
            >
              {/* Title Header */}
              <div className="text-center space-y-3">
                <span className="text-xs bg-sky-50 border border-sky-100 text-sky-750 px-3 py-1 rounded-xl font-bold uppercase tracking-wider">
                  Specialized Scope
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  Our Multi-Speciality Clinical Services
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  We provide specialized keyhole laparoscopy, urological laser surgery, orthopedic treatments, ENT therapy, and comprehensive women's health packages.
                </p>
              </div>

              {/* Services cards grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {dynServices.map((ser) => (
                  <div 
                    key={ser.id}
                    className="bg-white p-6 sm:p-7 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between group hover:border-[#0077B6]/30"
                    id={`service-card-${ser.id}`}
                  >
                    <div className="space-y-4">
                      {/* Icon bubble */}
                      <div className="w-10 h-10 rounded-xl bg-[#0077B6]/5 text-[#0077B6] flex items-center justify-center shrink-0 group-hover:scale-105 duration-300">
                        {getIconComponent(ser.iconName)}
                      </div>
                      
                      <div className="space-y-1.5 text-left">
                        <h3 className="font-extrabold text-slate-800 text-sm sm:text-base tracking-tight leading-snug">
                          {ser.title}
                        </h3>
                        <p className="text-slate-500 text-xs leading-relaxed">
                          {ser.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-4 mt-4 border-t border-slate-50 flex justify-between items-center text-xs">
                      <span className="text-slate-400 font-mono tracking-wider text-[10px] uppercase font-bold">Medicare</span>
                      <button 
                        onClick={handleBookButtonClickNoDoc}
                        className="text-sky-600 font-bold hover:underline cursor-pointer"
                      >
                        Book slot &rarr;
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Custom Medical package highlight */}
              <div className="bg-gradient-to-tr from-sky-950 to-[#0077B6] rounded-3xl p-8 text-white grid grid-cols-1 lg:grid-cols-12 gap-8 items-center text-center lg:text-left">
                <div className="lg:col-span-8 space-y-2">
                  <h3 className="text-xl font-bold">Preventative Health Screening Packages</h3>
                  <p className="text-xs text-sky-200 leading-relaxed">
                    Preventative diagnostic exams is clinical wisdom. Select our executive cardiovascular panel, complete biochemical screening, and diabetic test bundles. Fully updated digital lab reports in 6 hours.
                  </p>
                </div>
                <div className="lg:col-span-4 flex justify-center lg:justify-end">
                  <button 
                    onClick={handleBookButtonClickNoDoc}
                    className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-[#0077B6] font-extrabold text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer"
                  >
                    Consult Diagnostics
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ==================== FACILITIES TAB ==================== */}
          {activeTab === "facilities" && (
            <motion.div
              key="facilities-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-12"
            >
              {/* Title Section */}
              <div className="text-center space-y-3">
                <span className="text-xs bg-emerald-50 border border-emerald-100 text-emerald-800 px-3 py-1 rounded-full font-bold uppercase tracking-wider">
                  Healthcare Assets
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  Advanced Medical Facilities & Patient Care
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  Our Suryaraopet hospital unit has 24/7 fully stocked pharmacy, real-time advanced laboratory, ICU life support, waiting spaces, and reliable ambulance transfer services.
                </p>
              </div>

              {/* Facilities grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {FACILITIES.map((fac) => (
                  <div 
                    key={fac.id}
                    className="bg-white p-6 rounded-2xl border border-slate-100 hover:border-emerald-100 shadow-sm flex flex-col justify-between group"
                    id={`facility-card-${fac.id}`}
                  >
                    <div className="space-y-4 text-left">
                      {/* Icon capsule with emerald color */}
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                        {getIconComponent(fac.iconName, "w-5 h-5")}
                      </div>
                      
                      <div className="space-y-1">
                        <h4 className="font-extrabold text-slate-850 text-base">
                          {fac.title}
                        </h4>
                        <p className="text-slate-500 text-xs leading-relaxed">
                          {fac.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-4 mt-4 border-t border-slate-50 text-[10px] text-slate-400 font-mono tracking-wider">
                      STAFF OPERATED • 24/7 Available
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* ==================== GALLERY TAB ==================== */}
          {activeTab === "gallery" && (
            <motion.div
              key="gallery-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-12"
            >
              {/* Title Section */}
              <div className="text-center space-y-3">
                <span className="text-xs bg-sky-50 border border-sky-100 text-[#0077B6] px-3 py-1 rounded-xl font-bold uppercase tracking-wider">
                  Visual Media
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  Hospital Media Gallery & Diagnostics Suite
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  Take a photorealistic digital tour of our clinical premises in Suryaraopet, Vijayawada. Tap any media item below to launch the zoom-in lightbox viewer.
                </p>
              </div>

              {/* Gallery Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                {dynGallery.map((item, index) => (
                  <button
                    key={item.id}
                    onClick={() => setLightboxIndex(index)}
                    className="group bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-lg text-left transition-all relative cursor-zoom-in"
                    id={`gallery-item-btn-${item.id}`}
                  >
                    <div className="aspect-[4/3] bg-slate-100 overflow-hidden relative">
                      <img 
                        src={item.url} 
                        alt={item.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-[#0077B6]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>
                    <div className="p-4 bg-white">
                      <span className="text-[10px] font-bold text-sky-600 uppercase tracking-widest block mb-0.5">
                        {item.category}
                      </span>
                      <h4 className="text-xs sm:text-sm font-bold tracking-tight text-slate-800 line-clamp-1">
                        {item.title}
                      </h4>
                    </div>
                  </button>
                ))}
              </div>

              {/* Lightbox Trigger controller layer */}
              {lightboxIndex !== null && (
                <Lightbox 
                  items={dynGallery} 
                  currentIndex={lightboxIndex} 
                  onClose={() => setLightboxIndex(null)}
                  onPrev={() => setLightboxIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : dynGallery.length - 1))}
                  onNext={() => setLightboxIndex((prev) => (prev !== null && prev < dynGallery.length - 1 ? prev + 1 : 0))}
                />
              )}
            </motion.div>
          )}

          {/* ==================== REVIEWS TAB ==================== */}
          {activeTab === "reviews" && (
            <motion.div
              key="reviews-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12"
            >
              <ReviewSection />
            </motion.div>
          )}

          {/* ==================== APPOINTMENT TAB ==================== */}
          {activeTab === "appointment" && (
            <motion.div
              key="appointment-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-12"
            >
              <div className="text-center space-y-3">
                <span className="text-xs bg-emerald-50 border border-emerald-100 text-emerald-800 px-3 py-1 rounded-full font-bold uppercase tracking-wider">
                  Out-Patient Slot Scheduling
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  Online Clinical Appointment Desk
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  Pre-book consulting slots, laparoscopic surgical assessments, or urological laser consultations easily. Our administrative coordinators will verify your submission promptly.
                </p>
              </div>

              <AppointmentForm initialDoctorName={selectedDoctorName} />
            </motion.div>
          )}

          {/* ==================== CONTACT TAB ==================== */}
          {activeTab === "contact" && (
            <motion.div
              key="contact-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12 space-y-16"
            >
              {/* Title Area */}
              <div className="text-center space-y-3">
                <span className="text-xs bg-sky-50 border border-sky-100 text-[#0077B6] px-3 py-1 rounded-xl font-bold uppercase tracking-wider">
                  Contact Coordinates
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-850">
                  Get In Touch With Administrative Desk
                </h1>
                <p className="text-xs text-slate-500 max-w-xl mx-auto">
                  For emergency admissions, corporate wellness panels, surgical packages info, and real-time support, contact our round-the-clock telephone lines.
                </p>
              </div>

              {/* Coordinates Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
                
                {/* Visual side panel - Coordinates */}
                <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-md col-span-1 lg:col-span-4 space-y-8 flex flex-col justify-between">
                  <div className="space-y-6">
                    <h3 className="font-extrabold text-slate-800 text-lg border-b border-slate-100 pb-3">
                      Hospital Registry Contacts
                    </h3>
                    
                    <ul className="space-y-4 text-xs">
                      <li className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-slate-700 block mb-0.5">Physical Hospital Address:</strong>
                          <span className="text-slate-500 leading-relaxed block">
                            Medicare Multi Speciality Hospital,<br />
                            {HOSPITAL_INFO.address}
                          </span>
                        </div>
                      </li>

                      <li className="flex items-start gap-3">
                        <Phone className="w-5 h-5 text-[#0077B6] shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-slate-700 block mb-0.5">24/7 Dial-In Lines:</strong>
                          <div className="space-y-1">
                            {HOSPITAL_INFO.phones.map((p) => (
                              <a key={p} href={`tel:${p}`} className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1 text-slate-700 font-mono block hover:bg-slate-150 text-xs font-semibold">
                                +91 {p}
                              </a>
                            ))}
                          </div>
                        </div>
                      </li>

                      <li className="flex items-start gap-3">
                        <Mail className="w-5 h-5 text-[#0077B6] shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-slate-700 block mb-0.5">Email Queries:</strong>
                          <a href={`mailto:${HOSPITAL_INFO.email}`} className="text-sky-600 hover:underline">
                            {HOSPITAL_INFO.email}
                          </a>
                        </div>
                      </li>

                      <li className="flex items-start gap-3">
                        <Clock className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5 animate-pulse" />
                        <div>
                          <strong className="text-emerald-800 block mb-0.5">General OPD Hours:</strong>
                          <span className="text-slate-500 block">Mon - Sat: 09:00 AM - 08:30 PM</span>
                          <span className="text-emerald-600 font-bold block mt-1">Surgical / Emergency ICU Admissions: 24/7 Open</span>
                        </div>
                      </li>
                    </ul>
                  </div>

                  {/* Address directions deep links */}
                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex items-center justify-between gap-4 text-xs">
                    <div>
                      <span className="font-bold text-slate-800 block">Open Location App</span>
                      <span className="text-slate-400 text-[10px]">Navigate via smartphones</span>
                    </div>
                    <a 
                      href={HOSPITAL_INFO.mapsLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 hover:bg-sky-600 hover:text-white bg-white text-slate-700 border border-slate-200 rounded-xl font-bold transition-all text-xs flex items-center gap-1 uppercase tracking-wide shrink-0 shadow-sm"
                    >
                      <Map className="w-3.5 h-3.5" />
                      View Map
                    </a>
                  </div>

                </div>

                {/* Patient Quick Contact form */}
                <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-md col-span-1 lg:col-span-8">
                  {contactSubmitted ? (
                    <div className="py-12 text-center space-y-6 animate-fadeIn">
                      <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-100">
                        <Check className="w-7 h-7" strokeWidth={3} />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-xl font-bold text-slate-800">Support Request Sent Successfully</h3>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                          Thank you for coordinating with Medicare Multi Speciality Hospital. Our administrative receptionist will address your query over phone in less than 2 hours.
                        </p>
                      </div>

                      {/* EmailJS Support Inquiry Delivery State */}
                      <div className="p-4 bg-slate-50/80 rounded-2xl border border-slate-100 max-w-sm mx-auto text-left space-y-2 text-xs">
                        <p className="text-slate-700 font-bold block mb-1 text-center text-xs uppercase tracking-wide">
                          📧 EmailJS Ticket Dispatch Status
                        </p>
                        {contactEmailSending && (
                          <p className="text-blue-600 font-semibold text-center animate-pulse">
                            Routing ticket to administration desk via EmailJS...
                          </p>
                        )}
                        {contactEmailStatus === "success" && (
                          <p className="text-emerald-700 font-semibold text-center leading-relaxed">
                            ✔ Ticket routed and delivered to clinic inbox.
                          </p>
                        )}
                        {contactEmailStatus === "error" && (
                          <div className="space-y-1 text-rose-700">
                            <p className="font-bold text-center">✗ Routing failed.</p>
                            <p className="text-[10px] text-slate-500 font-mono text-center overflow-x-auto bg-slate-100 p-1.5 rounded">
                              Details: {contactEmailErrorDetail}
                            </p>
                          </div>
                        )}
                        {contactEmailStatus === "unconfigured" && (
                          <div className="space-y-1 text-slate-600 text-center">
                            <p className="font-semibold text-slate-600">ℹ Simulated transfer complete.</p>
                            <p className="text-[11px] text-slate-550 leading-relaxed text-center">
                              Real email routing requires <code className="bg-slate-100 px-1 py-0.5 rounded text-rose-600 text-[10px]">VITE_EMAILJS_SERVICE_ID</code> environment setup.
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={handleResetContactForm}
                          className="px-6 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-750 font-bold text-xs uppercase transition-all shadow-sm cursor-pointer"
                        >
                          Submit Another Ticket
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleContactSubmit} className="space-y-5">
                      <div>
                        <div className="flex flex-wrap justify-between items-start gap-2 mb-1">
                          <h3 className="text-lg font-bold text-slate-800">Submit a Support Ticket</h3>
                          {contactConfigActive || isEmailJsConfigured() ? (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100 flex items-center gap-1">
                              <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse"></span>
                              EmailJS Live
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100 flex items-center gap-1">
                              <span className="w-1 h-1 rounded-full bg-amber-400"></span>
                              Demo mode
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500">Have hospital admissions questions or need room availability details? Let our billing and administrative desk assist you.</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div className="space-y-1.5 text-xs text-slate-700">
                          <label className="font-bold">Patient / Coordinator Name <span className="text-rose-500">*</span></label>
                          <input 
                            type="text" 
                            required
                            placeholder="e.g. Ramesh Reddy" 
                            value={contactName}
                            onChange={(e) => setContactName(e.target.value)}
                            className="bg-slate-50 text-slate-800 p-3 rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:bg-white transition-all w-full leading-none"
                          />
                        </div>
                        <div className="space-y-1.5 text-xs text-slate-700">
                          <label className="font-bold">Phone Number <span className="text-rose-500">*</span></label>
                          <input 
                            type="tel" 
                            required
                            placeholder="e.g. 9876543210" 
                            value={contactPhone}
                            onChange={(e) => setContactPhone(e.target.value)}
                            className="bg-slate-50 text-slate-800 p-3 rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:bg-white transition-all w-full font-mono leading-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div className="space-y-1.5 text-xs text-slate-700">
                          <label className="font-bold">Email Address</label>
                          <input 
                            type="email" 
                            placeholder="e.g. coordinator@gmail.com" 
                            value={contactEmail}
                            onChange={(e) => setContactEmail(e.target.value)}
                            className="bg-slate-50 text-slate-800 p-3 rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:bg-white transition-all w-full leading-none"
                          />
                        </div>
                        <div className="space-y-1.5 text-xs text-slate-700">
                          <label className="font-bold">Subject Of Inquiry</label>
                          <input 
                            type="text" 
                            placeholder="e.g. Inpatient Room Tariffs" 
                            value={contactSubject}
                            onChange={(e) => setContactSubject(e.target.value)}
                            className="bg-slate-50 text-slate-800 p-3 rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:bg-white transition-all w-full leading-none"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5 text-xs text-slate-700">
                        <label className="font-bold">Your Inquiry Details <span className="text-rose-500">*</span></label>
                        <textarea 
                          required
                          rows={4}
                          placeholder="Type your message or detailing regarding surgical costs, lab diagnostic packages, room categories, or doctor OPD consulting queries..." 
                          value={contactMsg}
                          onChange={(e) => setContactMsg(e.target.value)}
                          className="bg-slate-50 text-slate-800 p-3.5 rounded-xl border border-slate-200 focus:outline-none focus:border-sky-500 focus:bg-white transition-all w-full text-xs resize-none leading-relaxed"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-[#0077B6] hover:bg-sky-700 text-white font-extrabold text-xs uppercase tracking-widest transition-all shadow cursor-pointer text-center"
                      >
                        SUBMIT INQUIRY
                      </button>
                    </form>
                  )}
                </div>

              </div>

              {/* Embedded Interactive Google Map and Scan QR code layout */}
              <div className="bg-white border border-slate-100 rounded-3xl p-6 sm:p-10 shadow-md">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  
                  {/* Google Map embed code */}
                  <div className="lg:col-span-8 space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="font-extrabold text-slate-850 text-base flex items-center gap-2">
                        <Map className="w-5 h-5 text-indigo-650" />
                        Embedded Surgical Unit Location
                      </h4>
                      <div className="flex gap-2">
                        <a 
                          href={HOSPITAL_INFO.mapsLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] sm:text-xs font-bold text-sky-600 hover:underline flex items-center gap-0.5"
                        >
                          Open Google Maps
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                        <span className="text-slate-300">|</span>
                        <a 
                          href={HOSPITAL_INFO.directionsLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] sm:text-xs font-bold text-emerald-600 hover:underline flex items-center gap-0.5"
                        >
                          Get Directions 🚙
                        </a>
                      </div>
                    </div>
                    
                    {/* Real Iframe embed for Google Maps location of Medicare Multi Speciality Hospital, Vijayawada */}
                    <div className="rounded-2xl overflow-hidden border border-slate-200/60 shadow-inner overflow-hidden aspect-video max-h-[380px] w-full relative">
                      <iframe 
                        title="Medicare Multi Speciality Hospital Google Maps Location in Suryaraopet Vijayawada"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3825.2638848467448!2d80.6276707!3d16.512759!2m3!1f0!2f0!3f0!3m2!1i1242!2i768!4f13.1!3m3!1m2!1s0x3a35f1bc0931fcab%3A0xc66085a81ca4da0e!2sMedicare%20Multi%20Speciality%20Hospital!5e0!3m2!1sen!2sin!4v1700000000000" 
                        className="absolute inset-0 w-full h-full border-0"
                        allowFullScreen 
                        loading="lazy" 
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>

                  {/* QR Code Layout side widget */}
                  <div className="lg:col-span-4 bg-slate-50 border border-slate-100 rounded-2xl p-6 sm:p-8 space-y-4 text-center">
                    <h4 className="font-extrabold text-xs tracking-wider uppercase text-slate-400">
                      Scan QR for Hospital Location
                    </h4>
                    
                    <div className="bg-white p-3 rounded-2xl inline-block shadow border border-slate-100">
                      <img 
                        src={qrImageUrl} 
                        alt="Medicare Multi Speciality Hospital Google Maps QR Location code" 
                        className="w-40 h-40 object-contain rounded"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="space-y-1 text-xs">
                      <strong className="text-slate-800 block">Scan to Navigate</strong>
                      <p className="text-slate-500 leading-snug">
                        Point your mobile camera at this QR code to load exact physical coordinates in the Google Maps app.
                      </p>
                    </div>
                  </div>

                </div>
              </div>
            </motion.div>
          )}

          {/* ==================== PATIENT PORTAL TAB ==================== */}
          {activeTab === "patient-portal" && (
            <motion.div
              key="patient-portal-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12"
            >
              <PatientPortal />
            </motion.div>
          )}

          {/* ==================== ADMIN DASHBOARD TAB ==================== */}
          {activeTab === "admin-dashboard" && (
            <motion.div
              key="admin-dashboard-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="max-w-7xl mx-auto px-4 md:px-6 py-12"
            >
              <AdminDashboard />
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* ==================== FOOTER ==================== */}
      <Footer setActiveTab={setActiveTab} />

      {/* ==================== FLOATING ACTION BUTTONS OVERLAY ==================== */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3 items-end" id="floating-action-buttons-overlay">
        
        {/* Scroll To Top element */}
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="p-3 rounded-full bg-slate-900 border border-slate-800 text-white shadow-lg shadow-slate-950/20 active:scale-95 transition-all outline-none cursor-pointer flex items-center justify-center hover:bg-slate-800"
            title="Scroll to top"
          >
            <ChevronRight className="w-5 h-5 -rotate-90" strokeWidth={2.5} />
          </button>
        )}

        {/* Messaging Support trigger */}
        <button
          onClick={() => {
            setActiveTab("contact");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
          className="p-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-500/20 active:scale-95 transition-all outline-none cursor-pointer flex items-center justify-center gap-2 group max-w-[50px] hover:max-w-[180px] overflow-hidden whitespace-nowrap"
          title="Message hospital desk"
          id="floating-messaging-btn"
        >
          <MessageSquare className="w-5 h-5 shrink-0" />
          <span className="text-xs font-bold leading-none uppercase tracking-wide opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            Send Message
          </span>
        </button>

        {/* WhatsApp Consultation trigger */}
        <a
          href="https://wa.me/916281573727"
          target="_blank"
          rel="noopener noreferrer"
          className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 active:scale-95 transition-all outline-none flex items-center justify-center gap-2 group max-w-[50px] hover:max-w-[200px] overflow-hidden whitespace-nowrap"
          title="Chat with Medicare on WhatsApp"
          id="floating-whatsapp-btn"
        >
          <MessageCircle className="w-5 h-5 fill-white text-emerald-600 shrink-0" />
          <span className="text-xs font-bold leading-none uppercase tracking-wide opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            Emergency Chat
          </span>
        </a>

        {/* Emergency Call dial-in hot trigger */}
        <a
          href="tel:9966700911"
          className="p-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-500/30 active:scale-95 transition-all outline-none flex items-center justify-center gap-2 animate-bounce group max-w-[50px] hover:max-w-[220px] overflow-hidden whitespace-nowrap border-2 border-white"
          title="Direct Dial Emergency ICU Desk"
          id="floating-emergency-call-btn"
        >
          <PhoneCall className="w-5 h-5 shrink-0 animate-pulse text-white" />
          <span className="text-xs font-bold leading-none uppercase tracking-wide opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            Emergency: 9966700911
          </span>
        </a>

      </div>

    </div>
  );
}
